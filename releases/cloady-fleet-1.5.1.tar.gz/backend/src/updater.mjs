import fs from 'node:fs';
import path from 'node:path';
import { CONFIG } from './config.mjs';

export const UPDATE_STATUS_FILE = path.join(CONFIG.dataDir, 'update-status.json');
export const UPDATE_REQUEST_FILE = path.join(CONFIG.dataDir, 'update.request');

export function readUpdateStatus() {
  let file = null;
  try {
    file = JSON.parse(fs.readFileSync(UPDATE_STATUS_FILE, 'utf8'));
  } catch {
    /* the host updater has not run yet */
  }
  return {
    currentVersion: CONFIG.version,
    status: file?.status || 'unknown',
    message: file?.message || null,
    checkedAt: file?.checked_at || null,
    latestVersion: file?.latest_version || null,
    appliedVersion: file?.applied_version || null,
    enabled: file?.enabled ?? true,
    requestPending: fs.existsSync(UPDATE_REQUEST_FILE),
  };
}

export function requestUpdate() {
  fs.mkdirSync(CONFIG.dataDir, { recursive: true });
  fs.writeFileSync(UPDATE_REQUEST_FILE, new Date().toISOString());
  return { ok: true, requestedAt: new Date().toISOString() };
}
