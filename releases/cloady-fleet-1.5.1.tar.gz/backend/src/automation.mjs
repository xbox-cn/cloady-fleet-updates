import { db, settings, audit } from './db.mjs';
import { createJob, getJob, jobBus } from './jobs.mjs';
import { log } from './config.mjs';

const KEYS = {
  enabled: 'automation_enabled',
  verify: 'automation_verify_enabled',
  sync: 'automation_sync_enabled',
  interval: 'automation_interval_minutes',
  lastRun: 'automation_last_run',
  nextRun: 'automation_next_run',
  lastJob: 'automation_last_job',
  lastError: 'automation_last_error',
};

const DEFAULTS = {
  [KEYS.enabled]: '1',
  [KEYS.verify]: '1',
  [KEYS.sync]: '1',
  [KEYS.interval]: '30',
};

let currentJobId = null;
let timer = null;
let initialized = false;

function flag(key) {
  return settings.get(key) === '1';
}

function intervalMinutes() {
  const raw = Number(settings.get(KEYS.interval));
  return Number.isFinite(raw) ? Math.min(1440, Math.max(5, Math.round(raw))) : 30;
}

function intervalMs() {
  return intervalMinutes() * 60_000;
}

function isoOrNull(value) {
  const ms = Number(value || 0);
  return ms > 0 ? new Date(ms).toISOString() : null;
}

function ensureDefaults() {
  for (const [key, value] of Object.entries(DEFAULTS)) {
    if (settings.get(key) === null) settings.set(key, value);
  }
}

function accountCounts() {
  const counts = { total: 0, normal: 0, banned: 0, unknown: 0 };
  for (const row of db.prepare('SELECT status, COUNT(*) AS n FROM accounts GROUP BY status').all()) {
    const key = row.status === 'normal' || row.status === 'banned' ? row.status : 'unknown';
    counts[key] += row.n;
    counts.total += row.n;
  }
  return counts;
}

export function getAutomationStatus() {
  const lastJobId = settings.get(KEYS.lastJob) || null;
  return {
    enabled: flag(KEYS.enabled),
    verifyEnabled: flag(KEYS.verify),
    syncEnabled: flag(KEYS.sync),
    intervalMinutes: intervalMinutes(),
    lastRunAt: settings.get(KEYS.lastRun) || null,
    nextRunAt: isoOrNull(settings.get(KEYS.nextRun)),
    lastJobId,
    lastJob: lastJobId ? getJob(lastJobId) : null,
    running: Boolean(currentJobId),
    currentJobId,
    lastError: settings.get(KEYS.lastError) || null,
    counts: accountCounts(),
  };
}

function scheduleAfterRun(now = Date.now()) {
  settings.set(KEYS.nextRun, String(now + intervalMs()));
}

export function runAutomation(trigger = 'manual', force = false) {
  ensureDefaults();
  if (!force && !flag(KEYS.enabled)) return { ok: false, reason: 'disabled' };
  if (currentJobId) return { ok: false, reason: 'running', jobId: currentJobId };

  const ids = db.prepare('SELECT id FROM accounts ORDER BY created_at').all().map((row) => row.id);
  const now = Date.now();
  if (!ids.length) {
    scheduleAfterRun(now);
    return { ok: false, reason: 'no_accounts' };
  }
  if (!flag(KEYS.sync) && !flag(KEYS.verify)) {
    scheduleAfterRun(now);
    return { ok: false, reason: 'no_tasks' };
  }

  const useSync = flag(KEYS.sync);
  const kind = useSync ? 'sync' : 'verify';
  const minutes = intervalMinutes();
  const label = useSync
    ? `自动同步 · ${minutes} 分钟巡检`
    : `自动测活 · ${minutes} 分钟巡检`;

  const { id } = createJob({
    kind,
    accountIds: ids,
    actor: 'automation',
    label,
  });
  currentJobId = id;
  settings.set(KEYS.lastRun, new Date(now).toISOString());
  settings.set(KEYS.lastJob, id);
  settings.set(KEYS.lastError, '');
  scheduleAfterRun(now);
  audit('automation', 'automation.run', { trigger, jobId: id, kind, accounts: ids.length });
  log.info(`[automation] ${label} → ${id} (${ids.length} accounts)`);
  return { ok: true, jobId: id, job: getJob(id) };
}

export function runAutomationNow() {
  return runAutomation('manual', true);
}

export function updateAutomation(patch = {}) {
  ensureDefaults();
  const before = getAutomationStatus();

  if (typeof patch.enabled === 'boolean') settings.set(KEYS.enabled, patch.enabled ? '1' : '0');
  if (typeof patch.verifyEnabled === 'boolean') settings.set(KEYS.verify, patch.verifyEnabled ? '1' : '0');
  if (typeof patch.syncEnabled === 'boolean') settings.set(KEYS.sync, patch.syncEnabled ? '1' : '0');
  if (patch.intervalMinutes != null) {
    const minutes = Math.min(1440, Math.max(5, Math.round(Number(patch.intervalMinutes) || 30)));
    settings.set(KEYS.interval, String(minutes));
  }

  const enabled = flag(KEYS.enabled);
  const next = Number(settings.get(KEYS.nextRun) || 0);
  if (enabled && (!next || next < Date.now()) && !currentJobId) {
    // Newly enabled or overdue: check shortly instead of waiting a full interval.
    settings.set(KEYS.nextRun, String(Date.now() + 10_000));
  }
  if (patch.intervalMinutes != null && enabled) {
    const last = Date.parse(settings.get(KEYS.lastRun) || '') || 0;
    const candidate = last ? last + intervalMs() : Date.now() + intervalMs();
    settings.set(KEYS.nextRun, String(Math.max(Date.now() + 5_000, candidate)));
  }
  if (before.enabled !== enabled) {
    audit('manager', enabled ? 'automation.enable' : 'automation.disable', {});
  }
  return getAutomationStatus();
}

function tick() {
  if (!flag(KEYS.enabled)) return;
  if (currentJobId) return;
  const next = Number(settings.get(KEYS.nextRun) || 0);
  if (!next || Date.now() < next) return;
  try {
    const result = runAutomation('schedule');
    if (!result.ok && result.reason === 'no_accounts') {
      // Nothing to check yet; the next tick after the interval will retry.
    }
  } catch (error) {
    settings.set(KEYS.lastError, String(error.message || error).slice(0, 400));
    log.error('[automation] run failed', error);
    scheduleAfterRun();
  }
}

export function initAutomation() {
  if (initialized) return;
  initialized = true;
  ensureDefaults();

  if (!Number(settings.get(KEYS.nextRun) || 0)) {
    const lastRun = Date.parse(settings.get(KEYS.lastRun) || '') || 0;
    const next = lastRun ? Math.max(Date.now(), lastRun + intervalMs()) : Date.now() + 20_000;
    settings.set(KEYS.nextRun, String(next));
  }

  jobBus.on('event', (event) => {
    if (event.type !== 'done' || event.jobId !== currentJobId) return;
    if (event.status === 'failed') {
      settings.set(KEYS.lastError, '最近一次自动巡检失败');
    }
    currentJobId = null;
  });

  if (timer) clearInterval(timer);
  timer = setInterval(tick, 15_000);
  timer.unref?.();

  const status = getAutomationStatus();
  log.info(
    `[automation] ${status.enabled ? 'enabled' : 'disabled'} · every ${status.intervalMinutes}m`
    + ` · verify=${status.verifyEnabled} sync=${status.syncEnabled} · next=${status.nextRunAt || '—'}`,
  );
}

export function stopAutomation() {
  if (timer) clearInterval(timer);
  timer = null;
}
