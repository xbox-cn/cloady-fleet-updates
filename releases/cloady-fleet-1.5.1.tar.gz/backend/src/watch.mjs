/**
 * New-account probation watcher.
 * Imported accounts are already verified once by the import job; this loop
 * re-runs /api/me + scope inference every 3 minutes for the first hour so an
 * early ban is reflected quickly instead of waiting for the 30-minute sweep.
 */
import { db, audit, settings } from './db.mjs';
import { createJob, jobBus } from './jobs.mjs';
import { log } from './config.mjs';
import { IMPORT_WATCH_INTERVAL_MINUTES } from './accounts.mjs';

let timer = null;
let runningJobId = null;
let initialized = false;

function dueAccountIds(nowIso) {
  return db.prepare(`
    SELECT id FROM accounts
    WHERE watch_until IS NOT NULL
      AND watch_until > ?
      AND watch_next_at IS NOT NULL
      AND watch_next_at <= ?
      AND status <> 'banned'
    ORDER BY watch_next_at
    LIMIT 200
  `).all(nowIso, nowIso).map((row) => row.id);
}

function hasRunningJob() {
  return Boolean(
    db.prepare("SELECT 1 FROM jobs WHERE status IN ('queued', 'running') LIMIT 1").get(),
  );
}

function clearExpired(nowIso) {
  db.prepare(`
    UPDATE accounts SET watch_until = NULL, watch_next_at = NULL
    WHERE watch_until IS NOT NULL AND watch_until <= ?
  `).run(nowIso);
}

function tick() {
  if (runningJobId) return;
  if (settings.get('automation_enabled') === '0') return;

  const now = new Date();
  const nowIso = now.toISOString();
  clearExpired(nowIso);

  // Do not overlap the import job, a manual batch, or the regular sweep.
  if (hasRunningJob()) return;

  const ids = dueAccountIds(nowIso);
  if (!ids.length) return;

  const nextAt = new Date(
    now.getTime() + IMPORT_WATCH_INTERVAL_MINUTES * 60_000,
  ).toISOString();
  const update = db.prepare(`
    UPDATE accounts
    SET watch_next_at = ?, watch_last_at = ?, watch_rounds = watch_rounds + 1
    WHERE id = ?
  `);
  for (const id of ids) update.run(nextAt, nowIso, id);

  try {
    const { id } = createJob({
      kind: 'verify',
      accountIds: ids,
      actor: 'watch',
      label: `导入观察复测 · ${ids.length} 个账号`,
    });
    runningJobId = id;
    audit('watch', 'watch.run', { jobId: id, accounts: ids.length });
    log.info(`[watch] ${IMPORT_WATCH_INTERVAL_MINUTES}m recheck → ${id} (${ids.length} accounts)`);
  } catch (error) {
    log.error('[watch] create job failed', error);
  }
}

export function initWatch() {
  if (initialized) return;
  initialized = true;

  jobBus.on('event', (event) => {
    if (event.type === 'done' && event.jobId === runningJobId) runningJobId = null;
  });

  if (timer) clearInterval(timer);
  timer = setInterval(tick, 15_000);
  timer.unref?.();

  setTimeout(tick, 15_000).unref?.();
  log.info(`[watch] imports rechecked every ${IMPORT_WATCH_INTERVAL_MINUTES}m during probation`);
}

export function stopWatch() {
  if (timer) clearInterval(timer);
  timer = null;
}
