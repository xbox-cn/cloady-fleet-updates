import fs from 'node:fs';
import { db } from './db.mjs';
import { CONFIG } from './config.mjs';
import { stats as clientStats, cacheStats } from './lib/cloady.mjs';
import { jobStats, listJobs } from './jobs.mjs';
import { OPERATIONS } from './operations.mjs';
import { getCatalog } from './catalog.mjs';

const startedAt = Date.now();

function group(sql) {
  return Object.fromEntries(db.prepare(sql).all().map((r) => [r.k ?? 'unknown', r.n]));
}

export function overview() {
  const accountStatus = group('SELECT status AS k, COUNT(*) AS n FROM accounts GROUP BY status');
  const accountScope = group('SELECT scope AS k, COUNT(*) AS n FROM accounts GROUP BY scope');
  const serviceStatus = group('SELECT status AS k, COUNT(*) AS n FROM services GROUP BY status');
  const region = group('SELECT region AS k, COUNT(*) AS n FROM services GROUP BY region');
  const plan = group('SELECT plan AS k, COUNT(*) AS n FROM workspaces GROUP BY plan');
  const totals = {
    accounts: db.prepare('SELECT COUNT(*) AS n FROM accounts').get().n,
    workspaces: db.prepare('SELECT COUNT(*) AS n FROM workspaces').get().n,
    services: db.prepare('SELECT COUNT(*) AS n FROM services').get().n,
    monthlyCents: db.prepare('SELECT COALESCE(SUM(monthly_cents), 0) AS n FROM accounts').get().n,
  };
  const since = new Date(Date.now() - 86_400_000).toISOString();
  const fresh = {
    verified24h: db.prepare('SELECT COUNT(*) AS n FROM accounts WHERE verified_at >= ?').get(since).n,
    synced24h: db.prepare('SELECT COUNT(*) AS n FROM accounts WHERE synced_at >= ?').get(since).n,
    stale: db.prepare(
      "SELECT COUNT(*) AS n FROM accounts WHERE synced_at IS NULL OR synced_at < ?",
    ).get(since).n,
  };
  const topAccounts = db.prepare(`
    SELECT id, label, user_email, status, service_count, workspace_count, monthly_cents
    FROM accounts ORDER BY service_count DESC, workspace_count DESC LIMIT 5
  `).all().map((r) => ({
    id: r.id,
    label: r.label,
    email: r.user_email,
    status: r.status,
    services: r.service_count,
    workspaces: r.workspace_count,
    monthlyCents: r.monthly_cents,
  }));
  const recent = listJobs({ page: 1, pageSize: 6 }).items;
  const js = jobStats(7);
  const catalog = getCatalog();
  let dbBytes = 0;
  try {
    dbBytes = fs.statSync(CONFIG.dbFile).size;
  } catch {
    /* missing file */
  }
  return {
    totals,
    accountStatus,
    accountScope,
    serviceStatus,
    region,
    plan,
    fresh,
    topAccounts,
    jobs: {
      days: js.days,
      items: js.items,
      running: js.running,
      recent,
      byStatus: db.prepare('SELECT status, COUNT(*) AS n FROM jobs GROUP BY status').all()
        .reduce((acc, r) => ({ ...acc, [r.status]: r.n }), {}),
    },
    client: {
      requests: clientStats.requests,
      cacheHits: clientStats.cacheHits,
      hitRate: clientStats.requests ? clientStats.cacheHits / clientStats.requests : 0,
      avgMs: clientStats.requests
        ? Math.round(clientStats.totalMs / Math.max(1, clientStats.requests - clientStats.cacheHits))
        : 0,
      errors: clientStats.errors,
      inFlight: clientStats.inFlight,
      cache: cacheStats(),
    },
    catalog: {
      api: catalog.operations.length,
      curated: OPERATIONS.length,
      apiVersion: catalog.version,
      sections: catalog.sections,
    },
    runtime: {
      uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
      dbBytes,
      node: process.version,
      concurrency: CONFIG.defaultConcurrency,
      cacheTtlMs: CONFIG.cacheTtlMs,
      version: CONFIG.version,
    },
  };
}
