import crypto from 'node:crypto';
import { db, settings } from './db.mjs';
import { CONFIG } from './config.mjs';
import {
  signSession, verifySession, verifyPassword, hashPassword, sha256, newId,
} from './lib/crypto.mjs';

const attempts = new Map(); // ip -> { count, resetAt }

export function parseCookies(header = '') {
  const out = {};
  for (const part of String(header).split(';')) {
    const idx = part.indexOf('=');
    if (idx < 0) continue;
    const key = part.slice(0, idx).trim();
    const value = part.slice(idx + 1).trim();
    if (key) out[key] = decodeURIComponent(value);
  }
  return out;
}

export function cookieHeader(name, value, { maxAge = 0, httpOnly = true, sameSite = 'Lax', secure = false } = {}) {
  const parts = [`${name}=${encodeURIComponent(value)}`, 'Path=/', `SameSite=${sameSite}`];
  if (httpOnly) parts.push('HttpOnly');
  if (secure) parts.push('Secure');
  parts.push(`Max-Age=${maxAge}`);
  return parts.join('; ');
}

export function issueSession(res) {
  const token = signSession({ sub: 'manager', exp: Date.now() + CONFIG.sessionTtlMs });
  res.setHeader('Set-Cookie', cookieHeader(CONFIG.cookieName, token, {
    maxAge: Math.floor(CONFIG.sessionTtlMs / 1000),
    secure: CONFIG.cookieSecure,
  }));
}

export function clearSession(res) {
  res.setHeader('Set-Cookie', cookieHeader(CONFIG.cookieName, '', {
    maxAge: 0,
    secure: CONFIG.cookieSecure,
  }));
}

export function checkLoginRate(ip) {
  const now = Date.now();
  const entry = attempts.get(ip);
  if (!entry || entry.resetAt < now) {
    attempts.set(ip, { count: 1, resetAt: now + 60_000 });
    return true;
  }
  entry.count += 1;
  return entry.count <= 10;
}

export function verifyManagerPassword(password) {
  const stored = settings.get('manager_password');
  if (!stored) return false;
  return verifyPassword(password, stored);
}

export function setManagerPassword(next) {
  settings.set('manager_password', hashPassword(next));
}

export function authenticate(req) {
  const cookies = parseCookies(req.headers.cookie || '');
  const session = verifySession(cookies[CONFIG.cookieName]);
  if (session?.sub === 'manager') return { actor: 'manager', via: 'session' };

  const header = req.headers.authorization || '';
  const match = /^Bearer\s+(.+)$/i.exec(header);
  if (match && match[1].startsWith('mgr_')) {
    const hash = sha256(match[1]);
    const row = db.prepare('SELECT * FROM api_keys WHERE key_hash = ?').get(hash);
    if (row) {
      db.prepare('UPDATE api_keys SET last_used_at = ? WHERE id = ?').run(new Date().toISOString(), row.id);
      return { actor: `key:${row.name}`, via: 'api_key', keyId: row.id };
    }
  }
  return null;
}

export function listKeys() {
  return db.prepare('SELECT id, name, key_hint, created_at, last_used_at FROM api_keys ORDER BY created_at DESC')
    .all()
    .map((r) => ({
      id: r.id,
      name: r.name,
      hint: r.key_hint,
      createdAt: r.created_at,
      lastUsedAt: r.last_used_at,
    }));
}

export function createKey(name) {
  const raw = `mgr_${crypto.randomBytes(24).toString('base64url')}`;
  const id = newId('key');
  const now = new Date().toISOString();
  db.prepare('INSERT INTO api_keys (id, name, key_hash, key_hint, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(id, String(name || '未命名密钥').slice(0, 60), sha256(raw), `${raw.slice(0, 10)}…${raw.slice(-4)}`, now);
  return { id, name, key: raw, createdAt: now };
}

export function deleteKey(id) {
  return db.prepare('DELETE FROM api_keys WHERE id = ?').run(id).changes > 0;
}

export function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try {
    const url = new URL(origin);
    return url.host === req.headers.host;
  } catch {
    return false;
  }
}
