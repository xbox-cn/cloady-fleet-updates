/**
 * Curated batch operations. Every entry maps to real Cloady API calls.
 * `target` decides how a job expands account selections into work units:
 *   account  → one unit per account
 *   workspace→ one unit per workspace of each account
 *   service  → one unit per app/service of each account
 */

const ws = (ctx) => encodeURIComponent(ctx.workspaceSlug);
const app = (ctx) => encodeURIComponent(ctx.appSlug);
const base = (ctx) => `/api/workspaces/${ws(ctx)}/apps/${app(ctx)}`;
const wsBase = (ctx) => `/api/workspaces/${ws(ctx)}`;
const envQuery = (ctx) => {
  const q = {};
  if (ctx.env) q.env = ctx.env;
  if (ctx.region) q.region = ctx.region;
  return q;
};

export const GROUPS = ['账户', '工作区', '应用', '运维'];

export const OPERATIONS = [
  /* ---------------------------------------------------------------- account */
  {
    id: 'account.verify',
    label: '账号体检',
    group: '账户',
    target: 'account',
    kind: 'read',
    description: '读取 /api/me，验证令牌是否有效并刷新归属人资料。',
    fields: [],
    steps: () => [{ label: '读取当前用户', method: 'GET', path: '/api/me' }],
  },
  {
    id: 'account.workspaces',
    label: '拉取工作区清单',
    group: '账户',
    target: 'account',
    kind: 'read',
    description: '读取全部工作区及其服务列表。',
    fields: [],
    steps: () => [{ label: '列出工作区', method: 'GET', path: '/api/workspaces' }],
  },
  {
    id: 'account.tokens',
    label: '列出 API 令牌',
    group: '账户',
    target: 'account',
    kind: 'read',
    scope: 'full',
    description: '列出账号下的 API 令牌（需要 full 范围）。',
    fields: [],
    steps: () => [{ label: '列出令牌', method: 'GET', path: '/api/me/tokens' }],
  },
  {
    id: 'account.billing',
    label: '读取账单',
    group: '账户',
    target: 'account',
    kind: 'read',
    description: '读取账户级账单信息。',
    fields: [],
    steps: () => [{ label: '读取账单', method: 'GET', path: '/api/me/billing' }],
  },
  {
    id: 'account.billing_state',
    label: '读取计费状态',
    group: '账户',
    target: 'account',
    kind: 'read',
    description: '读取免费额度、试用与付款状态。',
    fields: [],
    steps: () => [{ label: '读取计费状态', method: 'GET', path: '/api/me/billing-state' }],
  },
  {
    id: 'account.tickets',
    label: '列出工单',
    group: '账户',
    target: 'account',
    kind: 'read',
    description: '读取账号的工单列表。',
    fields: [],
    steps: () => [{ label: '列出工单', method: 'GET', path: '/api/me/tickets' }],
  },
  {
    id: 'account.notifications',
    label: '读取通知偏好',
    group: '账户',
    target: 'account',
    kind: 'read',
    description: '读取邮箱通知设置。',
    fields: [],
    steps: () => [{ label: '读取通知偏好', method: 'GET', path: '/api/me/notifications' }],
  },
  {
    id: 'account.security',
    label: '读取安全状态',
    group: '账户',
    target: 'account',
    kind: 'read',
    description: '读取两步验证与登录安全状态。',
    fields: [],
    steps: () => [{ label: '读取安全状态', method: 'GET', path: '/api/me/security' }],
  },
  {
    id: 'account.ticket_create',
    label: '创建工单',
    group: '账户',
    target: 'account',
    kind: 'write',
    description: '为每个选中账号提交一张支持工单。',
    fields: [
      { key: 'subject', label: '标题', type: 'text', required: true, max: 160, placeholder: '例如：域名证书未签发' },
      { key: 'topic', label: '分类', type: 'select', options: [
        { value: 'general', label: '通用' },
        { value: 'billing', label: '账单' },
        { value: 'technical', label: '技术' },
        { value: 'abuse', label: '滥用' },
      ], default: 'general' },
      { key: 'body', label: '内容', type: 'textarea', required: true, rows: 5, max: 8000, placeholder: '描述问题、复现步骤与期望结果' },
    ],
    steps: (_ctx, p) => [
      {
        label: '创建工单',
        method: 'POST',
        path: '/api/me/tickets',
        body: { subject: p.subject, topic: p.topic || 'general', body: p.body },
      },
    ],
  },

  /* -------------------------------------------------------------- workspace */
  {
    id: 'workspace.billing',
    label: '读取工作区账单',
    group: '工作区',
    target: 'workspace',
    kind: 'read',
    description: '汇总每个工作区的用量与月费。',
    fields: [],
    steps: (ctx) => [{ label: '读取账单', method: 'GET', path: `${wsBase(ctx)}/billing` }],
  },
  {
    id: 'workspace.members',
    label: '列出成员',
    group: '工作区',
    target: 'workspace',
    kind: 'read',
    description: '读取工作区成员与角色。',
    fields: [],
    steps: (ctx) => [{ label: '列出成员', method: 'GET', path: `${wsBase(ctx)}/members` }],
  },
  {
    id: 'workspace.invitations',
    label: '列出待接受邀请',
    group: '工作区',
    target: 'workspace',
    kind: 'read',
    description: '读取尚未接受的成员邀请。',
    fields: [],
    steps: (ctx) => [{ label: '列出邀请', method: 'GET', path: `${wsBase(ctx)}/invitations` }],
  },
  {
    id: 'workspace.invite',
    label: '发送成员邀请',
    group: '工作区',
    target: 'workspace',
    kind: 'write',
    scope: 'full',
    description: '向每个选中工作区发送一封邀请邮件。',
    fields: [
      { key: 'email', label: '邮箱', type: 'text', required: true, placeholder: 'name@example.com' },
      { key: 'role', label: '角色', type: 'select', options: [
        { value: 'viewer', label: 'viewer' },
        { value: 'developer', label: 'developer' },
        { value: 'admin', label: 'admin' },
      ], default: 'developer' },
    ],
    steps: (ctx, p) => [
      {
        label: '发送邀请',
        method: 'POST',
        path: `${wsBase(ctx)}/invitations`,
        body: { email: p.email, role: p.role },
      },
    ],
  },
  {
    id: 'workspace.domains',
    label: '列出工作区域名',
    group: '工作区',
    target: 'workspace',
    kind: 'read',
    description: '读取工作区绑定与注册的域名。',
    fields: [],
    steps: (ctx) => [{ label: '列域名', method: 'GET', path: `${wsBase(ctx)}/domains` }],
  },
  {
    id: 'workspace.volumes',
    label: '列出卷与文件系统',
    group: '工作区',
    target: 'workspace',
    kind: 'read',
    description: '读取工作区全部卷与服务文件系统。',
    fields: [],
    steps: (ctx) => [{ label: '列出卷', method: 'GET', path: `${wsBase(ctx)}/volumes` }],
  },
  {
    id: 'workspace.integrations',
    label: '列出集成',
    group: '工作区',
    target: 'workspace',
    kind: 'read',
    description: '读取 GitHub 等集成的连接状态。',
    fields: [],
    steps: (ctx) => [{ label: '列出集成', method: 'GET', path: `${wsBase(ctx)}/integrations` }],
  },
  {
    id: 'workspace.monitor',
    label: '工作区健康巡检',
    group: '工作区',
    target: 'workspace',
    kind: 'read',
    description: '读取工作区服务的在线率与健康状态。',
    fields: [],
    steps: (ctx) => [{ label: '健康巡检', method: 'GET', path: `${wsBase(ctx)}/monitor` }],
  },
  {
    id: 'workspace.deploy',
    label: '从 Git 新建应用',
    group: '工作区',
    target: 'workspace',
    kind: 'write',
    description: '按同一份 Git 源在多个工作区创建应用。',
    fields: [
      { key: 'repoUrl', label: '仓库地址', type: 'text', required: true, placeholder: 'https://github.com/user/repo.git' },
      { key: 'branch', label: '分支', type: 'text', default: 'main' },
      { key: 'subdir', label: '子目录', type: 'text', placeholder: 'apps/web（可空）' },
      { key: 'name', label: '应用名', type: 'text', max: 80, placeholder: '可空，默认取仓库名' },
      { key: 'region', label: '区域', type: 'text', required: true, placeholder: '从 /api/regions 获取，例如 us-east' },
      { key: 'env', label: '环境', type: 'select', options: [
        { value: 'production', label: 'production' },
        { value: 'preview', label: 'preview' },
        { value: 'development', label: 'development' },
      ], default: 'production' },
      { key: 'port', label: '端口', type: 'number', min: 1, max: 65535 },
      { key: 'buildCmd', label: '构建命令', type: 'text', placeholder: 'npm run build' },
      { key: 'startCmd', label: '启动命令', type: 'text', placeholder: 'npm start' },
      { key: 'values', label: '环境变量', type: 'textarea', rows: 4, placeholder: 'KEY=VALUE，每行一个；值可用引号包裹' },
      { key: 'secretKeys', label: '加密键', type: 'text', placeholder: '用逗号分隔，需包含在环境变量中' },
    ],
    steps: (ctx, p) => {
      const values = parseEnvLines(p.values);
      const secretKeys = String(p.secretKeys || '')
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      const body = {
        region: p.region,
        env: p.env || 'production',
        source: {
          type: 'git',
          repoUrl: p.repoUrl,
          branch: p.branch || 'main',
          ...(p.subdir ? { subdir: p.subdir } : {}),
        },
      };
      if (p.name) body.name = p.name;
      if (p.port) body.port = Number(p.port);
      if (p.buildCmd) body.buildCmd = p.buildCmd;
      if (p.startCmd) body.startCmd = p.startCmd;
      if (Object.keys(values).length) body.values = values;
      if (secretKeys.length) body.secretKeys = secretKeys.filter((k) => k in values);
      return [{ label: '创建应用', method: 'POST', path: `${wsBase(ctx)}/deploy`, body }];
    },
  },

  /* ---------------------------------------------------------------- service */
  {
    id: 'app.redeploy',
    label: '重新部署',
    group: '应用',
    target: 'service',
    kind: 'write',
    description: '对选中应用触发 redeploy。',
    fields: [],
    steps: (ctx) => [
      { label: '重新部署', method: 'POST', path: `${base(ctx)}/redeploy`, query: envQuery(ctx) },
    ],
  },
  {
    id: 'app.status',
    label: '设置运行状态',
    group: '应用',
    target: 'service',
    kind: 'write',
    description: '批量启动、停止或标记应用状态。停止会中断服务。',
    fields: [
      { key: 'status', label: '目标状态', type: 'select', required: true, options: [
        { value: 'running', label: 'running · 运行' },
        { value: 'stopped', label: 'stopped · 停止' },
        { value: 'degraded', label: 'degraded · 降级' },
        { value: 'error', label: 'error · 错误' },
      ], default: 'stopped' },
    ],
    steps: (ctx, p) => [
      {
        label: `设置状态 → ${p.status}`,
        method: 'PATCH',
        path: `${base(ctx)}`,
        query: envQuery(ctx),
        body: { status: p.status },
      },
    ],
  },
  {
    id: 'app.rename',
    label: '重命名应用',
    group: '应用',
    target: 'service',
    kind: 'write',
    description: '修改应用显示名称（slug 不变，URL 不受影响）。',
    fields: [{ key: 'name', label: '新名称', type: 'text', required: true, max: 80 }],
    steps: (ctx, p) => [
      {
        label: '重命名',
        method: 'PATCH',
        path: `${base(ctx)}`,
        query: envQuery(ctx),
        body: { name: p.name },
      },
    ],
  },
  {
    id: 'app.scale',
    label: '调整资源规格',
    group: '应用',
    target: 'service',
    kind: 'write',
    description: '修改 CPU / 内存配额（小数或整数核）。',
    fields: [
      { key: 'cpu', label: 'CPU', type: 'number', min: 0.1, step: 0.1, placeholder: '例如 0.5' },
      { key: 'memory', label: '内存', type: 'number', min: 0.1, step: 0.1, placeholder: '例如 0.5' },
    ],
    steps: (ctx, p) => {
      const scale = {};
      if (p.cpu !== '' && p.cpu != null) scale.cpu = Number(p.cpu);
      if (p.memory !== '' && p.memory != null) scale.memory = Number(p.memory);
      return [
        {
          label: '调整规格',
          method: 'PATCH',
          path: `${base(ctx)}`,
          query: envQuery(ctx),
          body: { scale },
        },
      ];
    },
  },
  {
    id: 'app.delete',
    label: '删除应用',
    group: '应用',
    target: 'service',
    kind: 'destructive',
    danger: true,
    description: '永久删除应用及其数据，不可恢复。执行前需二次确认。',
    fields: [],
    steps: (ctx) => [
      { label: '删除应用', method: 'DELETE', path: `${base(ctx)}`, query: envQuery(ctx) },
    ],
  },
  {
    id: 'app.deploys',
    label: '列出部署记录',
    group: '应用',
    target: 'service',
    kind: 'read',
    description: '读取每个应用的部署历史。',
    fields: [],
    steps: (ctx) => [
      { label: '部署记录', method: 'GET', path: `${base(ctx)}/deploys`, query: envQuery(ctx) },
    ],
  },
  {
    id: 'app.rollback',
    label: '回滚到指定部署',
    group: '应用',
    target: 'service',
    kind: 'write',
    description: '对选中应用执行指定 deployId 的回滚。',
    fields: [{ key: 'deployId', label: '部署 ID', type: 'text', required: true }],
    steps: (ctx, p) => [
      {
        label: `回滚 → ${p.deployId}`,
        method: 'POST',
        path: `${base(ctx)}/deploys/${encodeURIComponent(p.deployId)}/rollback`,
        query: envQuery(ctx),
      },
    ],
  },
  {
    id: 'app.vars.list',
    label: '列出环境变量',
    group: '应用',
    target: 'service',
    kind: 'read',
    description: '读取每个应用的环境变量与密钥键名。',
    fields: [],
    steps: (ctx) => [
      { label: '环境变量', method: 'GET', path: `${base(ctx)}/vars`, query: envQuery(ctx) },
    ],
  },
  {
    id: 'app.vars.import',
    label: '导入环境变量',
    group: '应用',
    target: 'service',
    kind: 'write',
    description: '批量写入变量；已存在的键会被跳过，不会覆盖。',
    fields: [
      { key: 'entries', label: '变量清单', type: 'textarea', required: true, rows: 7, placeholder: 'DATABASE_URL=postgres://…\nLOG_LEVEL=info' },
    ],
    steps: (ctx, p) => {
      const entries = parseEnvEntries(p.entries);
      return [
        {
          label: `导入 ${entries.length} 个变量`,
          method: 'POST',
          path: `${base(ctx)}/vars/import`,
          query: envQuery(ctx),
          body: { entries },
        },
      ];
    },
  },
  {
    id: 'app.vars.upsert',
    label: '覆盖 / 新建变量',
    group: '应用',
    target: 'service',
    kind: 'write',
    description: '按 key 精确写入：已存在则更新，不存在则创建。',
    fields: [
      { key: 'entries', label: '变量清单', type: 'textarea', required: true, rows: 7, placeholder: 'LOG_LEVEL=debug' },
      { key: 'isSecret', label: '标记为密钥', type: 'checkbox', default: false },
    ],
    run: async ({ call, ctx, params }) => {
      const entries = parseEnvEntries(params.entries);
      const existing = await call('GET', `${base(ctx)}/vars`, undefined, envQuery(ctx));
      if (!existing.ok) return existing;
      const byKey = new Map((existing.data?.vars || []).map((v) => [v.key, v]));
      let last = existing;
      const report = { created: 0, updated: 0 };
      for (const entry of entries) {
        const hit = byKey.get(entry.key);
        if (hit) {
          last = await call('PATCH', `${base(ctx)}/vars/${encodeURIComponent(hit.id)}`, {
            value: entry.value,
            ...(params.isSecret ? { isSecret: true } : {}),
          }, envQuery(ctx));
          if (!last.ok) return { ...last, data: { ...last.data, report } };
          report.updated += 1;
        } else {
          last = await call('POST', `${base(ctx)}/vars`, {
            key: entry.key,
            value: entry.value,
            isSecret: Boolean(params.isSecret),
          }, envQuery(ctx));
          if (!last.ok) return { ...last, data: { ...last.data, report } };
          report.created += 1;
        }
      }
      return { ...last, ok: true, status: 200, data: { report } };
    },
  },
  {
    id: 'app.domains.list',
    label: '列出应用域名',
    group: '应用',
    target: 'service',
    kind: 'read',
    description: '读取每个应用绑定的域名与证书状态。',
    fields: [],
    steps: (ctx) => [
      { label: '列出域名', method: 'GET', path: `${base(ctx)}/domains`, query: envQuery(ctx) },
    ],
  },
  {
    id: 'app.domains.add',
    label: '绑定域名',
    group: '应用',
    target: 'service',
    kind: 'write',
    description: '把同一批 host 绑定到每个选中应用。域名所有权需已由 DNS 验证。',
    fields: [
      { key: 'hosts', label: '域名', type: 'textarea', required: true, rows: 3, placeholder: 'example.com\nwww.example.com' },
      { key: 'primary', label: '首个设为主域名', type: 'checkbox', default: false },
    ],
    run: async ({ call, ctx, params }) => {
      const hosts = parseLines(params.hosts);
      let last = null;
      for (let i = 0; i < hosts.length; i += 1) {
        last = await call('POST', `${base(ctx)}/domains`, {
          host: hosts[i],
          ...(params.primary && i === 0 ? { isPrimary: true } : {}),
        }, envQuery(ctx));
        if (!last.ok) return last;
      }
      return last || { ok: true, status: 200, data: { domains: [] } };
    },
  },
  {
    id: 'app.domains.remove',
    label: '解绑域名',
    group: '应用',
    target: 'service',
    kind: 'destructive',
    description: '按 host 查找并删除应用域名。',
    fields: [
      { key: 'hosts', label: '域名', type: 'textarea', required: true, rows: 3, placeholder: 'example.com' },
    ],
    run: async ({ call, ctx, params }) => {
      const targets = new Set(parseLines(params.hosts).map((h) => h.toLowerCase()));
      const listed = await call('GET', `${base(ctx)}/domains`, undefined, envQuery(ctx));
      if (!listed.ok) return listed;
      const matches = (listed.data?.domains || []).filter((d) => targets.has(String(d.host).toLowerCase()));
      if (!matches.length) {
        return { ok: false, status: 404, data: { error: { code: 'not_found', message: '该应用没有匹配的域名' } } };
      }
      let last = listed;
      for (const domain of matches) {
        last = await call('DELETE', `${base(ctx)}/domains/${encodeURIComponent(domain.id)}`, undefined, envQuery(ctx));
        if (!last.ok) return last;
      }
      return { ...last, ok: true, status: 200, data: { removed: matches.map((d) => d.host) } };
    },
  },
  {
    id: 'app.backups.list',
    label: '列出备份',
    group: '应用',
    target: 'service',
    kind: 'read',
    description: '读取托管备份与最近备份点。',
    fields: [],
    steps: (ctx) => [
      { label: '列出备份', method: 'GET', path: `${base(ctx)}/backups`, query: envQuery(ctx) },
    ],
  },
  {
    id: 'app.services',
    label: '列出子服务',
    group: '应用',
    target: 'service',
    kind: 'read',
    description: '读取 compose 子服务、状态与端口。',
    fields: [],
    steps: (ctx) => [
      { label: '列出子服务', method: 'GET', path: `${base(ctx)}/services`, query: envQuery(ctx) },
    ],
  },
  {
    id: 'app.logs',
    label: '抓取服务日志',
    group: '运维',
    target: 'service',
    kind: 'read',
    description: '拉取最近 200 行日志（不带 SSE 的 JSON 快照）。',
    fields: [
      { key: 'component', label: '子服务', type: 'text', placeholder: '留空自动取第一个子服务' },
    ],
    run: async ({ call, ctx, params }) => {
      const component = params.component || ctx.subServices?.[0]?.name;
      if (!component) {
        return { ok: false, status: 400, data: { error: { code: 'missing_component', message: '该应用没有可用的子服务' } } };
      }
      return call(
        'GET',
        `${base(ctx)}/services/${encodeURIComponent(component)}/logs`,
        undefined,
        envQuery(ctx),
      );
    },
  },
  {
    id: 'app.metrics',
    label: '抓取指标快照',
    group: '运维',
    target: 'service',
    kind: 'read',
    description: '读取应用指标快照（CPU、内存、请求）。',
    fields: [],
    steps: (ctx) => [
      { label: '指标快照', method: 'GET', path: `${base(ctx)}/metrics`, query: envQuery(ctx) },
    ],
  },
  {
    id: 'app.exec',
    label: '远程执行命令',
    group: '运维',
    target: 'service',
    kind: 'destructive',
    danger: true,
    description: '在容器内执行 shell 命令。高风险，执行前确认目标与命令。',
    fields: [
      { key: 'component', label: '子服务', type: 'text', placeholder: '留空自动取第一个子服务' },
      { key: 'command', label: '命令', type: 'textarea', required: true, rows: 4, placeholder: 'ls -la /app' },
      { key: 'timeoutMs', label: '超时 (ms)', type: 'number', min: 1000, max: 300000, default: 30000 },
    ],
    run: async ({ call, ctx, params }) => {
      const component = params.component || ctx.subServices?.[0]?.name;
      if (!component) {
        return { ok: false, status: 400, data: { error: { code: 'missing_component', message: '该应用没有可用的子服务' } } };
      }
      return call('POST', `${base(ctx)}/exec`, {
        component,
        command: params.command,
        timeoutMs: Number(params.timeoutMs || 30000),
      }, envQuery(ctx));
    },
  },
  {
    id: 'app.ssh',
    label: '创建 SSH 会话',
    group: '运维',
    target: 'service',
    kind: 'write',
    description: '为每个应用申请 SSH 会话凭据。',
    fields: [],
    steps: (ctx) => [
      { label: '创建 SSH 会话', method: 'POST', path: `${base(ctx)}/ssh/session`, query: envQuery(ctx) },
    ],
  },
];

export const OPERATION_MAP = new Map(OPERATIONS.map((op) => [op.id, op]));

export function publicOperation(op) {
  return {
    id: op.id,
    label: op.label,
    group: op.group,
    target: op.target,
    kind: op.kind,
    danger: Boolean(op.danger),
    description: op.description,
    scope: op.scope || null,
    fields: op.fields || [],
  };
}

/* ---------------------------------------------------------------- parsing */

export function parseLines(text) {
  return String(text || '')
    .split(/[\n,]/)
    .map((s) => s.trim())
    .filter((s) => s && !s.startsWith('#'));
}

export function parseEnvEntries(text) {
  const entries = [];
  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1);
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue;
    entries.push({ key, value });
    if (entries.length >= 500) break;
  }
  return entries;
}

export function parseEnvLines(text) {
  return Object.fromEntries(parseEnvEntries(text).map((e) => [e.key, e.value]));
}
