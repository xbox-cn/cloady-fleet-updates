import fs from 'node:fs';
import path from 'node:path';

const specPath = path.join(import.meta.dirname, 'openapi.json');
const spec = JSON.parse(fs.readFileSync(specPath, 'utf8'));

const SECTION_LABELS = {
  me: '账户',
  workspaces: '工作区',
  apps: '应用',
  deploys: '部署',
  vars: '环境变量',
  services: '服务',
  domains: '域名',
  dns: 'DNS',
  volumes: '存储',
  integrations: '集成',
  billing: '计费',
  members: '成员',
  invitations: '邀请',
  monitor: '监控',
  traces: '链路追踪',
  prometheus: '指标',
  loki: '日志',
  sso: '单点登录',
  import: '迁移导入',
  deploy: '部署',
  uploads: '上传',
  images: '镜像',
  registry: '镜像',
  templates: '模板',
  regions: '平台',
  health: '平台',
  slugCheck: '平台',
  inspect: '平台',
  support: '支持',
  ai: 'AI',
  tickets: '工单',
  security: '安全',
  notifications: '通知',
  status: '状态页',
  alerts: '告警',
  channels: '通知渠道',
  browser: '浏览器监控',
  tracing: '追踪',
  git: 'Git',
  db: '数据库',
  database: '数据库',
  exec: '远程执行',
  ssh: 'SSH',
  backups: '备份',
  keys: '密钥',
  engine: '数据库引擎',
  jobs: '后台任务',
  mail: '邮件',
  usage: '用量',
  runtime: '运行时',
};

function sectionOf(pathname) {
  const parts = pathname.replace(/^\/api\//, '').split('/');
  // Skip resource identifiers to find the first semantic segment.
  for (const part of parts) {
    if (part.startsWith('{')) continue;
    if (part === 'apps' || part === 'workspaces') continue;
    if (SECTION_LABELS[part]) return part;
  }
  return parts.find((p) => !p.startsWith('{')) || 'platform';
}

function queryInfo(params = []) {
  return params
    .filter((p) => p.in === 'query')
    .map((p) => {
      const schema = p.schema || {};
      const ref = schema.$ref ? schema.$ref.split('/').pop() : null;
      return {
        name: p.name,
        required: Boolean(p.required),
        type: schema.type || (ref ? 'string' : 'string'),
        enum: Array.isArray(schema.enum) ? schema.enum : resolveEnum(ref),
        description: p.description || '',
      };
    });
}

function resolveEnum(ref) {
  if (!ref) return null;
  const node = spec.components?.schemas?.[ref];
  return Array.isArray(node?.enum) ? node.enum : null;
}

const OPERATIONS = [];
const MATCHERS = [];

for (const [pathname, methods] of Object.entries(spec.paths)) {
  for (const [method, op] of Object.entries(methods)) {
    if (!['get', 'post', 'put', 'patch', 'delete'].includes(method)) continue;
    const params = op.parameters || [];
    const pathParams = params.filter((p) => p.in === 'path').map((p) => p.name);
    const requestBody = Boolean(op.requestBody?.content?.['application/json']);
    const section = sectionOf(pathname);
    OPERATIONS.push({
      id: op.operationId || `${method}_${pathname}`,
      method: method.toUpperCase(),
      path: pathname,
      summary: op.summary || '',
      description: (op.description || '').slice(0, 400),
      section,
      sectionLabel: SECTION_LABELS[section] || '平台',
      pathParams,
      queryParams: queryInfo(params),
      hasBody: requestBody,
      pathOnly: pathParams.length === 0,
    });

    const pattern = new RegExp(
      `^${pathname.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\\\{[^}]+\\\}/g, '[^/]+')}$`,
    );
    MATCHERS.push({ method: method.toUpperCase(), pattern, template: pathname, operationId: op.operationId });
  }
}

OPERATIONS.sort((a, b) => a.sectionLabel.localeCompare(b.sectionLabel, 'zh') || a.path.localeCompare(b.path));

const SECTIONS = [...new Map(OPERATIONS.map((o) => [o.section, o.sectionLabel])).entries()]
  .map(([key, label]) => ({ key, label, count: OPERATIONS.filter((o) => o.section === key).length }))
  .sort((a, b) => b.count - a.count);

export function getCatalog() {
  return { operations: OPERATIONS, sections: SECTIONS, version: spec.info?.version || 'unknown' };
}

export function isAllowedRequest(method, pathname) {
  const m = String(method || 'GET').toUpperCase();
  if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(m)) return false;
  if (!pathname.startsWith('/api/')) return false;
  if (pathname.includes('..') || pathname.includes('//')) return false;
  const hit = MATCHERS.find((entry) => entry.method === m && entry.pattern.test(pathname));
  if (!hit) return false;
  if (hit.operationId === 'getHealth') {
    return m === 'GET';
  }
  return true;
}

export function operationById(id) {
  return OPERATIONS.find((o) => o.id === id) || null;
}
