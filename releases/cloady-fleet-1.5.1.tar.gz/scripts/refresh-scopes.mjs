/**
 * Re-detect scopes for stored accounts using the Cloady API.
 * Usage: DATA_DIR=/data/cloady-fleet/data node scripts/refresh-scopes.mjs
 */
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
process.env.DATA_DIR = process.env.DATA_DIR || path.join(root, 'backend', 'data');

const { db } = await import('../backend/src/db.mjs');
const { getAccountRow, refreshAccountScope } = await import('../backend/src/accounts.mjs');

const rows = db.prepare('SELECT id, label FROM accounts ORDER BY created_at').all();
for (const row of rows) {
  try {
    const result = await refreshAccountScope(getAccountRow(row.id));
    console.log(JSON.stringify({
      account: row.label,
      previous: result.previous,
      scope: result.scope,
      source: result.source,
      role: result.role || null,
    }));
  } catch (error) {
    console.log(JSON.stringify({ account: row.label, error: error.message }));
  }
}
console.log(`checked ${rows.length} account(s)`);
db.close();
