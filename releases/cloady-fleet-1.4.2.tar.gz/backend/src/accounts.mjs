import { db, tx, json, audit } from './db.mjs';
import { encryptSecret, decryptSecret, newId, maskToken, sha256 } from './lib/crypto.mjs';
import { cachedGet, errorOf } from './lib/cloady.mjs';

export const IMPORT_WATCH_INTERVAL_MINUTES = 3;
export const IMPORT_WATCH_WINDOW_MINUTES = 60;

let facetsCache = null;

function invalidateFacets() {
  facetsCache = null;
}

const SELECT = `
  SELECT id, label, token_enc, token_hint, token_hash, scope, workspace_hint, notes, tags,
         user_id, user_email, user_name, user_image, status, status_code, last_error,
         workspace_count, service_count, monthly_cents, plan_summary,
         watch_until, watch_next_at, watch_last_at, watch_rounds,
         created_at, updated_at, verified_at, synced_at
  FROM accounts
`;

export function toPublic(row) {
  if (!row) return null;
  const watchUntilMs = Date.parse(row.watch_until || '');
  return {
    id: row.id,
    label: row.label,
    tokenHint: row.token_hint,
    scope: row.scope,
    workspaceHint: row.workspace_hint,
    notes: row.notes,
    tags: json(row.tags, []),
    user: {
      id: row.user_id,
      email: row.user_email,
      name: row.user_name,
      image: row.user_image,
    },
    status: row.status,
    statusCode: row.status_code,
    lastError: row.last_error,
    counts: { workspaces: row.workspace_count, services: row.service_count },
    monthlyCents: row.monthly_cents,
    planSummary: row.plan_summary,
    watch: {
      active: Number.isFinite(watchUntilMs) && watchUntilMs > Date.now(),
      until: row.watch_until || null,
      nextAt: row.watch_next_at || null,
      lastAt: row.watch_last_at || null,
      rounds: Number(row.watch_rounds || 0),
    },
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    verifiedAt: row.verified_at,
    syncedAt: row.synced_at,
  };
}

export function getAccountRow(id) {
  return db.prepare(`${SELECT} WHERE id = ?`).get(id);
}

export function getAccountToken(row) {
  if (!row) throw new Error('account missing');
  return decryptSecret(row.token_enc);
}

export function existingAccountIds(ids = []) {
  const unique = [...new Set(ids.filter(Boolean))];
  if (!unique.length) return [];
  const found = new Set();
  const chunkSize = 500;
  for (let i = 0; i < unique.length; i += chunkSize) {
    const chunk = unique.slice(i, i + chunkSize);
    const rows = db.prepare(`SELECT id FROM accounts WHERE id IN (${chunk.map(() => '?').join(',')})`).all(...chunk);
    for (const row of rows) found.add(row.id);
  }
  return unique.filter((id) => found.has(id));
}

export function listAccounts({ query = '', status = '', scope = '', tag = '', page = 1, pageSize = 20 } = {}) {
  const where = [];
  const params = [];
  const q = String(query || '').trim();
  if (q) {
    where.push('(label LIKE ? OR user_email LIKE ? OR user_name LIKE ? OR token_hint LIKE ? OR workspace_hint LIKE ? OR notes LIKE ?)');
    const like = `%${q}%`;
    params.push(like, like, like, like, like, like);
  }
  if (status) {
    where.push('status = ?');
    params.push(status);
  }
  if (scope) {
    where.push('scope = ?');
    params.push(scope);
  }
  if (tag) {
    where.push('tags LIKE ?');
    params.push(`%"${tag}"%`);
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS n FROM accounts ${whereSql}`).get(...params).n;
  const size = Math.max(1, Math.min(100, Number(pageSize) || 20));
  const offset = (Math.max(1, Number(page) || 1) - 1) * size;
  const rows = db.prepare(`${SELECT} ${whereSql} ORDER BY created_at DESC LIMIT ? OFFSET ?`)
    .all(...params, size, offset);
  return anon({
    items: rows.map(toPublic),
    total,
    page: Math.max(1, Number(page) || 1),
    pageSize: size,
    facets: accountFacets(),
  });
}

function anon(v) {
  return v;
}

export function accountFacets({ fresh = false } = {}) {
  if (!fresh && facetsCache && Date.now() - facetsCache.at < 10_000) return facetsCache.value;
  const status = Object.fromEntries(
    db.prepare('SELECT status, COUNT(*) AS n FROM accounts GROUP BY status').all().map((r) => [r.status, r.n]),
  );
  const scope = Object.fromEntries(
    db.prepare('SELECT scope, COUNT(*) AS n FROM accounts GROUP BY scope').all().map((r) => [r.scope, r.n]),
  );
  const tags = {};
  for (const row of db.prepare('SELECT tags FROM accounts').all()) {
    for (const tag of json(row.tags, [])) tags[tag] = (tags[tag] || 0) + 1;
  }
  const total = db.prepare('SELECT COUNT(*) AS n FROM accounts').get().n;
  const value = { status, scope, tags, total };
  facetsCache = { at: Date.now(), value };
  return value;
}

export function normalizeToken(raw) {
  let token = String(raw || '').trim();
  token = token.replace(/^["'`]+|["'`]+$/g, '');
  if (/^bearer\s+/i.test(token)) token = token.replace(/^bearer\s+/i, '');
  return token.trim();
}

export function validateToken(token) {
  if (!token) return '令牌为空';
  if (/\s/.test(token)) return '令牌包含空白字符';
  if (token.length < 16) return '令牌长度异常（至少 16 个字符）';
  if (token.length > 400) return '令牌过长';
  if (!/^[A-Za-z0-9_.\-]+$/.test(token)) return '令牌包含非法字符';
  return null;
}

export function importAccounts(entries, actor) {
  const result = { imported: [], duplicates: 0, invalid: [] };
  const insert = db.prepare(`
    INSERT INTO accounts (
      id, label, token_enc, token_hint, token_hash, scope, workspace_hint, notes, tags,
      status, watch_until, watch_next_at, created_by, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'unknown', ?, ?, ?, ?, ?)
  `);
  const createdAt = Date.now();
  const now = new Date(createdAt).toISOString();
  const watchUntil = new Date(createdAt + IMPORT_WATCH_WINDOW_MINUTES * 60_000).toISOString();
  const watchNext = new Date(createdAt + IMPORT_WATCH_INTERVAL_MINUTES * 60_000).toISOString();
  tx(() => {
    entries.forEach((entry, index) => {
      const token = normalizeToken(entry.token);
      const err = validateToken(token);
      if (err) {
        result.invalid.push({ index, label: entry.label || '', message: err });
        return;
      }
      const hash = sha256(token);
      const exists = db.prepare('SELECT id FROM accounts WHERE token_hash = ?').get(hash);
      if (exists) {
        result.duplicates += 1;
        return;
      }
      const scope = ['read', 'deploy', 'full'].includes(entry.scope) ? entry.scope : 'unknown';
      const tags = Array.isArray(entry.tags)
        ? entry.tags.map((t) => String(t).trim()).filter(Boolean).slice(0, 8)
        : String(entry.tags || '')
            .split(',')
            .map((t) => t.trim())
            .filter(Boolean)
            .slice(0, 8);
      const id = newId('acc');
      insert.run(
        id,
        String(entry.label || '').trim().slice(0, 80) || '未命名账号',
        encryptSecret(token),
        maskToken(token),
        hash,
        scope,
        String(entry.workspaceHint || '').trim() || null,
        String(entry.notes || '').trim().slice(0, 2000),
        JSON.stringify(tags),
        watchUntil,
        watchNext,
        actor || 'manager',
        now,
        now,
      );
      result.imported.push(id);
    });
  });
  if (result.imported.length) {
    audit(actor, 'accounts.import', { count: result.imported.length, duplicates: result.duplicates });
    invalidateFacets();
  }
  return result;
}

export function updateAccount(id, patch, actor) {
  const row = getAccountRow(id);
  if (!row) return null;
  const fields = [];
  const params = [];
  if (typeof patch.label === 'string') {
    fields.push('label = ?');
    params.push(patch.label.trim().slice(0, 80) || row.label);
  }
  if (typeof patch.notes === 'string') {
    fields.push('notes = ?');
    params.push(patch.notes.slice(0, 2000));
  }
  if (typeof patch.workspaceHint === 'string') {
    fields.push('workspace_hint = ?');
    params.push(patch.workspaceHint.trim() || null);
  }
  if (Array.isArray(patch.tags)) {
    fields.push('tags = ?');
    params.push(JSON.stringify(patch.tags.map((t) => String(t).trim()).filter(Boolean).slice(0, 8)));
  }
  if (['read', 'deploy', 'full', 'unknown'].includes(patch.scope)) {
    fields.push('scope = ?');
    params.push(patch.scope);
  }
  if (patch.token) {
    const token = normalizeToken(patch.token);
    const err = validateToken(token);
    if (err) return { error: err };
    const hash = sha256(token);
    const clash = db.prepare('SELECT id FROM accounts WHERE token_hash = ? AND id <> ?').get(hash, id);
    if (clash) return { error: '该令牌已存在于另一个账号' };
    fields.push('token_enc = ?', 'token_hint = ?', 'token_hash = ?', "status = 'unknown'", 'last_error = NULL');
    params.push(encryptSecret(token), maskToken(token), hash);
  }
  if (!fields.length) return toPublic(row);
  fields.push('updated_at = ?');
  params.push(new Date().toISOString());
  db.prepare(`UPDATE accounts SET ${fields.join(', ')} WHERE id = ?`).run(...params, id);
  audit(actor, 'account.update', { id, fields: fields.map((f) => f.split(' ')[0]) });
  invalidateFacets();
  return toPublic(getAccountRow(id));
}

export function deleteAccount(id, actor) {
  const row = getAccountRow(id);
  if (!row) return false;
  db.prepare('DELETE FROM accounts WHERE id = ?').run(id);
  audit(actor, 'account.delete', { id, label: row.label });
  invalidateFacets();
  return true;
}

export function revealToken(id) {
  const row = getAccountRow(id);
  if (!row) return null;
  return getAccountToken(row);
}

/* ------------------------------------------------------------ scope inference */

const ROLE_TO_SCOPE = { owner: 'full', admin: 'full', developer: 'deploy', viewer: 'read' };
const VALID_SCOPES = new Set(['read', 'deploy', 'full']);

function prefixOf(value) {
  return String(value || '')
    .split('…')[0]
    .split('...')[0]
    .trim();
}

/**
 * Determine the real scope of a token.
 * 1. GET /api/me/tokens exposes every token's prefix + scope, so an exact
 *    prefix match identifies the current token without guessing.
 * 2. Otherwise, the caller's viewerRole in an accessible workspace maps to
 *    the effective role ceiling: owner/admin -> full, developer -> deploy,
 *    viewer -> read.
 */
export async function inferScope(token, workspaceSlugs = []) {
  const seen = new Set();
  const slugs = (workspaceSlugs || [])
    .map((w) => (typeof w === 'string' ? w : w?.slug))
    .filter((slug) => slug && !seen.has(slug) && seen.add(slug))
    .slice(0, 4);

  try {
    const res = await cachedGet({ token, path: '/api/me/tokens', ttlMs: 0, bypass: true });
    if (res.ok) {
      const tokens = Array.isArray(res.data?.tokens) ? res.data.tokens : [];
      const match = tokens.find((item) => {
        const prefix = prefixOf(item.prefix);
        return prefix.length >= 6 && token.startsWith(prefix);
      });
      const chosen = match
        || (tokens.length === 1 && VALID_SCOPES.has(tokens[0].scope) ? tokens[0] : null);
      if (chosen && VALID_SCOPES.has(chosen.scope)) {
        return { scope: chosen.scope, source: 'token-prefix', role: null, tokenName: chosen.name || null };
      }
    } else if (res.status === 401) {
      return { scope: 'unknown', source: 'token-prefix', role: null, status: 401 };
    }
  } catch {
    /* fall through to role inference */
  }

  for (const slug of slugs) {
    try {
      const res = await cachedGet({
        token,
        path: `/api/workspaces/${encodeURIComponent(slug)}/members`,
        ttlMs: 0,
        bypass: true,
      });
      if (res.ok) {
        const role = String(res.data?.viewerRole || '');
        const scope = ROLE_TO_SCOPE[role];
        if (scope) return { scope, source: 'viewer-role', role, tokenName: null };
      }
      if (res.status === 401) {
        return { scope: 'unknown', source: 'viewer-role', role: null, status: 401 };
      }
    } catch {
      /* try the next workspace */
    }
  }

  return { scope: 'unknown', source: 'none', role: null };
}

export async function refreshAccountScope(row) {
  const token = getAccountToken(row);
  let slugs = db.prepare('SELECT slug FROM workspaces WHERE account_id = ?').all(row.id).map((w) => w.slug);
  if (!slugs.length) {
    const ws = await cachedGet({ token, path: '/api/workspaces', ttlMs: 0, bypass: true });
    if (ws.ok) slugs = (ws.data?.workspaces || []).map((w) => w.slug);
  }
  const inferred = await inferScope(token, slugs);
  const now = new Date().toISOString();
  if (inferred.scope !== 'unknown') {
    db.prepare('UPDATE accounts SET scope = ?, updated_at = ? WHERE id = ?').run(inferred.scope, now, row.id);
    if (row.scope !== inferred.scope) {
      audit('system', 'account.scope_change', {
        id: row.id,
        from: row.scope,
        to: inferred.scope,
        source: inferred.source,
        role: inferred.role || null,
      });
    }
  }
  return {
    ...inferred,
    previous: row.scope,
    scope: inferred.scope === 'unknown' ? row.scope : inferred.scope,
  };
}

/* ------------------------------------------------------------------- sync */

function planSummaryOf(workspaces) {
  const counts = new Map();
  for (const w of workspaces) {
    const key = w.plan || 'unknown';
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  return [...counts.entries()].map(([k, n]) => `${k}×${n}`).join(' · ');
}

export async function fetchAccountSnapshot(row, { bypass = true } = {}) {
  const token = getAccountToken(row);
  const me = await cachedGet({ token, path: '/api/me', ttlMs: 0, bypass });
  if (!me.ok) {
    return { ok: false, stage: 'me', response: me, error: errorOf(me, '令牌校验失败') };
  }
  const workspaces = await cachedGet({ token, path: '/api/workspaces', ttlMs: 0, bypass });
  if (!workspaces.ok) {
    return { ok: false, stage: 'workspaces', response: workspaces, error: errorOf(workspaces, '工作区读取失败') };
  }
  return { ok: true, me: me.data?.user || null, workspaces: workspaces.data?.workspaces || [] };
}

export function applySnapshot(accountId, snapshot) {
  const now = new Date().toISOString();
  const workspaces = Array.isArray(snapshot.workspaces) ? snapshot.workspaces : [];
  const user = snapshot.me || {};
  let serviceCount = 0;
  let monthly = 0;
  for (const w of workspaces) {
    monthly += Number(w.monthlyCents || 0);
    serviceCount += Array.isArray(w.services) ? w.services.length : 0;
  }
  tx(() => {
    db.prepare(`
      UPDATE accounts SET
        user_id = ?, user_email = ?, user_name = ?, user_image = ?,
        status = 'normal', status_code = 200, last_error = NULL,
        workspace_count = ?, service_count = ?, monthly_cents = ?, plan_summary = ?,
        verified_at = ?, synced_at = ?, updated_at = ?
      WHERE id = ?
    `).run(
      user.id || null,
      user.email || null,
      user.name || null,
      user.image || null,
      workspaces.length,
      serviceCount,
      monthly,
      planSummaryOf(workspaces),
      now,
      now,
      now,
      accountId,
    );

    db.prepare('DELETE FROM workspaces WHERE account_id = ?').run(accountId);
    db.prepare('DELETE FROM services WHERE account_id = ?').run(accountId);

    const wsInsert = db.prepare(`
      INSERT INTO workspaces (account_id, slug, name, plan, monthly_cents, plan_ends_at, paywall,
        trial_available, usage_json, hues_json, icon_url, synced_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const svcInsert = db.prepare(`
      INSERT INTO services (account_id, workspace_slug, slug, name, env, region, status, type, uptime,
        endpoints_json, limits_json, scale_json, source_json, sub_services_json, blocked, synced_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const w of workspaces) {
      wsInsert.run(
        accountId,
        String(w.slug || ''),
        String(w.name || w.slug || ''),
        w.plan || null,
        Number(w.monthlyCents || 0),
        w.planEndsAt || null,
        w.paywall ? 1 : 0,
        w.trialAvailable ? 1 : 0,
        JSON.stringify(w.usage || {}),
        JSON.stringify(w.hues || []),
        w.iconUrl || null,
        now,
      );
      for (const s of Array.isArray(w.services) ? w.services : []) {
        svcInsert.run(
          accountId,
          String(w.slug || ''),
          String(s.slug || ''),
          String(s.name || s.slug || ''),
          s.env || null,
          s.region || null,
          s.status || null,
          s.type || null,
          s.uptime || null,
          JSON.stringify(s.endpoints || []),
          JSON.stringify(s.limits || {}),
          JSON.stringify(s.scale || {}),
          JSON.stringify(s.source || {}),
          JSON.stringify(s.subServices || []),
          s.blocked || null,
          now,
        );
      }
    }
  });
  return { workspaces: workspaces.length, services: serviceCount };
}

export function markAccountVerified(accountId, user = {}) {
  const now = new Date().toISOString();
  db.prepare(`
    UPDATE accounts SET user_id = ?, user_email = ?, user_name = ?, user_image = ?,
      status = 'normal', status_code = 200, last_error = NULL, verified_at = ?, updated_at = ?
    WHERE id = ?
  `).run(
    user.id || null, user.email || null, user.name || null, user.image || null,
    now, now, accountId,
  );
}

export function recordAccountError(accountId, error) {
  const now = new Date().toISOString();
  const status = error.status === 401 ? 'banned' : 'unknown';
  db.prepare(`
    UPDATE accounts SET status = ?, status_code = ?, last_error = ?, updated_at = ?
    WHERE id = ?
  `).run(status, error.status || 0, `${error.code}: ${error.message}`.slice(0, 500), now, accountId);
}

export async function verifyAccount(row) {
  const token = getAccountToken(row);
  const res = await cachedGet({ token, path: '/api/me', ttlMs: 0, bypass: true });
  const now = new Date().toISOString();
  if (!res.ok) {
    const error = errorOf(res, '令牌校验失败');
    recordAccountError(row.id, error);
    return { ok: false, error };
  }
  const user = res.data?.user || {};
  let slugs = db.prepare('SELECT slug FROM workspaces WHERE account_id = ?').all(row.id).map((w) => w.slug);
  if (!slugs.length) {
    const ws = await cachedGet({ token, path: '/api/workspaces', ttlMs: 0, bypass: true });
    if (ws.ok) slugs = (ws.data?.workspaces || []).map((w) => w.slug);
  }
  const inferred = await inferScope(token, slugs);
  const scope = inferred.scope === 'unknown' ? null : inferred.scope;
  db.prepare(`
    UPDATE accounts SET user_id = ?, user_email = ?, user_name = ?, user_image = ?,
      status = 'normal', status_code = 200, last_error = NULL, scope = COALESCE(?, scope),
      verified_at = ?, updated_at = ?
    WHERE id = ?
  `).run(user.id || null, user.email || null, user.name || null, user.image || null, scope, now, now, row.id);
  return { ok: true, user, scope: scope || row.scope, scopeInference: inferred };
}

export async function syncAccount(row) {
  const snapshot = await fetchAccountSnapshot(row, { bypass: true });
  if (!snapshot.ok) {
    recordAccountError(row.id, snapshot.error);
    return snapshot;
  }
  const inferred = await inferScope(getAccountToken(row), (snapshot.workspaces || []).map((w) => w.slug));
  const applied = applySnapshot(row.id, snapshot);
  if (inferred.scope !== 'unknown') {
    db.prepare('UPDATE accounts SET scope = ?, updated_at = ? WHERE id = ?')
      .run(inferred.scope, new Date().toISOString(), row.id);
  }
  return { ok: true, scope: inferred.scope === 'unknown' ? row.scope : inferred.scope, scopeInference: inferred, ...applied };
}

/* -------------------------------------------------------------- inventory */

export function getAccountDetail(id) {
  const row = getAccountRow(id);
  if (!row) return null;
  const workspaces = db
    .prepare('SELECT * FROM workspaces WHERE account_id = ? ORDER BY name COLLATE NOCASE')
    .all(id)
    .map((w) => ({
      slug: w.slug,
      name: w.name,
      plan: w.plan,
      monthlyCents: w.monthly_cents,
      planEndsAt: w.plan_ends_at,
      paywall: Boolean(w.paywall),
      trialAvailable: Boolean(w.trial_available),
      usage: json(w.usage_json, {}),
      hues: json(w.hues_json, []),
      iconUrl: w.icon_url,
      syncedAt: w.synced_at,
    }));
  const services = db
    .prepare('SELECT * FROM services WHERE account_id = ? ORDER BY workspace_slug, name COLLATE NOCASE')
    .all(id)
    .map(serviceToPublic);
  return { ...toPublic(row), workspaces, services };
}

export function serviceToPublic(s) {
  return {
    accountId: s.account_id,
    workspaceSlug: s.workspace_slug,
    slug: s.slug,
    name: s.name,
    env: s.env,
    region: s.region,
    status: s.status,
    type: s.type,
    uptime: s.uptime,
    endpoints: json(s.endpoints_json, []),
    limits: json(s.limits_json, {}),
    scale: json(s.scale_json, {}),
    source: json(s.source_json, {}),
    subServices: json(s.sub_services_json, []),
    blocked: s.blocked,
    syncedAt: s.synced_at,
  };
}

export function listInventory({
  query = '',
  accountId = '',
  workspace = '',
  status = '',
  region = '',
  page = 1,
  pageSize = 20,
} = {}) {
  const where = [];
  const params = [];
  const q = String(query || '').trim();
  if (q) {
    where.push('(s.name LIKE ? OR s.slug LIKE ? OR s.workspace_slug LIKE ? OR a.label LIKE ? OR a.user_email LIKE ?)');
    const like = `%${q}%`;
    params.push(like, like, like, like, like);
  }
  if (accountId) {
    where.push('s.account_id = ?');
    params.push(accountId);
  }
  if (workspace) {
    where.push('s.workspace_slug = ?');
    params.push(workspace);
  }
  if (status) {
    where.push('s.status = ?');
    params.push(status);
  }
  if (region) {
    where.push('s.region = ?');
    params.push(region);
  }
  const from = 'FROM services s JOIN accounts a ON a.id = s.account_id';
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS n ${from} ${whereSql}`).get(...params).n;
  const size = Math.max(1, Math.min(100, Number(pageSize) || 20));
  const offset = (Math.max(1, Number(page) || 1) - 1) * size;
  const rows = db.prepare(`
    SELECT s.*, a.label AS account_label, a.user_email AS account_email
    ${from} ${whereSql}
    ORDER BY s.status = 'running' DESC, s.workspace_slug, s.name COLLATE NOCASE
    LIMIT ? OFFSET ?
  `).all(...params, size, offset);
  const facets = {
    status: Object.fromEntries(
      db.prepare('SELECT status, COUNT(*) AS n FROM services GROUP BY status').all().map((r) => [r.status, r.n]),
    ),
    region: Object.fromEntries(
      db.prepare('SELECT region, COUNT(*) AS n FROM services GROUP BY region').all().map((r) => [r.region, r.n]),
    ),
    accounts: db.prepare('SELECT COUNT(*) AS n FROM accounts').get().n,
    workspaces: db.prepare('SELECT COUNT(*) AS n FROM workspaces').get().n,
    services: db.prepare('SELECT COUNT(*) AS n FROM services').get().n,
  };
  return {
    items: rows.map((r) => ({
      ...serviceToPublic(r),
      accountLabel: r.account_label,
      accountEmail: r.account_email,
    })),
    total,
    page: Math.max(1, Number(page) || 1),
    pageSize: size,
    facets,
  };
}

export function ownedServices(accountId, workspaceSlug, appSlug, env) {
  let sql = 'SELECT * FROM services WHERE account_id = ?';
  const params = [accountId];
  if (workspaceSlug) {
    sql += ' AND workspace_slug = ?';
    params.push(workspaceSlug);
  }
  if (appSlug) {
    sql += ' AND slug = ?';
    params.push(appSlug);
  }
  if (env) {
    sql += ' AND env = ?';
    params.push(env);
  }
  sql += ' ORDER BY workspace_slug, name';
  return db.prepare(sql).all(...params);
}

export function ownedWorkspaces(accountId, slug) {
  let sql = 'SELECT * FROM workspaces WHERE account_id = ?';
  const params = [accountId];
  if (slug) {
    sql += ' AND slug = ?';
    params.push(slug);
  }
  sql += ' ORDER BY name COLLATE NOCASE';
  return db.prepare(sql).all(...params);
}

export function accountIdByTokenHash(hash) {
  return db.prepare('SELECT id FROM accounts WHERE token_hash = ?').get(hash)?.id || null;
}
