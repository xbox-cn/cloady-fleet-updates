import http from 'node:http';
import fs from 'node:fs';
import {
  CONFIG, log,
} from './config.mjs';
import { db, bootstrapPassword, settings, audit } from './db.mjs';
import {
  sendJson, sendText, sendEmpty, readJson, queryObject, serveStatic,
  applySecurityHeaders, HttpError,
} from './lib/http.mjs';
import {
  authenticate, issueSession, clearSession, checkLoginRate, verifyManagerPassword,
  setManagerPassword, listKeys, createKey, deleteKey, sameOrigin,
} from './auth.mjs';
import {
  listAccounts, getAccountRow, getAccountDetail, importAccounts, updateAccount, deleteAccount,
  revealToken, verifyAccount, syncAccount, refreshAccountScope, listInventory, serviceToPublic, toPublic,
  ownedServices, ownedWorkspaces,
} from './accounts.mjs';
import { rawRequest, cachedGet, errorOf, stats as clientStats, clearCache, cacheStats } from './lib/cloady.mjs';
import { getCatalog, isAllowedRequest } from './catalog.mjs';
import { OPERATIONS, publicOperation } from './operations.mjs';
import {
  createJob, getJob, listJobs, getJobItems, getJobLogs, cancelJob, retryFailed, retryItem,
  jobStats, jobBus, initJobs,
} from './jobs.mjs';
import { overview } from './stats.mjs';
import { getAutomationStatus, initAutomation, runAutomationNow, updateAutomation } from './automation.mjs';
import { initWatch } from './watch.mjs';
import {
  listWorkflows, listWorkflowRuns, getWorkflowRun, startWorkflowRun, cancelWorkflowRun,
  resolveWorkflowBundle, publicBaseFromRequest, initWorkflowRunner,
} from './workflows.mjs';
import { readUpdateStatus, requestUpdate } from './updater.mjs';

bootstrapPassword();
initJobs();
initAutomation();
initWatch();
initWorkflowRunner();

function clientIp(req) {
  const real = req.headers['x-real-ip'];
  const socket = req.socket.remoteAddress || '';
  if (real && (socket === '127.0.0.1' || socket === '::1' || socket === '::ffff:127.0.0.1')) {
    return String(real).slice(0, 64);
  }
  return socket || 'unknown';
}

const routes = [];

function route(method, pattern, handler, opts = {}) {
  routes.push({
    method,
    segments: pattern.split('/').filter(Boolean),
    handler,
    public: Boolean(opts.public),
    raw: Boolean(opts.raw),
  });
}

function matchRoute(method, pathname) {
  const parts = pathname.split('/').filter(Boolean);
  for (const entry of routes) {
    if (entry.method !== method) continue;
    if (entry.segments.length !== parts.length) continue;
    const params = {};
    let ok = true;
    for (let i = 0; i < parts.length; i += 1) {
      const seg = entry.segments[i];
      if (seg.startsWith(':')) params[seg.slice(1)] = decodeURIComponent(parts[i]);
      else if (seg !== parts[i]) {
        ok = false;
        break;
      }
    }
    if (ok) return { entry, params };
  }
  return null;
}

/* ------------------------------------------------------------------ auth */

route('GET', '/api/health', async (req, res) => {
  sendJson(res, 200, {
    ok: true,
    name: 'Cloady Fleet',
    version: CONFIG.version,
    uptimeSec: Math.floor(process.uptime()),
  });
}, { public: true });

route('GET', '/api/auth/me', async (req, res) => {
  const auth = authenticate(req);
  sendJson(res, 200, {
    authenticated: Boolean(auth),
    actor: auth?.actor || null,
    via: auth?.via || null,
    version: CONFIG.version,
    apiVersion: getCatalog().version,
  });
}, { public: true });

route('POST', '/api/auth/login', async (req, res, { body }) => {
  const ip = clientIp(req);
  if (!checkLoginRate(ip)) {
    throw new HttpError(429, 'rate_limited', '尝试过于频繁，请一分钟后再试');
  }
  if (!sameOrigin(req)) throw new HttpError(403, 'bad_origin', '来源不合法');
  const password = String(body.password || '');
  if (!password) throw new HttpError(400, 'bad_body', '请输入管理密码');
  if (!verifyManagerPassword(password)) {
    audit('anonymous', 'auth.login_failed', { ip });
    throw new HttpError(401, 'unauthorized', '密码错误');
  }
  issueSession(res);
  audit('manager', 'auth.login', { ip });
  sendJson(res, 200, { ok: true, actor: 'manager' });
}, { public: true });

route('POST', '/api/auth/logout', async (req, res) => {
  clearSession(res);
  sendJson(res, 200, { ok: true });
}, { public: true });

route('POST', '/api/auth/password', async (req, res, { body, auth }) => {
  const current = String(body.current || '');
  const next = String(body.next || '');
  if (!verifyManagerPassword(current)) throw new HttpError(401, 'unauthorized', '当前密码错误');
  if (next.length < 8) throw new HttpError(400, 'weak_password', '新密码至少 8 位');
  setManagerPassword(next);
  audit(auth.actor, 'auth.password_change', {});
  issueSession(res);
  sendJson(res, 200, { ok: true });
});

/* --------------------------------------------------------------- overview */

route('GET', '/api/overview', async (req, res) => {
  sendJson(res, 200, overview());
});

route('GET', '/api/client/stats', async (req, res) => {
  sendJson(res, 200, {
    ...clientStats,
    avgMs: clientStats.requests
      ? Math.round(clientStats.totalMs / Math.max(1, clientStats.requests - clientStats.cacheHits))
      : 0,
    cache: cacheStats(),
  });
});

route('POST', '/api/cache/clear', async (req, res, { auth }) => {
  clearCache();
  audit(auth.actor, 'cache.clear', {});
  sendJson(res, 200, { ok: true });
});

/* --------------------------------------------------------------- accounts */

route('GET', '/api/accounts', async (req, res, { url }) => {
  const q = queryObject(url);
  sendJson(res, 200, listAccounts({
    query: q.query,
    status: q.status,
    scope: q.scope,
    tag: q.tag,
    page: q.page,
    pageSize: q.pageSize,
  }));
});

route('POST', '/api/accounts/import', async (req, res, { body, auth }) => {
  let entries = Array.isArray(body.entries) ? body.entries : [];
  if (!entries.length && Array.isArray(body.tokens)) {
    entries = body.tokens.map((token, index) => ({ label: `导入账号 ${index + 1}`, token }));
  }
  if (!entries.length) throw new HttpError(400, 'bad_body', '没有可导入的令牌');
  if (entries.length > 500) throw new HttpError(400, 'too_many', '单次最多导入 500 个账号');
  const result = importAccounts(entries, auth.actor);
  let job = null;
  if (result.imported.length) {
    const useSync = Boolean(body.sync);
    job = createJob({
      kind: useSync ? 'sync' : 'verify',
      accountIds: result.imported,
      actor: auth.actor,
      label: `${useSync ? '导入后同步' : '导入后测活'} · ${result.imported.length} 个账号`,
    }).job;
  }
  sendJson(res, 201, { ...result, job });
});

route('POST', '/api/accounts', async (req, res, { body, auth }) => {
  const result = importAccounts([body], auth.actor);
  if (!result.imported.length) {
    throw new HttpError(400, 'bad_body', result.invalid[0]?.message || '令牌重复或非法');
  }
  const row = getAccountRow(result.imported[0]);
  const job = createJob({
    kind: 'verify',
    accountIds: result.imported,
    actor: auth.actor,
    label: '导入后测活 · 1 个账号',
  }).job;
  sendJson(res, 201, { account: toPublic(row), job });
});

route('POST', '/api/accounts/sync', async (req, res, { body, auth }) => {
  let ids = Array.isArray(body.ids) ? body.ids : [];
  if (!ids.length && body.all) {
    ids = db.prepare('SELECT id FROM accounts ORDER BY created_at DESC').all().map((r) => r.id);
  }
  if (!ids.length) throw new HttpError(400, 'bad_body', '至少选择一个账号');
  const result = createJob({
    kind: 'sync',
    accountIds: ids,
    actor: auth.actor,
    label: body.all ? `同步全部账号 · ${ids.length} 个` : undefined,
  });
  sendJson(res, 202, result);
});

route('GET', '/api/accounts/:id', async (req, res, { params }) => {
  const detail = getAccountDetail(params.id);
  if (!detail) throw new HttpError(404, 'not_found', '账号不存在');
  sendJson(res, 200, { account: detail });
});

route('PATCH', '/api/accounts/:id', async (req, res, { params, body, auth }) => {
  const result = updateAccount(params.id, body, auth.actor);
  if (!result) throw new HttpError(404, 'not_found', '账号不存在');
  if (result.error) throw new HttpError(400, 'bad_token', result.error);
  sendJson(res, 200, { account: result });
});

route('DELETE', '/api/accounts/:id', async (req, res, { params, body, auth }) => {
  if (body?.confirm !== true) throw new HttpError(400, 'confirm_required', '删除账号需要 confirm: true');
  const ok = deleteAccount(params.id, auth.actor);
  if (!ok) throw new HttpError(404, 'not_found', '账号不存在');
  sendJson(res, 200, { ok: true });
});

route('POST', '/api/accounts/:id/reveal', async (req, res, { params, body, auth }) => {
  if (!verifyManagerPassword(String(body.password || ''))) {
    throw new HttpError(401, 'unauthorized', '管理密码错误');
  }
  const token = revealToken(params.id);
  if (!token) throw new HttpError(404, 'not_found', '账号不存在');
  audit(auth.actor, 'account.reveal', { id: params.id });
  sendJson(res, 200, { token }, { 'Cache-Control': 'no-store' });
});

route('POST', '/api/accounts/:id/verify', async (req, res, { params }) => {
  const row = getAccountRow(params.id);
  if (!row) throw new HttpError(404, 'not_found', '账号不存在');
  const result = await verifyAccount(row);
  sendJson(res, result.ok ? 200 : 400, {
    ok: result.ok,
    account: toPublic(getAccountRow(params.id)),
    error: result.error || null,
  });
});

route('POST', '/api/accounts/:id/scope', async (req, res, { params, auth }) => {
  const row = getAccountRow(params.id);
  if (!row) throw new HttpError(404, 'not_found', '账号不存在');
  const result = await refreshAccountScope(row);
  audit(auth.actor, 'account.scope_refresh', {
    id: params.id,
    from: result.previous,
    to: result.scope,
    source: result.source,
    role: result.role || null,
  });
  sendJson(res, 200, { ...result, account: toPublic(getAccountRow(params.id)) });
});

route('POST', '/api/accounts/:id/sync', async (req, res, { params }) => {
  const row = getAccountRow(params.id);
  if (!row) throw new HttpError(404, 'not_found', '账号不存在');
  const result = await syncAccount(row);
  sendJson(res, result.ok ? 200 : 400, {
    ok: result.ok,
    account: toPublic(getAccountRow(params.id)),
    ...result,
  });
});

/* -------------------------------------------------------------- inventory */

route('GET', '/api/inventory', async (req, res, { url }) => {
  const q = queryObject(url);
  sendJson(res, 200, listInventory({
    query: q.query,
    accountId: q.accountId,
    workspace: q.workspace,
    status: q.status,
    region: q.region,
    page: q.page,
    pageSize: q.pageSize,
  }));
});

route('GET', '/api/inventory/app', async (req, res, { url }) => {
  const q = queryObject(url);
  if (!q.accountId || !q.workspace || !q.app) {
    throw new HttpError(400, 'bad_body', '缺少 accountId / workspace / app');
  }
  const row = getAccountRow(q.accountId);
  if (!row) throw new HttpError(404, 'not_found', '账号不存在');
  const service = ownedServices(q.accountId, q.workspace, q.app)[0];
  if (!service) throw new HttpError(404, 'not_found', '应用不存在');
  const workspace = ownedWorkspaces(q.accountId, q.workspace)[0];
  sendJson(res, 200, {
    account: toPublic(row),
    workspace: workspace ? {
      slug: workspace.slug,
      name: workspace.name,
      plan: workspace.plan,
      monthlyCents: workspace.monthly_cents,
      planEndsAt: workspace.plan_ends_at,
      usage: JSON.parse(workspace.usage_json || '{}'),
      hues: JSON.parse(workspace.hues_json || '[]'),
      iconUrl: workspace.icon_url,
      syncedAt: workspace.synced_at,
    } : null,
    service: service ? { ...serviceToPublic(service), accountLabel: row.label } : null,
  });
});

route('GET', '/api/regions', async (req, res, { url }) => {
  const q = queryObject(url);
  const row = q.accountId ? getAccountRow(q.accountId) : db.prepare('SELECT * FROM accounts LIMIT 1').get();
  if (!row) throw new HttpError(400, 'no_account', '先添加一个账号');
  const token = revealToken(row.id);
  const result = await cachedGet({ token, path: '/api/regions', ttlMs: 300_000 });
  sendJson(res, result.status || 502, result.data ?? { error: errorOf(result) });
});

/* --------------------------------------------------------------- catalog */

route('GET', '/api/catalog', async (req, res) => {
  const catalog = getCatalog();
  sendJson(res, 200, {
    curated: OPERATIONS.map(publicOperation),
    sections: catalog.sections,
    api: catalog.operations,
    apiVersion: catalog.version,
  });
});

/* ------------------------------------------------------------------ jobs */

route('GET', '/api/jobs/stats', async (req, res) => {
  sendJson(res, 200, jobStats(7));
});

route('GET', '/api/jobs', async (req, res, { url }) => {
  const q = queryObject(url);
  sendJson(res, 200, listJobs({ page: q.page, pageSize: q.pageSize, status: q.status, kind: q.kind, query: q.query }));
});

route('GET', '/api/workflows', async (req, res) => {
  sendJson(res, 200, { items: listWorkflows() });
});

route('GET', '/api/workflow-runs', async (req, res, { url }) => {
  const q = queryObject(url);
  sendJson(res, 200, listWorkflowRuns({
    page: q.page,
    pageSize: q.pageSize,
    workflow: q.workflow,
    status: q.status,
    query: q.query,
  }));
});

route('GET', '/api/workflow-runs/:id', async (req, res, { params }) => {
  const run = getWorkflowRun(params.id);
  if (!run) throw new HttpError(404, 'run_not_found', '任务不存在');
  sendJson(res, 200, { run });
});

route('POST', '/api/workflows/:id/runs', async (req, res, { params, body, auth }) => {
  const run = await startWorkflowRun({
    workflowId: params.id,
    accountId: String(body.accountId || ''),
    workspaceSlug: body.workspaceSlug ? String(body.workspaceSlug) : '',
    appSlug: body.appSlug ? String(body.appSlug) : '',
    component: body.component ? String(body.component) : '',
    params: body.params || {},
    actor: auth.actor,
    publicBase: publicBaseFromRequest(req),
  });
  sendJson(res, 202, { run });
});

route('POST', '/api/workflow-runs/:id/cancel', async (req, res, { params, auth }) => {
  const run = await cancelWorkflowRun(params.id, auth.actor);
  sendJson(res, 202, { run });
});

route('GET', '/api/workflows/:id/bundle', async (req, res, { params, url }) => {
  const runId = String(url.searchParams.get('run') || '');
  const token = String(url.searchParams.get('token') || '');
  const found = resolveWorkflowBundle(params.id, runId, token);
  if (!found) throw new HttpError(404, 'bundle_not_found', '源码包不存在或令牌已失效');
  const stat = fs.statSync(found.file);
  res.writeHead(200, {
    'Content-Type': 'application/gzip',
    'Content-Length': String(stat.size),
    'Cache-Control': 'no-store',
    'Content-Disposition': `attachment; filename="${found.workflow.bundleFile}"`,
  });
  fs.createReadStream(found.file).pipe(res);
}, { public: true });

route('POST', '/api/jobs', async (req, res, { body, auth }) => {
  const kind = body.kind || 'operation';
  let accountIds = Array.isArray(body.accountIds) ? body.accountIds : [];
  if (body.all) {
    accountIds = db.prepare('SELECT id FROM accounts ORDER BY created_at').all().map((row) => row.id);
  }
  if (!accountIds.length) throw new HttpError(400, 'no_accounts', '至少选择一个账号');
  if (kind === 'operation') {
    const result = createJob({
      kind,
      operationId: body.operationId,
      accountIds,
      params: body.params || {},
      filters: body.filters || {},
      options: body.options || {},
      label: body.label,
      actor: auth.actor,
    });
    return sendJson(res, 202, result);
  }
  if (kind === 'sync') {
    const result = createJob({ kind, accountIds, actor: auth.actor, label: body.label });
    return sendJson(res, 202, result);
  }
  if (kind === 'raw') {
    const method = String(body.params?.method || 'GET').toUpperCase();
    const templatePath = String(body.params?.path || '');
    const concrete = templatePath.replace(/\{[A-Za-z]+\}/g, 'x');
    if (!isAllowedRequest(method, concrete)) {
      throw new HttpError(400, 'bad_path', '该路径不在 Cloady API 白名单内');
    }
    const result = createJob({
      kind,
      accountIds,
      params: { ...body.params, method },
      filters: body.filters || {},
      options: body.options || {},
      label: body.label,
      actor: auth.actor,
    });
    return sendJson(res, 202, result);
  }
  throw new HttpError(400, 'bad_kind', '未知任务类型');
});

route('GET', '/api/jobs/:id', async (req, res, { params, url }) => {
  const job = getJob(params.id);
  if (!job) throw new HttpError(404, 'not_found', '任务不存在');
  const q = queryObject(url);
  const items = getJobItems(params.id, { page: q.page, pageSize: q.pageSize, status: q.status });
  const logs = getJobLogs(params.id, 200);
  sendJson(res, 200, { job, items, logs });
});

route('GET', '/api/jobs/:id/items', async (req, res, { params, url }) => {
  const q = queryObject(url);
  sendJson(res, 200, getJobItems(params.id, { page: q.page, pageSize: q.pageSize, status: q.status }));
});

route('GET', '/api/jobs/:id/logs', async (req, res, { params }) => {
  sendJson(res, 200, { logs: getJobLogs(params.id, 300) });
});

route('GET', '/api/jobs/:id/stream', async (req, res, { params }) => {
  const job = getJob(params.id);
  if (!job) throw new HttpError(404, 'not_found', '任务不存在');
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  const write = (event) => {
    if (res.writableEnded) return;
    res.write(`event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`);
  };
  write({ type: 'snapshot', job });
  const listener = (event) => {
    if (event.jobId === params.id) write(event);
  };
  jobBus.on('event', listener);
  const heartbeat = setInterval(() => {
    if (!res.writableEnded) res.write(': ping\n\n');
  }, 15_000);
  req.on('close', () => {
    clearInterval(heartbeat);
    jobBus.off('event', listener);
  });
}, { raw: true });

route('POST', '/api/jobs/:id/cancel', async (req, res, { params, auth }) => {
  const ok = cancelJob(params.id);
  audit(auth.actor, 'job.cancel', { id: params.id, ok });
  if (!ok) throw new HttpError(409, 'not_running', '任务不在运行中');
  sendJson(res, 200, { ok: true });
});

route('POST', '/api/jobs/:id/retry', async (req, res, { params, auth }) => {
  const result = retryFailed(params.id, auth.actor);
  sendJson(res, 202, result);
});

route('POST', '/api/jobs/:id/items/:itemId/retry', async (req, res, { params, auth }) => {
  const result = retryItem(params.id, Number(params.itemId), auth.actor);
  sendJson(res, 202, result);
});

route('GET', '/api/jobs/:id/export', async (req, res, { params }) => {
  const job = getJob(params.id);
  if (!job) throw new HttpError(404, 'not_found', '任务不存在');
  const rows = [];
  for (let page = 1; ; page += 1) {
    const chunk = getJobItems(params.id, { page, pageSize: 200 });
    rows.push(...chunk.items);
    if (page * chunk.pageSize >= chunk.total) break;
  }
  const header = ['target', 'account_id', 'workspace', 'app', 'status', 'http', 'duration_ms', 'error_code', 'error_message'];
  const esc = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;
  const lines = [header.join(',')];
  for (const row of rows) {
    lines.push([
      row.targetLabel, row.accountId, row.workspaceSlug, row.appSlug, row.status,
      row.httpStatus, row.durationMs, row.errorCode, row.errorMessage,
    ].map(esc).join(','));
  }
  sendText(res, 200, `\uFEFF${lines.join('\r\n')}`, 'text/csv; charset=utf-8', {
    'Content-Disposition': `attachment; filename="job-${params.id}.csv"`,
  });
});

/* ----------------------------------------------------------------- proxy */

route('POST', '/api/proxy', async (req, res, { body, auth }) => {
  const method = String(body.method || 'GET').toUpperCase();
  const pathname = String(body.path || '');
  if (!pathname.startsWith('/api/') || pathname.includes('..')) {
    throw new HttpError(400, 'bad_path', '路径必须是 /api/ 下的相对路径');
  }
  if (!isAllowedRequest(method, pathname.replace(/\{[A-Za-z]+\}/g, 'x'))) {
    throw new HttpError(400, 'bad_path', '该路径不在 Cloady API 白名单内');
  }
  if (/\{[A-Za-z]+\}/.test(pathname)) {
    throw new HttpError(400, 'bad_path', '请把路径中的占位符替换为实际值');
  }
  const row = getAccountRow(String(body.accountId || ''));
  if (!row) throw new HttpError(404, 'not_found', '账号不存在');
  const token = revealToken(row.id);
  let result;
  try {
    if (method === 'GET') {
      result = await cachedGet({
        token,
        path: pathname,
        query: body.query || {},
        ttlMs: Math.max(0, Number(body.ttlMs ?? CONFIG.cacheTtlMs)),
        bypass: Boolean(body.bypass),
      });
    } else {
      result = await rawRequest({
        token,
        method,
        path: pathname,
        query: body.query || {},
        body: body.body ?? undefined,
      });
    }
  } catch (err) {
    throw new HttpError(502, err.code || 'network_error', err.message);
  }
  sendJson(res, 200, {
    ok: result.ok,
    status: result.status,
    data: result.data,
    durationMs: Math.round(result.durationMs),
    cached: Boolean(result.cached),
    error: result.ok ? null : errorOf(result),
  });
});

/* -------------------------------------------------------------- settings */

route('GET', '/api/settings', async (req, res, { auth }) => {
  const catalog = getCatalog();
  let dbBytes = 0;
  try {
    dbBytes = fs.statSync(CONFIG.dbFile).size;
  } catch {
    /* noop */
  }
  sendJson(res, 200, {
    runtime: {
      version: CONFIG.version,
      node: process.version,
      uptimeSec: Math.floor(process.uptime()),
      baseUrl: CONFIG.baseUrl,
      dataDir: CONFIG.dataDir,
      dbBytes,
      apiVersion: catalog.version,
    },
    tuning: {
      batchConcurrency: Number(settings.get('batch_concurrency') || CONFIG.defaultConcurrency),
      perAccountConcurrency: CONFIG.perAccountConcurrency,
      cacheTtlMs: Number(settings.get('cache_ttl_ms') || CONFIG.cacheTtlMs),
      maxSockets: CONFIG.maxSockets,
      defaultConcurrency: CONFIG.defaultConcurrency,
      defaultCacheTtlMs: CONFIG.cacheTtlMs,
    },
    keys: listKeys(),
    actor: auth.actor,
    via: auth.via,
  });
});

route('PATCH', '/api/settings', async (req, res, { body, auth }) => {
  if (body.batchConcurrency != null) {
    const n = Math.max(1, Math.min(32, Number(body.batchConcurrency) || 8));
    settings.set('batch_concurrency', n);
  }
  if (body.cacheTtlMs != null) {
    const n = Math.max(0, Math.min(600_000, Number(body.cacheTtlMs) || 0));
    settings.set('cache_ttl_ms', n);
  }
  audit(auth.actor, 'settings.update', body);
  sendJson(res, 200, { ok: true });
});

route('GET', '/api/update', async (req, res) => {
  sendJson(res, 200, readUpdateStatus());
});

route('POST', '/api/update/request', async (req, res, { auth }) => {
  const result = requestUpdate();
  audit(auth.actor, 'update.request', result);
  sendJson(res, 202, { ...result, status: readUpdateStatus() });
});

route('GET', '/api/settings/keys', async (req, res) => {
  sendJson(res, 200, { keys: listKeys() });
});

route('POST', '/api/settings/keys', async (req, res, { body, auth }) => {
  const key = createKey(body.name);
  audit(auth.actor, 'settings.key_create', { id: key.id });
  sendJson(res, 201, { key });
});

route('DELETE', '/api/settings/keys/:id', async (req, res, { params, auth }) => {
  const ok = deleteKey(params.id);
  if (!ok) throw new HttpError(404, 'not_found', '密钥不存在');
  audit(auth.actor, 'settings.key_delete', { id: params.id });
  sendJson(res, 200, { ok: true });
});

route('GET', '/api/export/accounts', async (req, res) => {
  const rows = db.prepare('SELECT * FROM accounts ORDER BY created_at DESC').all();
  const header = ['id', 'label', 'email', 'scope', 'status', 'workspaces', 'services', 'monthly_cents', 'created_at', 'synced_at'];
  const esc = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;
  const lines = [header.join(',')];
  for (const r of rows) {
    lines.push([r.id, r.label, r.user_email, r.scope, r.status, r.workspace_count, r.service_count, r.monthly_cents, r.created_at, r.synced_at].map(esc).join(','));
  }
  sendText(res, 200, `\uFEFF${lines.join('\r\n')}`, 'text/csv; charset=utf-8', {
    'Content-Disposition': 'attachment; filename="cloady-accounts.csv"',
  });
});

route('GET', '/api/automation', async (req, res) => {
  sendJson(res, 200, getAutomationStatus());
});

route('PATCH', '/api/automation', async (req, res, { body, auth }) => {
  const status = updateAutomation(body || {});
  audit(auth.actor, 'automation.update', body || {});
  sendJson(res, 200, status);
});

route('POST', '/api/automation/run', async (req, res, { auth }) => {
  const result = runAutomationNow();
  if (!result.ok) {
    if (result.reason === 'running') throw new HttpError(409, 'running', '已有自动巡检正在执行');
    if (result.reason === 'no_accounts') throw new HttpError(400, 'no_accounts', '还没有可检测的账号');
    throw new HttpError(400, 'no_tasks', '请至少开启自动测活或自动同步');
  }
  audit(auth.actor, 'automation.run_now', { jobId: result.jobId });
  sendJson(res, 202, result);
});

/* ------------------------------------------------------------------ main */

const server = http.createServer(async (req, res) => {
  const started = Date.now();
  applySecurityHeaders(res);
  let url;
  try {
    url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  } catch {
    return sendEmpty(res, 400);
  }
  const pathname = url.pathname;
  const method = req.method || 'GET';

  if (!pathname.startsWith('/api/')) {
    if (pathname.endsWith('.html') || pathname === '/') {
      res.setHeader(
        'Content-Security-Policy',
        "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; font-src 'self' data:; base-uri 'self'; frame-ancestors 'none'",
      );
    }
    return serveStatic(req, res, CONFIG.staticDir);
  }

  const match = matchRoute(method, pathname);
  if (!match) {
    return sendJson(res, 404, { error: { code: 'not_found', message: '路由不存在' } });
  }
  const { entry, params } = match;

  try {
    const auth = authenticate(req);
    if (!entry.public && !auth) {
      throw new HttpError(401, 'unauthorized', '请先登录');
    }
    if (!entry.public && !['GET', 'HEAD'].includes(method) && auth?.via === 'session' && !sameOrigin(req)) {
      throw new HttpError(403, 'bad_origin', '来源不合法');
    }

    let body = {};
    if (!['GET', 'HEAD'].includes(method) && !entry.raw) {
      const type = String(req.headers['content-type'] || '');
      if (type.includes('application/json')) {
        body = await readJson(req);
      }
    }

    await entry.handler(req, res, { params, url, body, auth });
  } catch (err) {
    const status = err instanceof HttpError
      ? err.status
      : err?.name === 'CloadyError' ? 502 : 500;
    const code = err instanceof HttpError ? err.code : err?.code || 'internal';
    if (status >= 500 && !(err instanceof HttpError)) {
      log.error(`${method} ${pathname} failed`, err);
    }
    if (!res.writableEnded) {
      sendJson(res, status, {
        error: {
          code,
          message: err.message || '服务器错误',
          ...(err.details ? { details: err.details } : {}),
        },
      });
    }
  } finally {
    const ms = Date.now() - started;
    if (ms > 400 || pathname.startsWith('/api/jobs')) {
      log.info(`${method} ${pathname} ${res.statusCode} ${ms}ms`);
    }
  }
});

server.requestTimeout = 120_000;
server.headersTimeout = 65_000;
server.keepAliveTimeout = 65_000;

server.listen(CONFIG.port, CONFIG.host, () => {
  log.info(`Cloady Fleet ${CONFIG.version} → http://${CONFIG.host}:${CONFIG.port}`);
  log.info(`API 上游 ${CONFIG.baseUrl} · 并发 ${CONFIG.defaultConcurrency} · 缓存 ${CONFIG.cacheTtlMs}ms`);
  if (!fs.existsSync(CONFIG.staticDir)) {
    log.warn('未找到前端构建产物：先运行 npm run build（开发模式请用 npm run dev）');
  }
});

function shutdown(signal) {
  log.info(`收到 ${signal}，正在关闭…`);
  server.close(() => {
    try {
      db.close();
    } catch {
      /* noop */
    }
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 3_000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
