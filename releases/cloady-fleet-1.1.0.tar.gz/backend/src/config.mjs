import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const here = import.meta.dirname;
export const ROOT = path.resolve(here, '..');
export const PROJECT_ROOT = path.resolve(ROOT, '..');

let appVersion = '1.1.0';
try {
  appVersion = fs.readFileSync(path.join(PROJECT_ROOT, 'VERSION'), 'utf8').trim();
} catch {
  try {
    appVersion = JSON.parse(fs.readFileSync(path.join(PROJECT_ROOT, 'package.json'), 'utf8')).version || appVersion;
  } catch {
    /* keep fallback */
  }
}
export const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.join(ROOT, 'data');

fs.mkdirSync(DATA_DIR, { recursive: true });

export const CONFIG = {
  host: process.env.HOST || '127.0.0.1',
  port: Number(process.env.PORT || 8787),
  baseUrl: (process.env.CLOADY_BASE_URL || 'https://cloady.com').replace(/\/+$/, ''),
  dataDir: DATA_DIR,
  dbFile: path.join(DATA_DIR, 'fleet.db'),
  staticDir: path.join(PROJECT_ROOT, 'frontend', 'dist'),
  sessionTtlMs: 7 * 24 * 3600 * 1000,
  cookieName: 'cf_session',
  cookieSecure: process.env.COOKIE_SECURE === '1',
  defaultConcurrency: Math.max(1, Math.min(32, Number(process.env.BATCH_CONCURRENCY || 8))),
  perAccountConcurrency: Math.max(1, Number(process.env.PER_ACCOUNT_CONCURRENCY || 2)),
  cacheTtlMs: Math.max(0, Number(process.env.CACHE_TTL_MS || 20_000)),
  requestTimeoutMs: Math.max(2_000, Number(process.env.REQUEST_TIMEOUT_MS || 45_000)),
  maxSockets: Math.max(8, Number(process.env.MAX_SOCKETS || 64)),
  logLevel: process.env.LOG_LEVEL || 'info',
  version: appVersion,
};

const secretFile = path.join(DATA_DIR, 'secret.bin');
let secret;
if (fs.existsSync(secretFile)) {
  secret = fs.readFileSync(secretFile);
} else {
  secret = crypto.randomBytes(32);
  fs.writeFileSync(secretFile, secret, { mode: 0o600 });
}
export const SECRET = secret;

/** HKDF-derived AES-256-GCM key for the token vault. */
export const ENC_KEY = Buffer.from(
  crypto.hkdfSync('sha256', SECRET, Buffer.from('cloady-fleet'), Buffer.from('vault-v1'), 32),
);

export const SESSION_KEY = Buffer.from(
  crypto.hkdfSync('sha256', SECRET, Buffer.from('cloady-fleet'), Buffer.from('session-v1'), 32),
);

export const log = {
  info: (...a) => CONFIG.logLevel !== 'silent' && console.log('[fleet]', ...a),
  warn: (...a) => CONFIG.logLevel !== 'silent' && console.warn('[fleet]', ...a),
  error: (...a) => console.error('[fleet]', ...a),
};
