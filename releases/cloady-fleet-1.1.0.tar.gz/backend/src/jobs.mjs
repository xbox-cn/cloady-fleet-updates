import { EventEmitter } from 'node:events';
import { db, tx, json, audit, settings } from './db.mjs';
import { CONFIG, log } from './config.mjs';
import { newId } from './lib/crypto.mjs';
import {
  rawRequest, cachedGet, errorOf, isRetryable, retryDelay, CloadyError,
} from './lib/cloady.mjs';
import { OPERATIONS, OPERATION_MAP, publicOperation } from './operations.mjs';
import {
  getAccountRow, getAccountToken, syncAccount, verifyAccount, ownedServices, ownedWorkspaces,
  markAccountVerified, recordAccountError,
} from './accounts.mjs';

export const jobBus = new EventEmitter();
jobBus.setMaxListeners(200);

const running = new Map(); // jobId -> { cancelled, controller, spec }

/* ------------------------------------------------------------------ util */

function nowIso() {
  return new Date().toISOString();
}

function truncate(value, max = 6_000) {
  const text = JSON.stringify(value ?? null);
  if (text.length <= max) return text;
  return JSON.stringify({ truncated: true, preview: text.slice(0, max) });
}

function publicJob(row, summary) {
  return {
    id: row.id,
    kind: row.kind,
    label: row.label,
    operationId: row.operation_id,
    status: row.status,
    total: row.total,
    done: row.done,
    failed: row.failed,
    skipped: row.skipped,
    processed: row.done + row.failed + row.skipped,
    progress: row.total > 0 ? Math.min(1, (row.done + row.failed + row.skipped) / row.total) : 0,
    createdAt: row.created_at,
    startedAt: row.started_at,
    finishedAt: row.finished_at,
    spec: json(row.spec_json, {}),
    summary: summary ?? json(row.summary_json, null),
  };
}

function publicItem(row, includeResponse = false) {
  const base = {
    id: row.id,
    accountId: row.account_id,
    targetKey: row.target_key,
    targetLabel: row.target_label,
    workspaceSlug: row.workspace_slug,
    appSlug: row.app_slug,
    status: row.status,
    attempts: row.attempts,
    httpStatus: row.http_status,
    durationMs: row.duration_ms,
    errorCode: row.error_code,
    errorMessage: row.error_message,
    createdAt: row.created_at,
    finishedAt: row.finished_at,
  };
  if (includeResponse) base.response = json(row.response_json, null);
  return base;
}

export function getJob(id) {
  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(id);
  return row ? publicJob(row) : null;
}

export function listJobs({ page = 1, pageSize = 20, status = '', kind = '', query = '' } = {}) {
  const where = [];
  const params = [];
  if (status) {
    where.push('status = ?');
    params.push(status);
  }
  if (kind) {
    where.push('kind = ?');
    params.push(kind);
  }
  if (query) {
    where.push('(label LIKE ? OR operation_id LIKE ? OR id LIKE ?)');
    const like = `%${query}%`;
    params.push(like, like, like);
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS n FROM jobs ${whereSql}`).get(...params).n;
  const size = Math.max(1, Math.min(100, Number(pageSize) || 20));
  const offset = (Math.max(1, Number(page) || 1) - 1) * size;
  const rows = db.prepare(`SELECT * FROM jobs ${whereSql} ORDER BY created_at DESC LIMIT ? OFFSET ?`)
    .all(...params, size, offset);
  const counts = Object.fromEntries(
    db.prepare('SELECT status, COUNT(*) AS n FROM jobs GROUP BY status').all().map((r) => [r.status, r.n]),
  );
  return { items: rows.map((r) => publicJob(r)), total, page: Math.max(1, Number(page) || 1), pageSize: size, counts };
}

export function getJobItems(jobId, { page = 1, pageSize = 50, status = '' } = {}) {
  const where = ['job_id = ?'];
  const params = [jobId];
  if (status) {
    where.push('status = ?');
    params.push(status);
  }
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const total = db.prepare(`SELECT COUNT(*) AS n FROM job_items ${whereSql}`).get(...params).n;
  const size = Math.max(1, Math.min(200, Number(pageSize) || 50));
  const offset = (Math.max(1, Number(page) || 1) - 1) * size;
  const rows = db.prepare(`SELECT * FROM job_items ${whereSql} ORDER BY id LIMIT ? OFFSET ?`)
    .all(...params, size, offset);
  return {
    items: rows.map((r) => publicItem(r, pageSize <= 100)),
    total,
    page: Math.max(1, Number(page) || 1),
    pageSize: size,
  };
}

export function getJobLogs(jobId, limit = 300) {
  return db.prepare('SELECT * FROM job_logs WHERE job_id = ? ORDER BY id DESC LIMIT ?').all(jobId, limit)
    .map((r) => ({ id: r.id, at: r.at, level: r.level, message: r.message }))
    .reverse();
}

function emit(jobId, type, payload) {
  jobBus.emit('event', { jobId, type, at: nowIso(), ...payload });
}

function logLine(jobId, level, message) {
  const at = nowIso();
  db.prepare('INSERT INTO job_logs (job_id, at, level, message) VALUES (?, ?, ?, ?)').run(jobId, at, level, message);
  emit(jobId, 'log', { level, message, at });
  if (level === 'error') log.warn(`[job ${jobId}]`, message);
}

function setJob(jobId, fields) {
  const keys = Object.keys(fields);
  if (!keys.length) return;
  db.prepare(`UPDATE jobs SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`)
    .run(...keys.map((k) => fields[k]), jobId);
}

function bumpProgress(jobId, patch = {}) {
  const job = db.prepare('SELECT total, done, failed, skipped, status FROM jobs WHERE id = ?').get(jobId);
  if (!job) return;
  const next = {
    done: job.done + (patch.done || 0),
    failed: job.failed + (patch.failed || 0),
    skipped: job.skipped + (patch.skipped || 0),
  };
  db.prepare('UPDATE jobs SET done = ?, failed = ?, skipped = ? WHERE id = ?')
    .run(next.done, next.failed, next.skipped, jobId);
  emit(jobId, 'progress', {
    status: job.status,
    total: job.total,
    done: next.done,
    failed: next.failed,
    skipped: next.skipped,
    processed: next.done + next.failed + next.skipped,
  });
}

/* --------------------------------------------------------------- creation */

export function createJob({
  kind = 'operation',
  operationId = null,
  accountIds = [],
  params = {},
  filters = {},
  options = {},
  label = null,
  actor = 'manager',
  onlyTargets = null,
}) {
  const ids = [...new Set((accountIds || []).filter(Boolean))];
  if (!ids.length) throw Object.assign(new Error('至少选择一个账号'), { status: 400 });
  const rows = ids.map((id) => getAccountRow(id)).filter(Boolean);
  if (!rows.length) throw Object.assign(new Error('账号不存在'), { status: 404 });

  let op = null;
  if (kind === 'operation') {
    op = OPERATION_MAP.get(operationId);
    if (!op) throw Object.assign(new Error('未知操作'), { status: 400 });
  }
  if (kind === 'raw') {
    if (!params?.path || !params?.method) throw Object.assign(new Error('缺少 API 路径或方法'), { status: 400 });
  }
  const spec = {
    kind,
    operationId,
    accountIds: rows.map((r) => r.id),
    params,
    filters: {
      workspaceSlug: filters.workspaceSlug || null,
      appSlug: filters.appSlug || null,
      env: filters.env || null,
    },
    options: {
      concurrency: Math.max(1, Math.min(32,
        Number(options.concurrency)
        || Number(settings.get('batch_concurrency'))
        || CONFIG.defaultConcurrency)),
      retries: Math.max(0, Math.min(5, Number(options.retries ?? 2))),
      dryRun: Boolean(options.dryRun),
      stopOnError: Boolean(options.stopOnError),
    },
    onlyTargets: onlyTargets || null,
  };
  const id = newId('job');
  const title = label
    || (kind === 'sync' ? '同步账号资产'
      : kind === 'verify' ? '账号测活'
      : kind === 'raw' ? `${params.method} ${params.path}`
        : op ? op.label : '批量任务');
  db.prepare(`
    INSERT INTO jobs (id, kind, label, operation_id, status, total, done, failed, skipped,
      created_by, created_at, spec_json)
    VALUES (?, ?, ?, ?, 'queued', 0, 0, 0, 0, ?, ?, ?)
  `).run(id, kind, title, operationId, actor, nowIso(), JSON.stringify(spec));
  audit(actor, 'job.create', { id, kind, operationId, accounts: spec.accountIds.length });
  queueMicrotask(() => runJob(id).catch((err) => {
    log.error('job crashed', id, err);
    finishJob(id, 'failed', { fatal: err.message });
  }));
  return { id, job: getJob(id) };
}

export function cancelJob(id) {
  const entry = running.get(id);
  const row = db.prepare('SELECT status FROM jobs WHERE id = ?').get(id);
  if (!row) return false;
  if (!entry) {
    if (row.status === 'queued') {
      setJob(id, { status: 'cancelled', finished_at: nowIso() });
      return true;
    }
    return false;
  }
  entry.cancelled = true;
  entry.controller.abort();
  return true;
}

export function retryFailed(id, actor) {
  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(id);
  if (!row) throw Object.assign(new Error('任务不存在'), { status: 404 });
  const spec = json(row.spec_json, {});
  const failed = db.prepare("SELECT * FROM job_items WHERE job_id = ? AND status = 'failed'").all(id);
  if (!failed.length) throw Object.assign(new Error('没有失败的条目'), { status: 400 });
  const onlyTargets = failed.map((f) => ({
    accountId: f.account_id,
    workspaceSlug: f.workspace_slug,
    appSlug: f.app_slug,
    serviceKey: f.target_key,
  }));
  return createJob({
    kind: spec.kind,
    operationId: spec.operationId,
    accountIds: spec.accountIds,
    params: spec.params,
    filters: spec.filters,
    options: { ...spec.options, dryRun: false },
    label: `${row.label}（重试失败项）`,
    actor,
    onlyTargets,
  });
}

/* -------------------------------------------------------------- expansion */

function targetKey(accountId, workspaceSlug, appSlug) {
  return [accountId, workspaceSlug || '', appSlug || ''].join('|');
}

async function ensureInventory(row, jobId) {
  const count = db.prepare('SELECT COUNT(*) AS n FROM workspaces WHERE account_id = ?').get(row.id).n;
  if (count > 0) return true;
  logLine(jobId, 'info', `账号「${row.label}」尚无资产快照，先执行一次同步`);
  const res = await syncAccount(row);
  if (!res.ok) {
    logLine(jobId, 'error', `账号「${row.label}」同步失败：${res.error?.code} ${res.error?.message}`);
    return false;
  }
  return true;
}

async function expandTargets(jobId, spec, op) {
  const targets = [];
  const only = spec.onlyTargets ? new Set(spec.onlyTargets.map((t) => t.serviceKey)) : null;

  for (const accountId of spec.accountIds) {
    const row = getAccountRow(accountId);
    if (!row) continue;
    let kind;
    if (spec.kind === 'sync' || spec.kind === 'verify') kind = 'account';
    else if (spec.kind === 'raw') {
      const rawPath = String(spec.params?.path || '');
      kind = rawPath.includes('{appSlug}') || rawPath.includes('{serviceName}')
        ? 'service'
        : rawPath.includes('{workspaceSlug}') ? 'workspace' : 'account';
    } else {
      kind = op.target;
    }

    if (kind === 'account') {
      targets.push({
        accountId,
        accountLabel: row.label,
        targetKey: targetKey(accountId),
        targetLabel: row.label,
        workspaceSlug: null,
        appSlug: null,
      });
      continue;
    }

    const ready = await ensureInventory(row, jobId);
    if (!ready) {
      targets.push({
        accountId,
        accountLabel: row.label,
        targetKey: targetKey(accountId),
        targetLabel: `${row.label} · 同步失败`,
        workspaceSlug: null,
        appSlug: null,
        preflightError: '同步失败，无法展开资产',
      });
      continue;
    }

    if (kind === 'workspace') {
      const workspaces = ownedWorkspaces(accountId, spec.filters.workspaceSlug);
      if (!workspaces.length) {
        targets.push({
          accountId,
          accountLabel: row.label,
          targetKey: targetKey(accountId),
          targetLabel: `${row.label} · 无匹配工作区`,
          workspaceSlug: null,
          appSlug: null,
          skipped: true,
        });
        continue;
      }
      for (const w of workspaces) {
        targets.push({
          accountId,
          accountLabel: row.label,
          targetKey: targetKey(accountId, w.slug),
          targetLabel: `${row.label} / ${w.name}`,
          workspaceSlug: w.slug,
          appSlug: null,
        });
      }
      continue;
    }

    // service target
    const services = ownedServices(accountId, spec.filters.workspaceSlug, spec.filters.appSlug, spec.filters.env);

    if (!services.length) {
      targets.push({
        accountId,
        accountLabel: row.label,
        targetKey: targetKey(accountId),
        targetLabel: `${row.label} · 无匹配应用`,
        workspaceSlug: null,
        appSlug: null,
        skipped: true,
      });
      continue;
    }
    for (const svc of services) {
      const key = targetKey(accountId, svc.workspace_slug, svc.slug);
      if (only && !only.has(key)) continue;
      targets.push({
        accountId,
        accountLabel: row.label,
        targetKey: key,
        targetLabel: `${row.label} / ${svc.workspace_slug} / ${svc.name}`,
        workspaceSlug: svc.workspace_slug,
        appSlug: svc.slug,
        service: svc,
      });
    }
  }

  if (only) {
    // Keep explicit targets that are no longer present in inventory.
    const seen = new Set(targets.map((t) => t.targetKey));
    for (const t of spec.onlyTargets) {
      if (seen.has(t.serviceKey)) continue;
      targets.push({
        accountId: t.accountId,
        accountLabel: getAccountRow(t.accountId)?.label || t.accountId,
        targetKey: t.serviceKey,
        targetLabel: `${getAccountRow(t.accountId)?.label || t.accountId} / ${t.workspaceSlug || ''} / ${t.appSlug || ''}`,
        workspaceSlug: t.workspaceSlug,
        appSlug: t.appSlug,
        skipped: true,
      });
    }
  }
  return targets;
}

/* -------------------------------------------------------------- execution */

function materializePath(template, ctx) {
  return String(template || '')
    .replace(/\{workspaceSlug\}/g, ctx.workspaceSlug || '')
    .replace(/\{appSlug\}/g, ctx.appSlug || '')
    .replace(/\{serviceName\}/g, ctx.subServices?.[0]?.name || '');
}

function buildOpContext(target, spec, token, controller) {
  const svc = target.service;
  const ctx = {
    accountId: target.accountId,
    workspaceSlug: target.workspaceSlug,
    appSlug: target.appSlug,
    env: spec.filters.env || svc?.env || null,
    region: svc?.region || null,
    subServices: svc ? json(svc.sub_services_json, []) : [],
  };
  const call = async (method, path, body, query) => {
    const opts = {
      token,
      method,
      path,
      query,
      body,
      signal: controller.signal,
      timeoutMs: CONFIG.requestTimeoutMs,
    };
    if (method === 'GET') {
      return cachedGet({ ...opts, ttlMs: 0, bypass: true });
    }
    return rawRequest(opts);
  };
  return { ctx, call };
}

function validateParams(op, params) {
  for (const field of op.fields || []) {
    if (field.type === 'checkbox') continue;
    const value = params?.[field.key];
    if (field.required && (value === undefined || value === null || String(value).trim() === '')) {
      return `缺少必填参数：${field.label}`;
    }
    if (field.type === 'number' && value !== '' && value != null && Number.isNaN(Number(value))) {
      return `参数 ${field.label} 必须是数字`;
    }
  }
  return null;
}

async function executeStep(call, step, signal) {
  return call(step.method, step.path, step.body, step.query);
}

async function runItem(jobId, target, spec, op, controller) {
  const item = db.prepare('SELECT * FROM job_items WHERE job_id = ? AND target_key = ?').get(jobId, target.targetKey);
  if (!item) return;
  const startedAt = Date.now();
  db.prepare("UPDATE job_items SET status = 'running', attempts = 0 WHERE id = ?").run(item.id);
  emit(jobId, 'item', {
    item: { id: item.id, targetKey: target.targetKey, status: 'running', httpStatus: null, durationMs: null },
  });

  if (target.skipped) {
    db.prepare("UPDATE job_items SET status = 'skipped', finished_at = ?, error_code = 'no_targets', error_message = ? WHERE id = ?")
      .run(nowIso(), '没有匹配的目标', item.id);
    bumpProgress(jobId, { skipped: 1 });
    return;
  }
  if (target.preflightError) {
    db.prepare("UPDATE job_items SET status = 'failed', finished_at = ?, error_code = 'preflight', error_message = ? WHERE id = ?")
      .run(nowIso(), target.preflightError, item.id);
    bumpProgress(jobId, { failed: 1 });
    return;
  }

  const row = getAccountRow(target.accountId);
  if (!row) {
    db.prepare("UPDATE job_items SET status = 'failed', finished_at = ?, error_code = 'account_missing', error_message = '账号已删除' WHERE id = ?")
      .run(nowIso(), item.id);
    bumpProgress(jobId, { failed: 1 });
    return;
  }

  const token = getAccountToken(row);
  const { ctx, call } = buildOpContext(target, spec, token, controller);
  const opts = spec.options;

  try {
    if (spec.kind === 'sync') {
      const res = await syncAccount(row);
      if (!res.ok) {
        throw Object.assign(new Error(res.error?.message || '同步失败'), {
          stepError: res.error,
          result: { status: res.error?.status || 0, data: { error: res.error } },
        });
      }
      db.prepare(`UPDATE job_items SET status = 'success', http_status = 200, duration_ms = ?,
        response_json = ?, finished_at = ? WHERE id = ?`)
        .run(Date.now() - startedAt, truncate(res), nowIso(), item.id);
      bumpProgress(jobId, { done: 1 });
      return;
    }

    if (spec.kind === 'verify') {
      const res = await verifyAccount(row);
      if (!res.ok) {
        throw Object.assign(new Error(res.error?.message || '测活失败'), {
          stepError: res.error,
          result: { status: res.error?.status || 0, data: { error: res.error } },
        });
      }
      db.prepare(`UPDATE job_items SET status = 'success', http_status = 200, duration_ms = ?,
        response_json = ?, finished_at = ? WHERE id = ?`)
        .run(Date.now() - startedAt, truncate({ user: res.user, scope: res.scope }), nowIso(), item.id);
      bumpProgress(jobId, { done: 1 });
      return;
    }

    if (spec.kind === 'raw') {
      const method = String(spec.params.method || 'GET').toUpperCase();
      const path = materializePath(spec.params.path, ctx);
      if (/\{[A-Za-z]+\}/.test(path)) {
        throw Object.assign(new Error(`路径参数无法自动补全：${path}`), { validation: true });
      }
      const query = {};
      for (const [key, value] of Object.entries(spec.params.query || {})) {
        query[key] = typeof value === 'string' ? materializePath(value, ctx) : value;
      }
      let res;
      if (opts.dryRun) {
        res = {
          ok: true,
          status: 0,
          data: { dryRun: true, request: { method, path, query, body: spec.params.body || null } },
          durationMs: 0,
        };
      } else {
        res = await call(method, path, spec.params.body ?? undefined, query);
      }
      if (!res.ok) {
        const e = errorOf(res);
        const wrapped = new Error(e.message);
        Object.assign(wrapped, { stepError: e, result: res });
        throw wrapped;
      }
      db.prepare(`UPDATE job_items SET status = 'success', http_status = ?, duration_ms = ?,
        response_json = ?, finished_at = ? WHERE id = ?`)
        .run(res.status, Date.now() - startedAt, truncate(res.data), nowIso(), item.id);
      bumpProgress(jobId, { done: 1 });
      return;
    }

    const validationError = validateParams(op, spec.params);
    if (validationError) throw Object.assign(new Error(validationError), { validation: true });

    let steps;
    if (op.run) {
      steps = null;
    } else {
      steps = op.steps(ctx, spec.params || {});
    }

    if (opts.dryRun) {
      const preview = op.run
        ? { custom: true, target: ctx }
        : { requests: steps.map((s) => ({ method: s.method, path: s.path, query: s.query || {}, body: s.body || null })) };
      db.prepare(`UPDATE job_items SET status = 'success', http_status = 0, duration_ms = 0,
        response_json = ?, finished_at = ? WHERE id = ?`)
        .run(truncate({ dryRun: true, ...preview }), nowIso(), item.id);
      bumpProgress(jobId, { done: 1 });
      return;
    }

    let last = null;
    if (op.run) {
      last = await op.run({ call, ctx, params: spec.params || {} });
    } else {
      for (const [index, step] of steps.entries()) {
        let attempt = 0;
        let res;
        let err = null;
        while (true) {
          if (controller.signal.aborted) {
            throw new CloadyError('任务已取消', { code: 'aborted' });
          }
          try {
            res = await executeStep(call, step, controller.signal);
            err = null;
          } catch (e) {
            err = e;
            res = null;
          }
          db.prepare('UPDATE job_items SET attempts = attempts + 1 WHERE id = ?').run(item.id);
          if (res && !res.ok && isRetryable(res) && attempt < opts.retries) {
            await new Promise((r) => setTimeout(r, retryDelay(attempt, res)));
            attempt += 1;
            continue;
          }
          if (err && isRetryable(null, err) && attempt < opts.retries) {
            await new Promise((r) => setTimeout(r, retryDelay(attempt, null)));
            attempt += 1;
            continue;
          }
          break;
        }
        if (err) throw err;
        last = res;
        if (!res.ok) {
          const e = errorOf(res, `步骤 ${index + 1} 失败`);
          const wrapped = new Error(e.message);
          Object.assign(wrapped, { stepError: e, result: res });
          throw wrapped;
        }
        if (opts.stopOnError === false) {
          /* continue executing steps regardless of soft errors */
        }
      }
    }

    if (last && !last.ok) {
      const e = errorOf(last);
      const wrapped = new Error(e.message);
      Object.assign(wrapped, { stepError: e, result: last });
      throw wrapped;
    }

    const httpStatus = last?.status || 200;
    if (spec.operationId === 'account.verify') {
      markAccountVerified(target.accountId, last?.data?.user || {});
    }
    const duration = Date.now() - startedAt;
    db.prepare(`UPDATE job_items SET status = 'success', http_status = ?, duration_ms = ?,
      response_json = ?, finished_at = ? WHERE id = ?`)
      .run(httpStatus, duration, truncate(last?.data ?? { ok: true }), nowIso(), item.id);
    bumpProgress(jobId, { done: 1 });
    emit(jobId, 'item', {
      item: { id: item.id, targetKey: target.targetKey, status: 'success', httpStatus, durationMs: duration },
    });
  } catch (err) {
    const aborted = controller.signal.aborted || err.code === 'aborted';
    const e = err.stepError || errorOf(err.result, err.message);
    const status = aborted ? 'cancelled' : 'failed';
    if (!aborted && [401, 403].includes(Number(err.result?.status))) {
      recordAccountError(target.accountId, e);
    }
    const duration = Date.now() - startedAt;
    db.prepare(`UPDATE job_items SET status = ?, http_status = ?, duration_ms = ?,
      error_code = ?, error_message = ?, response_json = ?, finished_at = ? WHERE id = ?`)
      .run(
        status,
        err.result?.status || null,
        duration,
        aborted ? 'aborted' : (e.code || 'error'),
        String(e.message || err.message).slice(0, 500),
        truncate(err.result?.data ?? null),
        nowIso(),
        item.id,
      );
    bumpProgress(jobId, aborted ? { skipped: 1 } : { failed: 1 });
    emit(jobId, 'item', {
      item: {
        id: item.id,
        targetKey: target.targetKey,
        status,
        httpStatus: err.result?.status || null,
        durationMs: duration,
        errorCode: aborted ? 'aborted' : e.code,
        errorMessage: e.message,
      },
    });
  }
}

async function runPool(jobId, targets, spec, op, controller) {
  const concurrency = spec.options.concurrency;
  const perAccount = CONFIG.perAccountConcurrency;
  const queue = [...targets];
  const activeByAccount = new Map();
  let active = 0;
  let stop = false;

  return new Promise((resolve) => {
    const tick = () => {
      if (stop) return;
      if (controller.signal.aborted) {
        // Drain whatever is not running.
        while (queue.length) {
          const dropped = queue.pop();
          db.prepare(`UPDATE job_items SET status = 'skipped', error_code = 'aborted',
            error_message = '任务取消，未开始执行', finished_at = ?
            WHERE job_id = ? AND target_key = ?`)
            .run(nowIso(), jobId, dropped.targetKey);
          bumpProgress(jobId, { skipped: 1 });
        }
        if (active === 0) {
          stop = true;
          resolve();
        }
        return;
      }
      let progressed = true;
      while (progressed && active < concurrency && queue.length) {
        progressed = false;
        for (let i = 0; i < queue.length; i += 1) {
          const target = queue[i];
          const accountActive = activeByAccount.get(target.accountId) || 0;
          if (accountActive >= perAccount) continue;
          queue.splice(i, 1);
          active += 1;
          activeByAccount.set(target.accountId, accountActive + 1);
          progressed = true;
          runItem(jobId, target, spec, op, controller)
            .catch((err) => log.error('item crashed', err))
            .finally(() => {
              active -= 1;
              activeByAccount.set(target.accountId, (activeByAccount.get(target.accountId) || 1) - 1);
              if (queue.length === 0 && active === 0) {
                stop = true;
                resolve();
                return;
              }
              tick();
            });
          break;
        }
      }
      if (queue.length === 0 && active === 0) {
        stop = true;
        resolve();
      }
    };
    tick();
  });
}

function finishJob(jobId, status, summary) {
  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
  if (!row) return;
  const finishedAt = nowIso();
  const byError = Object.fromEntries(
    db.prepare(`SELECT COALESCE(error_code, 'unknown') AS code, COUNT(*) AS n
                FROM job_items WHERE job_id = ? AND status = 'failed' GROUP BY error_code`)
      .all(jobId)
      .map((r) => [r.code, r.n]),
  );
  const started = row.started_at ? new Date(row.started_at).getTime() : Date.now();
  const finalSummary = {
    success: row.done,
    failed: row.failed,
    skipped: row.skipped,
    total: row.total,
    durationMs: Date.now() - started,
    byError,
    ...summary,
  };
  db.prepare('UPDATE jobs SET status = ?, finished_at = ?, summary_json = ? WHERE id = ?')
    .run(status, finishedAt, JSON.stringify(finalSummary), jobId);
  emit(jobId, 'done', { status, summary: finalSummary });
  const after = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
  emit(jobId, 'snapshot', { job: publicJob(after) });
}

async function runJob(jobId) {
  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
  if (!row) return;
  const spec = json(row.spec_json, {});
  const controller = new AbortController();
  running.set(jobId, { controller, cancelled: false, spec });
  setJob(jobId, { status: 'running', started_at: nowIso() });
  emit(jobId, 'status', { status: 'running' });

  const op = spec.kind === 'operation' ? OPERATION_MAP.get(spec.operationId) : null;
  if (spec.kind === 'operation' && !op) {
    finishJob(jobId, 'failed', { fatal: '操作不存在' });
    running.delete(jobId);
    return;
  }

  try {
    logLine(jobId, 'info', `任务开始：${row.label}，账号 ${spec.accountIds.length} 个，并发 ${spec.options.concurrency}`);
    const targets = await expandTargets(jobId, spec, op);
    if (!targets.length) {
      logLine(jobId, 'warn', '没有匹配的目标，任务结束');
      setJob(jobId, { total: 0 });
      finishJob(jobId, 'done', { note: '没有匹配的目标' });
      return;
    }

    tx(() => {
      const insert = db.prepare(`
        INSERT INTO job_items (job_id, account_id, target_key, target_label, workspace_slug, app_slug,
          status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'queued', ?)
      `);
      for (const t of targets) {
        insert.run(jobId, t.accountId, t.targetKey, t.targetLabel, t.workspaceSlug || null, t.appSlug || null, nowIso());
      }
    });
    setJob(jobId, { total: targets.length });
    emit(jobId, 'progress', {
      status: 'running', total: targets.length, done: 0, failed: 0, skipped: 0, processed: 0,
    });
    logLine(jobId, 'info', `展开 ${targets.length} 个执行目标`);
    if (spec.options.dryRun) logLine(jobId, 'info', '演练模式：只预览请求，不产生写入');

    await runPool(jobId, targets, spec, op, controller);

    const finalRow = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
    let status = 'done';
    if (controller.signal.aborted) status = 'cancelled';
    else if (finalRow.failed > 0 && finalRow.done === 0) status = 'failed';
    else if (finalRow.failed > 0) status = 'partial';
    finishJob(jobId, status, {});
    logLine(jobId, 'info', `任务结束：成功 ${finalRow.done}，失败 ${finalRow.failed}，跳过 ${finalRow.skipped}`);
  } catch (err) {
    log.error('runJob failed', err);
    logLine(jobId, 'error', `任务异常：${err.message}`);
    finishJob(jobId, 'failed', { fatal: err.message });
  } finally {
    running.delete(jobId);
  }
}

/* --------------------------------------------------------------- retry */

export function retryItem(jobId, itemId, actor) {
  const item = db.prepare('SELECT * FROM job_items WHERE id = ? AND job_id = ?').get(itemId, jobId);
  if (!item) throw Object.assign(new Error('条目不存在'), { status: 404 });
  const spec = json(db.prepare('SELECT spec_json FROM jobs WHERE id = ?').get(jobId).spec_json, {});
  return createJob({
    kind: spec.kind,
    operationId: spec.operationId,
    accountIds: [item.account_id],
    params: spec.params,
    filters: spec.filters,
    options: { ...spec.options, dryRun: false },
    label: `单条重试 · ${item.target_label}`,
    actor,
    onlyTargets: [{
      accountId: item.account_id,
      workspaceSlug: item.workspace_slug,
      appSlug: item.app_slug,
      serviceKey: item.target_key,
    }],
  });
}

/* ------------------------------------------------------------- lifecycle */

export function initJobs() {
  db.prepare("UPDATE jobs SET status = 'failed', finished_at = ?, summary_json = ? WHERE status IN ('running','queued')")
    .run(nowIso(), JSON.stringify({ fatal: '服务重启，任务中断' }));
  // Keep the store bounded; jobs are operational history, not audit records.
  const cutoff = db.prepare('SELECT id FROM jobs ORDER BY created_at DESC LIMIT 1 OFFSET 500').get();
  if (cutoff) {
    db.prepare('DELETE FROM jobs WHERE created_at < (SELECT created_at FROM jobs WHERE id = ?)').run(cutoff.id);
  }
}

export function jobStats(days = 7) {
  const since = new Date(Date.now() - days * 86_400_000).toISOString();
  const rows = db.prepare(`
    SELECT substr(created_at, 1, 10) AS day, status, COUNT(*) AS n
    FROM jobs WHERE created_at >= ? GROUP BY day, status ORDER BY day
  `).all(since);
  const byDay = {};
  for (let i = days - 1; i >= 0; i -= 1) {
    const d = new Date(Date.now() - i * 86_400_000).toISOString().slice(0, 10);
    byDay[d] = { day: d, done: 0, failed: 0, partial: 0, cancelled: 0, total: 0 };
  }
  for (const r of rows) {
    if (!byDay[r.day]) byDay[r.day] = { day: r.day, done: 0, failed: 0, partial: 0, cancelled: 0, total: 0 };
    byDay[r.day][r.status] = (byDay[r.day][r.status] || 0) + r.n;
    byDay[r.day].total += r.n;
  }
  const itemTotals = db.prepare(`
    SELECT COUNT(*) AS n,
           SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS ok,
           SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS bad,
           AVG(duration_ms) AS avg_ms
    FROM job_items WHERE created_at >= ?
  `).get(since);
  const serial = running.size;
  return {
    days: Object.values(byDay),
    items: {
      total: itemTotals.n || 0,
      success: itemTotals.ok || 0,
      failed: itemTotals.bad || 0,
      avgMs: Math.round(itemTotals.avg_ms || 0),
    },
    running: serial,
    catalog: OPERATIONS.map(publicOperation),
  };
}

export function runningJobs() {
  return [...running.keys()];
}
