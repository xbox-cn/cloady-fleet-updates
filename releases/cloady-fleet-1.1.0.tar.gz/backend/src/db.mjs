import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { CONFIG, log } from './config.mjs';
import { hashPassword, randomPassword } from './lib/crypto.mjs';

fs.mkdirSync(path.dirname(CONFIG.dbFile), { recursive: true });

export const db = new DatabaseSync(CONFIG.dbFile);
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA synchronous = NORMAL;
  PRAGMA foreign_keys = ON;
  PRAGMA busy_timeout = 5000;
`);

const MIGRATIONS = [
  `
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    token_enc TEXT NOT NULL,
    token_hint TEXT NOT NULL,
    token_hash TEXT NOT NULL UNIQUE,
    scope TEXT NOT NULL DEFAULT 'unknown',
    workspace_hint TEXT,
    notes TEXT NOT NULL DEFAULT '',
    tags TEXT NOT NULL DEFAULT '[]',
    user_id TEXT,
    user_email TEXT,
    user_name TEXT,
    user_image TEXT,
    status TEXT NOT NULL DEFAULT 'unknown',
    status_code INTEGER,
    last_error TEXT,
    workspace_count INTEGER NOT NULL DEFAULT 0,
    service_count INTEGER NOT NULL DEFAULT 0,
    monthly_cents INTEGER NOT NULL DEFAULT 0,
    plan_summary TEXT,
    created_by TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    verified_at TEXT,
    synced_at TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_accounts_status ON accounts(status);
  CREATE INDEX IF NOT EXISTS idx_accounts_created ON accounts(created_at DESC);

  CREATE TABLE IF NOT EXISTS workspaces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    slug TEXT NOT NULL,
    name TEXT NOT NULL,
    plan TEXT,
    monthly_cents INTEGER NOT NULL DEFAULT 0,
    plan_ends_at TEXT,
    paywall INTEGER NOT NULL DEFAULT 0,
    trial_available INTEGER NOT NULL DEFAULT 0,
    usage_json TEXT NOT NULL DEFAULT '{}',
    hues_json TEXT NOT NULL DEFAULT '[]',
    icon_url TEXT,
    synced_at TEXT NOT NULL,
    UNIQUE(account_id, slug)
  );
  CREATE INDEX IF NOT EXISTS idx_workspaces_account ON workspaces(account_id);

  CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    workspace_slug TEXT NOT NULL,
    slug TEXT NOT NULL,
    name TEXT NOT NULL,
    env TEXT,
    region TEXT,
    status TEXT,
    type TEXT,
    uptime TEXT,
    endpoints_json TEXT NOT NULL DEFAULT '[]',
    limits_json TEXT NOT NULL DEFAULT '{}',
    scale_json TEXT NOT NULL DEFAULT '{}',
    source_json TEXT NOT NULL DEFAULT '{}',
    sub_services_json TEXT NOT NULL DEFAULT '[]',
    blocked TEXT,
    synced_at TEXT NOT NULL,
    UNIQUE(account_id, workspace_slug, slug)
  );
  CREATE INDEX IF NOT EXISTS idx_services_account ON services(account_id);
  CREATE INDEX IF NOT EXISTS idx_services_ws ON services(account_id, workspace_slug);
  CREATE INDEX IF NOT EXISTS idx_services_status ON services(status);

  CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    label TEXT NOT NULL,
    operation_id TEXT,
    status TEXT NOT NULL,
    total INTEGER NOT NULL DEFAULT 0,
    done INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    skipped INTEGER NOT NULL DEFAULT 0,
    created_by TEXT,
    created_at TEXT NOT NULL,
    started_at TEXT,
    finished_at TEXT,
    spec_json TEXT NOT NULL,
    summary_json TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_jobs_created ON jobs(created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);

  CREATE TABLE IF NOT EXISTS job_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    account_id TEXT,
    target_key TEXT,
    target_label TEXT,
    workspace_slug TEXT,
    app_slug TEXT,
    status TEXT NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    http_status INTEGER,
    duration_ms INTEGER,
    error_code TEXT,
    error_message TEXT,
    response_json TEXT,
    created_at TEXT NOT NULL,
    finished_at TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_job_items_job ON job_items(job_id, id);
  CREATE INDEX IF NOT EXISTS idx_job_items_status ON job_items(job_id, status);

  CREATE TABLE IF NOT EXISTS job_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    at TEXT NOT NULL,
    level TEXT NOT NULL,
    message TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_job_logs_job ON job_logs(job_id, id);

  CREATE TABLE IF NOT EXISTS api_keys (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    key_hash TEXT NOT NULL UNIQUE,
    key_hint TEXT NOT NULL,
    created_at TEXT NOT NULL,
    last_used_at TEXT
  );

  CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    at TEXT NOT NULL,
    actor TEXT,
    action TEXT NOT NULL,
    detail TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_audit_at ON audit(at DESC);
  `,
  `
  UPDATE accounts SET status = 'normal' WHERE status = 'ok';
  UPDATE accounts SET status = 'banned' WHERE status = 'invalid';
  UPDATE accounts SET status = 'unknown' WHERE status IN ('limited', 'error', 'unverified');
  `,
];

export function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch {
      /* already rolled back */
    }
    throw err;
  }
}

const current = db.prepare('PRAGMA user_version').get().user_version ?? 0;
if (current < MIGRATIONS.length) {
  tx(() => {
    for (let i = current; i < MIGRATIONS.length; i += 1) db.exec(MIGRATIONS[i]);
    db.exec(`PRAGMA user_version = ${MIGRATIONS.length}`);
  });
}

/* ---------------------------------------------------------------- settings */

export const settings = {
  get(key, fallback = null) {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
    return row ? row.value : fallback;
  },
  set(key, value) {
    db.prepare(
      `INSERT INTO settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    ).run(key, String(value));
  },
  all() {
    const out = {};
    for (const row of db.prepare('SELECT key, value FROM settings').all()) out[row.key] = row.value;
    return out;
  },
};

/* Bootstrap the manager password exactly once. */
export function bootstrapPassword() {
  if (settings.get('manager_password')) return;
  const fromEnv = process.env.MANAGER_PASSWORD;
  const password = fromEnv || randomPassword(20);
  settings.set('manager_password', hashPassword(password));
  if (!fromEnv) {
    const file = path.join(CONFIG.dataDir, 'initial-password.txt');
    fs.writeFileSync(file, `${password}\n`, { mode: 0o600 });
    log.warn('==========================================================');
    log.warn(' 首次启动：管理后台密码已生成');
    log.warn(`   ${password}`);
    log.warn(` 已写入 ${file}`);
    log.warn(' 登录后请在「设置 → 安全」中更换。');
    log.warn('==========================================================');
  }
}

export function audit(actor, action, detail) {
  db.prepare('INSERT INTO audit (at, actor, action, detail) VALUES (?, ?, ?, ?)').run(
    new Date().toISOString(),
    actor || 'system',
    action,
    detail ? JSON.stringify(detail) : null,
  );
}

export function json(value, fallback) {
  if (value == null || value === '') return fallback;
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}
