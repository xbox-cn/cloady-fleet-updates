# Cloady Fleet

自托管的 **Cloady 多账号控制平面**：把多枚 `cldy_` API 令牌收进加密金库，拉平工作区与应用视图，然后把重复操作交给受控批量引擎。

- 官方文档：[Cloady REST API](https://cloady.com/zh/docs/api) · [OpenAPI 0.19](https://cloady.com/openapi.json)
- 视觉：Midnight Glass（深空玻璃、紫色主电流、青/粉辅助光），参考 `Twitch掉宝前端/twitch-cdk`

---

## 功能

| 模块 | 能力 |
|---|---|
| 账号金库 | 单条 / 批量 / CSV / JSON 导入令牌；自动去重；AES-256-GCM 加密落库；自动识别 Read only / Deploy only / Full access |
| 资产同步 | 读取 `/api/me` + `/api/workspaces`，落库工作区、应用、区域、规格、端点与月费 |
| 跨账号资产 | 搜索、按账号/状态/区域筛选；应用抽屉实时读取变量、部署、域名、日志 |
| 批量任务 | 37 个封装操作（体检、同步、部署、状态、变量、域名、备份、日志、工单…） |
| 全量 API | 官方 **162 个端点**全部可在「API 实验室」单发或批量执行（白名单保护） |
| API 文档 | `/api-docs` 公开阅读；调用 API 需 `mgr_` 密钥（设置生成） |
| 自动化 | 默认开启：每 30 分钟批量测活 + 同步；可调间隔与单项开关，任务进审计中心 |
| 审计中心 | 操作历史、逐条响应、失败分布、失败重试、CSV 导出；创建操作后就地反馈，不强制跳转 |
| 自动化 | 管理密钥（`mgr_…`）可调用导入 / 建任务 / 代理接口 |
| 运维 | 并发、缓存 TTL 可调；上游延迟与缓存命中实时统计 |

不支持或受上游限制的能力不会伪造：令牌真实范围由 Cloady 决定，管理器只做标注与请求转发。

---

## 快速开始

要求 **Node.js ≥ 22.5**（使用内置 `node:sqlite`；推荐 24.x）。

```bash
# 1. 构建前端
npm --prefix frontend install
npm --prefix frontend run build

# 2. 启动
npm start
# 或 Windows 双击 start.cmd
```

打开 <http://127.0.0.1:8787>。

首次启动会生成管理密码：

- 终端日志中打印一次
- 同时写入 `backend/data/initial-password.txt`
- 登录后在「设置 → 安全」中修改，并删除该文件

### 已部署实例

当前公网实例：**http://47.98.228.129:41087**（纯 HTTP）。
部署拓扑、路径、服务、备份与更新步骤见 [DEPLOYMENT.md](DEPLOYMENT.md)。

### 路由约定

- `/` 始终是公开展示页，登录后也不会被控制台覆盖。
- `/login` 登录；`/dashboard` 机群总览；`/accounts`、`/inventory`、`/batch`、`/automation`、`/audit`、`/lab`、`/api-docs`、`/settings` 各自独立路由；旧的 `/jobs` 会自动重定向到 `/audit`。
- 未登录访问控制台路由会跳到登录页，登录后回到原目标页。
- 侧栏「查看展示页」可随时回到 `/`。
- 创建同步、体检、批量操作后留在当前页，顶栏显示「N 个操作运行中」，审计中心只负责历史与详情。

### 外观与动效

- 默认跟随系统明暗；点击右上角太阳/月亮图标直接切换浅色 / 深色，手动切换后即切断系统跟随。
- 设置页「外观」可随时切回跟随系统；选择会写入 localStorage，刷新后保持。
- 动效全量常开，不提供开关。
- 页面进入、卡片错峰、图表线条、状态点、进度条、导航电流、Landing 的极光/浮层/数字滚动/入场揭示与卡片聚光均已接入。

### 开发模式

```bash
npm run dev          # API :8787 + Vite :5173（/api 代理到后端）
```

### 演示数据（可选）

```bash
node scripts/seed-demo.mjs
DATA_DIR=backend/data-demo PORT=8788 node backend/src/server.mjs
```

演示库与正式库完全隔离，密码在 `backend/data-demo/initial-password.txt`。

---

## 架构

```
Browser (React 19 + Vite)
  │  fetch /api/*            SSE /api/jobs/:id/stream
  ▼
Node 24 控制面（零运行时依赖）
  ├─ 会话 / 管理密钥认证      HttpOnly Cookie + scrypt
  ├─ 金库                    AES-256-GCM, HKDF(secret.bin)
  ├─ SQLite (WAL)            账号 / 工作区 / 应用 / 任务 / 审计
  ├─ 批量调度器              全局并发 + 单账号并发 + 重试 + 取消
  ├─ 上游客户端              HTTPS keep-alive / gzip / ETag / single-flight
  └─ OpenAPI 白名单          162 端点目录 + 路径校验
        │
        ▼
   https://cloady.com/api
```

### 性能设计

- **连接复用**：`https.Agent` keep-alive，默认 64 sockets、LIFO 调度，避免批量任务反复握手。
- **缓存**：GET 默认 20s TTL，支持 `ETag / If-None-Match`；并发相同请求合并为一次上游调用（single-flight）；缓存按令牌哈希分区，不会串号。
- **批量引擎**：全局 8 并发（可调）+ 单账号 2 并发；429/5xx 指数退避并尊重 `Retry-After`；失败项可单独重跑。
- **流式反馈**：任务进度走 SSE，不轮询；前端只在终态失效查询。
- **存储**：SQLite WAL、预编译语句、事务批量写入；默认最多保留 500 个任务。
- **前端**：TanStack Query 缓存与占位数据、路由级页面、按需加载抽屉内容、44KB CSS / 448KB JS（gzip 约 143KB）。

### 目录

```
backend/src/
  server.mjs         HTTP 路由与静态服务
  accounts.mjs       金库、同步、资产查询
  jobs.mjs           批量调度器与 SSE 事件
  operations.mjs     37 个预设操作（真实请求构造）
  catalog.mjs        OpenAPI 解析与路径白名单
  stats.mjs          总览聚合
  lib/cloady.mjs     上游客户端（连接池/缓存/重试）
frontend/src/
  pages/             总览、账号、资产、批量、任务、实验室、设置
  components/        AppShell、抽屉、导入、图表、UI 原语
scripts/
  dev.mjs            本地双进程启动
  seed-demo.mjs      演示数据
```

---

## 批量操作

预设操作按目标分三类：

- **按账号**：体检、读取工作区、令牌、账单、工单、通知、安全状态、创建工单
- **按工作区**：账单、成员、邀请、域名、卷、集成、健康巡检、从 Git 新建应用
- **按应用**：重新部署、设置状态、改名、调规格、删除、部署记录、回滚、变量导入/覆盖、域名绑定/解绑、备份、子服务、日志、指标、远程执行、SSH 会话

「API 实验室」里可以在 162 个端点中任选一个：

- 单发：选择账号、填路径/查询/请求体，直接看到上游状态码与 JSON
- 批量：路径中的 `{workspaceSlug}` / `{appSlug}` 会按每个账号已同步的资产自动展开
- 演练：只生成请求预览，不产生写入

所有路径都必须命中官方 OpenAPI 目录，且仅允许 `/api/` 下的相对路径。

---

## 管理器 API

浏览器会话之外，可在「设置 → 自动化密钥」创建 `mgr_…`。它拥有与浏览器会话相同的管理权限。

```bash
# 导入多个令牌并自动同步
curl -X POST http://127.0.0.1:8787/api/accounts/import \
  -H "Authorization: Bearer mgr_xxx" \
  -H "Content-Type: application/json" \
  -d '{
    "entries": [
      {"label": "东京生产", "token": "cldy_xxx", "scope": "full", "tags": ["生产"]},
      {"label": "新加坡预发", "token": "cldy_yyy", "scope": "deploy"}
    ],
    "sync": true
  }'

# 发起批量同步
curl -X POST http://127.0.0.1:8787/api/accounts/sync \
  -H "Authorization: Bearer mgr_xxx" \
  -H "Content-Type: application/json" \
  -d '{"all": true}'

# 发起预设操作
curl -X POST http://127.0.0.1:8787/api/jobs \
  -H "Authorization: Bearer mgr_xxx" \
  -H "Content-Type: application/json" \
  -d '{
    "kind": "operation",
    "operationId": "app.redeploy",
    "accountIds": ["acc_xxx"],
    "params": {},
    "filters": {"workspaceSlug": "studio-web"},
    "options": {"concurrency": 8, "dryRun": true}
  }'

# 单条实时代理（白名单内任意端点）
curl -X POST http://127.0.0.1:8787/api/proxy \
  -H "Authorization: Bearer mgr_xxx" \
  -H "Content-Type: application/json" \
  -d '{"accountId":"acc_xxx","method":"GET","path":"/api/me"}'
```

主要响应字段：

- 导入：`imported[]`、`duplicates`、`invalid[]`、`job`
- 任务：`{ id, job }`；查询 `GET /api/jobs/:id`；流 `GET /api/jobs/:id/stream`
- 代理：`{ ok, status, data, durationMs, cached, error }`

---

## 安全

- 令牌 **AES-256-GCM** 加密；密钥由 `data/secret.bin` 经 HKDF 派生。备份数据库时必须同时备份该文件。
- 管理密码用 **scrypt** 哈希；会话 Cookie `HttpOnly`、`SameSite=Lax`，默认 7 天。
- 查看明文令牌需要再次输入管理密码；操作写入审计表。
- 所有写请求校验同源；登录限速 10 次/分钟/IP。
- 上游路径严格白名单，禁止绝对 URL、`..` 与未知端点。
- 默认只监听 `127.0.0.1`。放到反代后请设置 `COOKIE_SECURE=1` 并启用 HTTPS。
- 删除账号只删本地记录，不动 Cloady 资源。

---

## 配置

见 `.env.example`。常用项：

| 变量 | 默认 | 说明 |
|---|---|---|
| `HOST` / `PORT` | `127.0.0.1` / `8787` | 监听地址 |
| `DATA_DIR` | `backend/data` | SQLite、密钥、初始密码 |
| `MANAGER_PASSWORD` | 自动生成 | 首次启动密码 |
| `BATCH_CONCURRENCY` | `8` | 批量全局并发（也可在 UI 调） |
| `PER_ACCOUNT_CONCURRENCY` | `2` | 单账号并发 |
| `CACHE_TTL_MS` | `20000` | GET 缓存 |
| `COOKIE_SECURE` | `0` | HTTPS 下设 1 |
| `CLOADY_BASE_URL` | `https://cloady.com` | 上游控制面 |

---

## Docker

```bash
docker build -t cloady-fleet .
docker run -d --name cloady-fleet \
  -p 8787:8787 \
  -v $(pwd)/data:/data \
  -e COOKIE_SECURE=0 \
  cloady-fleet
```

或 `docker compose up -d`。容器内 `HOST=0.0.0.0`、`DATA_DIR=/data`。

---

## 验证范围

本次交付已实际执行：

- `tsc -b && vite build` 通过（无类型错误）
- `npm run smoke` 全绿：健康检查、未登录拦截、登录/会话、目录（162 API / 37 预设）、账号、总览、代理路径校验、OpenAPI 白名单、SPA 回退与 CSP
- 后端启动、SQLite 迁移、登录、HttpOnly 会话 Cookie
- 令牌导入、去重、加密落库、后台同步任务及失败状态
- 批量任务创建、演练模式、逐条结果、SSE 事件、CSV 导出、取消与重试路径
- 管理密钥创建与调用（导入 / 建任务 / 代理）
- 静态资源 gzip 与 immutable 缓存头、SPA 深链回退
- 浏览器内走查：登录、总览、账号、账号抽屉、资产、应用抽屉、批量编排、任务抽屉、导入抽屉、API 实验室、设置、浅色主题、移动端（390px）与命令面板

真实 Cloady 上游调用取决于你的令牌与权限，仓库内不自带任何可用令牌；演示库 `backend/data-demo` 使用假令牌，仅用于界面走查。

---

Cloady Fleet 是独立工具，与 NeptoLab / Cloady 无隶属关系。Cloady 名称与 API 归其所有者。
