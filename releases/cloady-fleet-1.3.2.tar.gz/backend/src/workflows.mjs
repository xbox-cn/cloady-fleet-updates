/**
 * Workflow projects that run inside a Cloady app container.
 *
 * A run is a detached shell process started through the Cloady exec endpoint.
 * The manager polls a status script, keeps a log tail, and can kill the whole
 * process group at any time. The first project is cloady-autoreg.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { CONFIG, log } from './config.mjs';
import { db, json, audit } from './db.mjs';
import { newId, sha256 } from './lib/crypto.mjs';
import { getAccountRow, getAccountToken } from './accounts.mjs';
import { createKey, deleteKey } from './auth.mjs';
import { rawRequest } from './lib/cloady.mjs';
import { HttpError } from './lib/http.mjs';

const WORK_ROOT = '/tmp/cloady-fleet-workflows';
const BUNDLE_TTL_MS = 60 * 60_000;

export const WORKFLOWS = [
  {
    id: 'cloady-autoreg',
    name: 'Cloady Autoreg',
    version: '1.4.0',
    repo: 'https://github.com/xbox-cn/cloady-autoreg',
    description: 'cloak 指纹浏览器过 Cloudflare Turnstile，协议层注册账号、铸造 token，并自动导入 Cloady Fleet。',
    notes: '容器需要 Node.js ≥ 20.19、npm、curl/wget、tar 与足够磁盘；首次运行会安装依赖。',
    bundleFile: 'cloady-autoreg-1.4.0.tar.gz',
    entry: 'node src/run.mjs',
    fields: [
      { key: 'count', label: '注册数量', type: 'number', default: 1, min: 1, max: 1000 },
      { key: 'workers', label: '浏览器 worker', type: 'number', default: 1, min: 1, max: 20 },
      { key: 'threads', label: '每 worker 并发', type: 'number', default: 1, min: 1, max: 10 },
      { key: 'rounds', label: '每 lane 轮数', type: 'number', default: 1, min: 1, max: 50 },
      { key: 'proxy', label: '代理', type: 'text', default: '', placeholder: 'http://user:pass@host:port' },
      { key: 'mailApi', label: '临时邮箱 API', type: 'text', default: 'https://mail.minecraft.fashion/api' },
      { key: 'mailDomain', label: '邮箱域名', type: 'text', default: '5atud.asia' },
      { key: 'mailApiKey', label: '邮箱 API Key', type: 'password', default: '' },
      { key: 'tokenScope', label: 'Token 权限', type: 'select', default: 'full', options: ['full', 'deploy', 'read'] },
      { key: 'tokenExpires', label: 'Token 有效期', type: 'select', default: 'never', options: ['never', '30d', '90d', '1y'] },
    ],
  },
];

const WORKFLOW_MAP = new Map(WORKFLOWS.map((workflow) => [workflow.id, workflow]));
const ACTIVE = ['queued', 'running', 'cancelling'];

fs.mkdirSync(CONFIG.workflowsDir, { recursive: true, mode: 0o700 });

function httpError(status, code, message) {
  return new HttpError(status, code, message);
}

function nowIso() {
  return new Date().toISOString();
}

function bundlePath(workflow) {
  return path.join(CONFIG.workflowsDir, workflow.bundleFile);
}

function shellQuote(value) {
  return `'${String(value ?? '').replace(/'/g, "'\\''")}'`;
}

function clampNumber(value, field) {
  const n = Number(value);
  const base = Number.isFinite(n) ? n : Number(field.default || 0);
  return Math.max(field.min ?? 0, Math.min(field.max ?? Number.MAX_SAFE_INTEGER, Math.round(base)));
}

function normalizeParams(workflow, input = {}) {
  const out = {};
  for (const field of workflow.fields) {
    const raw = input[field.key] ?? field.default;
    if (field.type === 'number') out[field.key] = clampNumber(raw, field);
    else out[field.key] = String(raw ?? '').slice(0, field.type === 'password' ? 400 : 1000);
  }
  return out;
}

function redactParams(params = {}) {
  const out = { ...params };
  if (out.mailApiKey) out.mailApiKey = '••••';
  if (out.proxy) {
    out.proxy = String(out.proxy).replace(/:\/\/([^:@/]+):([^@/]+)@/, '://$1:***@');
  }
  return out;
}

function selectService(accountId, workspaceSlug, appSlug) {
  const rows = db.prepare(`
    SELECT * FROM services WHERE account_id = ?
    ORDER BY (status = 'running') DESC, id
  `).all(accountId);
  let matched = rows;
  if (workspaceSlug) matched = matched.filter((row) => row.workspace_slug === workspaceSlug);
  if (appSlug) matched = matched.filter((row) => row.slug === appSlug);
  return matched[0] || null;
}

function componentFor(service, requested) {
  if (requested) return String(requested).slice(0, 200);
  const sub = json(service.sub_services_json, []);
  return String(sub?.[0]?.name || service.slug || 'app').slice(0, 200);
}

function publicBaseFromRequest(req) {
  if (CONFIG.publicBaseUrl) return CONFIG.publicBaseUrl;
  const proto = String(req.headers['x-forwarded-proto'] || 'http').split(',')[0].trim() || 'http';
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
  return host ? `${proto}://${host}`.replace(/\/+$/, '') : '';
}

export { publicBaseFromRequest };

export function listWorkflows() {
  return WORKFLOWS.map((workflow) => {
    const file = bundlePath(workflow);
    let size = 0;
    try { size = fs.statSync(file).size; } catch { /* missing */ }
    return {
      id: workflow.id,
      name: workflow.name,
      version: workflow.version,
      repo: workflow.repo,
      description: workflow.description,
      notes: workflow.notes,
      entry: workflow.entry,
      fields: workflow.fields,
      bundleAvailable: size > 0,
      bundleBytes: size,
    };
  });
}

export function publicRun(row) {
  if (!row) return null;
  const started = row.started_at ? Date.parse(row.started_at) : 0;
  const finished = row.finished_at ? Date.parse(row.finished_at) : 0;
  return {
    id: row.id,
    workflowId: row.workflow_id,
    workflowName: row.workflow_name,
    workflowVersion: row.workflow_version,
    accountId: row.account_id,
    accountLabel: row.account_label,
    workspaceSlug: row.workspace_slug,
    appSlug: row.app_slug,
    appLabel: row.app_label,
    component: row.component,
    status: row.status,
    params: redactParams(json(row.params_json, {})),
    logTail: row.log_tail || '',
    exitCode: row.exit_code,
    error: row.error,
    createdAt: row.created_at,
    startedAt: row.started_at,
    finishedAt: row.finished_at,
    lastPolledAt: row.last_polled_at,
    durationMs: started ? (finished || Date.now()) - started : 0,
  };
}

export function listWorkflowRuns({ page = 1, pageSize = 20, workflow = '', status = '', query = '' } = {}) {
  const where = [];
  const params = [];
  if (workflow) { where.push('workflow_id = ?'); params.push(workflow); }
  if (status === 'active') {
    where.push("status IN ('queued','running','cancelling')");
  } else if (status) {
    where.push('status = ?');
    params.push(status);
  }
  const q = String(query || '').trim();
  if (q) {
    where.push('(account_label LIKE ? OR app_label LIKE ? OR app_slug LIKE ? OR id LIKE ?)');
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS n FROM workflow_runs ${whereSql}`).get(...params).n;
  const size = Math.max(1, Math.min(100, Number(pageSize) || 20));
  const offset = (Math.max(1, Number(page) || 1) - 1) * size;
  const rows = db.prepare(`
    SELECT * FROM workflow_runs ${whereSql}
    ORDER BY created_at DESC LIMIT ? OFFSET ?
  `).all(...params, size, offset);
  const counts = db.prepare('SELECT status, COUNT(*) AS n FROM workflow_runs GROUP BY status').all()
    .reduce((acc, row) => ({ ...acc, [row.status]: row.n }), {});
  return {
    items: rows.map(publicRun),
    total,
    page: Math.max(1, Number(page) || 1),
    pageSize: size,
    counts,
  };
}

export function getWorkflowRun(id) {
  return publicRun(db.prepare('SELECT * FROM workflow_runs WHERE id = ?').get(id));
}

function execPath(service) {
  return `/api/workspaces/${encodeURIComponent(service.workspace_slug)}`
    + `/apps/${encodeURIComponent(service.slug)}/exec`;
}

async function execOnService({ account, service, component, command, stdin, timeoutMs = 30_000 }) {
  const token = getAccountToken(account);
  const query = {};
  if (service.env) query.env = service.env;
  if (service.region) query.region = service.region;
  const res = await rawRequest({
    token,
    method: 'POST',
    path: execPath(service),
    query,
    body: {
      component,
      command,
      ...(stdin ? { stdin } : {}),
      timeoutMs,
    },
    timeoutMs: timeoutMs + 5_000,
  }).catch((error) => {
    throw httpError(502, 'exec_failed', `容器命令失败：${error.message}`);
  });
  if (!res.ok) {
    throw httpError(res.status === 401 || res.status === 403 ? res.status : 502,
      'exec_failed', `容器命令失败：HTTP ${res.status} ${JSON.stringify(res.data).slice(0, 300)}`);
  }
  if (res.data?.timedOut) {
    throw httpError(504, 'exec_timeout', '容器命令超时');
  }
  if (res.data?.exit != null && Number(res.data.exit) !== 0) {
    throw httpError(502, 'exec_exit',
      `容器命令退出码 ${res.data.exit}：${String(res.data.output || '').slice(-500)}`);
  }
  return res.data;
}

function runScript({ run, workflow, params, bundleUrl, managerKey, publicBase }) {
  const runDir = `${WORK_ROOT}/runs/${run.id}`;
  const projectDir = `${WORK_ROOT}/projects/${workflow.id}-${workflow.version}`;
  const env = {
    TARGET_URL: 'https://cloady.com',
    LOGIN_PATH: '/login',
    MAIL_API: params.mailApi,
    MAIL_DOMAIN: params.mailDomain,
    TOKEN_SCOPE: params.tokenScope,
    TOKEN_EXPIRES: params.tokenExpires,
    HEADED: 'false',
    FLEET_SYNC: 'true',
    FLEET_TAGS: 'autoreg,workflow',
    FLEET_IMPORT_CONCURRENCY: '3',
    OUT_DIR: 'accounts',
    LOG_DIR: 'logs',
  };
  if (params.mailApiKey) env.MAIL_API_KEY = params.mailApiKey;
  const envLines = Object.entries(env)
    .map(([key, value]) => `export ${key}=${shellQuote(value)}`)
    .join('\n');
  const args = [
    'node', 'src/run.mjs',
    '--count', String(params.count),
    '--workers', String(params.workers),
    '--threads', String(params.threads),
    '--rounds', String(params.rounds),
    '--token-scope', params.tokenScope,
    '--token-expires', params.tokenExpires,
    '--verbose',
    '--fleet-url', publicBase,
    '--fleet-key', managerKey,
    '--fleet-tags', 'autoreg,workflow',
    '--fleet-concurrency', '3',
  ];
  if (params.proxy) args.push('--proxy', params.proxy);

  return `#!/bin/sh
RUN_DIR=${shellQuote(runDir)}
PROJECT_DIR=${shellQuote(projectDir)}
BUNDLE_URL=${shellQuote(bundleUrl)}
finish() { code=$?; echo "$code" > "$RUN_DIR/exit_code"; }
trap finish EXIT
mkdir -p "$RUN_DIR" "$PROJECT_DIR"
exec >> "$RUN_DIR/run.log" 2>&1
echo $$ > "$RUN_DIR/self_pid"
echo "[fleet] $(date -u +%FT%TZ) workflow ${workflow.id} ${workflow.version}"
if [ -f "$RUN_DIR/cancel_requested" ]; then echo "[fleet] cancelled before start"; exit 130; fi
if ! command -v node >/dev/null 2>&1; then echo "[fleet] node not found (need >= 20.19)"; exit 20; fi
if ! command -v npm >/dev/null 2>&1; then echo "[fleet] npm not found"; exit 21; fi
node -e "const [a,b]=process.versions.node.split('.').map(Number); if(a<20||(a===20&&b<19)) process.exit(22)" || { echo "[fleet] node too old"; exit 22; }
node -v
npm -v
if [ ! -f "$PROJECT_DIR/package.json" ]; then
  echo "[fleet] downloading bundle"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$BUNDLE_URL" -o "$RUN_DIR/bundle.tar.gz" || exit 30
  elif command -v wget >/dev/null 2>&1; then
    wget -qO "$RUN_DIR/bundle.tar.gz" "$BUNDLE_URL" || exit 30
  else
    echo "[fleet] curl/wget not found"; exit 31
  fi
  rm -rf "$PROJECT_DIR"; mkdir -p "$PROJECT_DIR"
  tar -xzf "$RUN_DIR/bundle.tar.gz" -C "$PROJECT_DIR" || exit 32
fi
cd "$PROJECT_DIR" || exit 33
if [ ! -f "$PROJECT_DIR/.fleet-install-ok" ]; then
  echo "[fleet] installing dependencies"
  if [ -f package-lock.json ]; then
    npm ci --omit=dev --no-audit --no-fund || exit 34
  else
    npm install --omit=dev --no-audit --no-fund || exit 34
  fi
  touch "$PROJECT_DIR/.fleet-install-ok"
fi
${envLines}
echo "[fleet] starting ${workflow.entry}"
${args.map(shellQuote).join(' ')}
code=$?
echo "[fleet] workflow exited: $code"
exit $code
`;
}

function startCommand(runId) {
  const runDir = `${WORK_ROOT}/runs/${runId}`;
  return `set -e
RUN_DIR=${shellQuote(runDir)}
mkdir -p "$RUN_DIR"
cat > "$RUN_DIR/run.sh"
chmod +x "$RUN_DIR/run.sh"
cd "$RUN_DIR"
if command -v setsid >/dev/null 2>&1; then
  setsid sh "$RUN_DIR/run.sh" > "$RUN_DIR/boot.log" 2>&1 < /dev/null &
else
  nohup sh "$RUN_DIR/run.sh" > "$RUN_DIR/boot.log" 2>&1 < /dev/null &
fi
echo $! > "$RUN_DIR/pid"
cat "$RUN_DIR/pid"`;
}

function statusCommand(runId) {
  const runDir = `${WORK_ROOT}/runs/${runId}`;
  return `RUN_DIR=${shellQuote(runDir)}
PID_FILE="$RUN_DIR/self_pid"
[ -f "$PID_FILE" ] || PID_FILE="$RUN_DIR/pid"
if [ -f "$RUN_DIR/cancel_requested" ]; then echo cancelling; fi
if [ -f "$RUN_DIR/exit_code" ]; then
  echo "exit=$(cat "$RUN_DIR/exit_code")"
elif [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  echo running
else
  echo lost
fi
echo '---LOG---'
tail -n 80 "$RUN_DIR/run.log" 2>/dev/null || true`;
}

function cancelCommand(runId) {
  const runDir = `${WORK_ROOT}/runs/${runId}`;
  return `RUN_DIR=${shellQuote(runDir)}
PID_FILE="$RUN_DIR/self_pid"
[ -f "$PID_FILE" ] || PID_FILE="$RUN_DIR/pid"
mkdir -p "$RUN_DIR"
echo 1 > "$RUN_DIR/cancel_requested"
PID=$(cat "$PID_FILE" 2>/dev/null || true)
if [ -n "$PID" ]; then
  kill -TERM -"$PID" 2>/dev/null || kill -TERM "$PID" 2>/dev/null || true
  sleep 1
  kill -KILL -"$PID" 2>/dev/null || kill -KILL "$PID" 2>/dev/null || true
fi
echo cancelled`;
}

function runService(row) {
  return {
    workspace_slug: row.workspace_slug,
    slug: row.app_slug,
    env: row.env,
    region: row.region,
  };
}

export async function startWorkflowRun({
  workflowId, accountId, workspaceSlug = '', appSlug = '', component = '', params = {}, actor = 'manager', publicBase,
}) {
  const workflow = WORKFLOW_MAP.get(workflowId);
  if (!workflow) throw httpError(404, 'workflow_not_found', '工作流不存在');
  if (!accountId) throw httpError(400, 'account_required', '请选择运行账号');
  if (!publicBase) throw httpError(400, 'public_base_missing', '无法确定管理器的公网地址');
  if (!fs.existsSync(bundlePath(workflow))) {
    throw httpError(503, 'bundle_missing', '工作流源码包尚未安装到服务器');
  }
  const account = getAccountRow(accountId);
  if (!account) throw httpError(404, 'account_not_found', '账号不存在');
  if (account.status === 'banned') throw httpError(400, 'account_banned', '该账号已封号，无法运行工作流');

  const active = db.prepare(`
    SELECT id FROM workflow_runs
    WHERE account_id = ? AND workflow_id = ? AND status IN ('queued','running','cancelling')
  `).get(accountId, workflowId);
  if (active) throw httpError(409, 'already_running', `该账号已有运行中的任务：${active.id}`);

  const service = selectService(accountId, workspaceSlug, appSlug);
  if (!service) {
    throw httpError(400, 'no_container', '该账号还没有可执行容器；请先同步资产并在工作区创建应用');
  }
  const resolvedComponent = componentFor(service, component);
  const normalized = normalizeParams(workflow, params);
  const runId = newId('run');
  const bundleToken = crypto.randomBytes(24).toString('base64url');
  const bundleExpires = new Date(Date.now() + BUNDLE_TTL_MS).toISOString();
  const apiKey = createKey(`workflow:${workflowId}:${runId}`);
  const createdAt = nowIso();
  const row = {
    id: runId,
    workflow_id: workflow.id,
    workflow_name: workflow.name,
    workflow_version: workflow.version,
    account_id: account.id,
    account_label: account.label,
    workspace_slug: service.workspace_slug,
    app_slug: service.slug,
    app_label: service.name || service.slug,
    component: resolvedComponent,
    env: service.env || null,
    region: service.region || null,
    status: 'queued',
    params_json: JSON.stringify(redactParams(normalized)),
    log_tail: '',
    exit_code: null,
    error: null,
    bundle_token_hash: sha256(bundleToken),
    bundle_expires_at: bundleExpires,
    api_key_id: apiKey.id,
    cancel_requested: 0,
    poll_errors: 0,
    created_by: actor,
    created_at: createdAt,
    started_at: null,
    finished_at: null,
    last_polled_at: createdAt,
  };
  try {
    db.prepare(`
      INSERT INTO workflow_runs (
        id, workflow_id, workflow_name, workflow_version, account_id, account_label,
        workspace_slug, app_slug, app_label, component, env, region, status, params_json,
        log_tail, exit_code, error, bundle_token_hash, bundle_expires_at, api_key_id,
        cancel_requested, poll_errors, created_by, created_at, started_at, finished_at, last_polled_at
      ) VALUES (
        @id, @workflow_id, @workflow_name, @workflow_version, @account_id, @account_label,
        @workspace_slug, @app_slug, @app_label, @component, @env, @region, @status, @params_json,
        @log_tail, @exit_code, @error, @bundle_token_hash, @bundle_expires_at, @api_key_id,
        @cancel_requested, @poll_errors, @created_by, @created_at, @started_at, @finished_at, @last_polled_at
      )
    `).run(row);
  } catch (error) {
    try { deleteKey(apiKey.id); } catch { /* best effort */ }
    throw error;
  }

  const bundleUrl = `${publicBase}/api/workflows/${encodeURIComponent(workflow.id)}/bundle`
    + `?run=${encodeURIComponent(runId)}&token=${encodeURIComponent(bundleToken)}`;
  const script = runScript({
    run: row, workflow, params: normalized, bundleUrl, managerKey: apiKey.key, publicBase,
  });

  try {
    await execOnService({
      account,
      service,
      component: resolvedComponent,
      command: startCommand(runId),
      stdin: script,
      timeoutMs: 30_000,
    });
    const startedAt = nowIso();
    db.prepare(`
      UPDATE workflow_runs SET status = 'running', started_at = ?, last_polled_at = ? WHERE id = ?
    `).run(startedAt, startedAt, runId);
    audit(actor, 'workflow.start', {
      id: runId, workflowId, accountId, app: service.slug, component: resolvedComponent,
    });
    return getWorkflowRun(runId);
  } catch (error) {
    try {
      await execOnService({
        account,
        service,
        component: resolvedComponent,
        command: cancelCommand(runId),
        timeoutMs: 10_000,
      });
    } catch { /* best effort */ }
    try { deleteKey(apiKey.id); } catch { /* best effort */ }
    db.prepare(`
      UPDATE workflow_runs SET status = 'failed', error = ?, finished_at = ?, last_polled_at = ?,
        api_key_id = NULL, bundle_token_hash = NULL, bundle_expires_at = NULL WHERE id = ?
    `).run(String(error.message || error).slice(0, 1000), nowIso(), nowIso(), runId);
    throw error;
  }
}

export async function cancelWorkflowRun(id, actor) {
  const row = db.prepare('SELECT * FROM workflow_runs WHERE id = ?').get(id);
  if (!row) throw httpError(404, 'run_not_found', '任务不存在');
  if (!ACTIVE.includes(row.status)) return publicRun(row);
  if (row.status !== 'cancelling') {
    db.prepare("UPDATE workflow_runs SET status = 'cancelling', cancel_requested = 1 WHERE id = ?").run(id);
  }
  const account = getAccountRow(row.account_id);
  if (!account) throw httpError(404, 'account_not_found', '账号已删除');
  try {
    await execOnService({
      account,
      service: runService(row),
      component: row.component,
      command: cancelCommand(row.id),
      timeoutMs: 15_000,
    });
    audit(actor, 'workflow.cancel', { id, workflowId: row.workflow_id, accountId: row.account_id });
    return getWorkflowRun(id);
  } catch (error) {
    db.prepare(`
      UPDATE workflow_runs SET error = ?, status = CASE WHEN status = 'cancelling' THEN 'running' ELSE status END
      WHERE id = ?
    `).run(`取消失败：${String(error.message || error).slice(0, 900)}`, id);
    throw error;
  }
}

export function resolveWorkflowBundle(workflowId, runId, token) {
  const workflow = WORKFLOW_MAP.get(workflowId);
  if (!workflow || !token) return null;
  const file = bundlePath(workflow);
  if (!fs.existsSync(file)) return null;
  const row = db.prepare(`
    SELECT bundle_token_hash, bundle_expires_at FROM workflow_runs
    WHERE id = ? AND workflow_id = ?
  `).get(runId, workflowId);
  if (!row?.bundle_token_hash) return null;
  if (sha256(token) !== row.bundle_token_hash) return null;
  if (row.bundle_expires_at && Date.parse(row.bundle_expires_at) < Date.now()) return null;
  return { file, workflow };
}

function finishRun(row, status, { exitCode = null, error = null, logTail } = {}) {
  const finished = nowIso();
  db.prepare(`
    UPDATE workflow_runs SET status = ?, exit_code = ?, error = ?, log_tail = ?,
      finished_at = ?, last_polled_at = ?, poll_errors = 0,
      bundle_token_hash = NULL, bundle_expires_at = NULL
    WHERE id = ?
  `).run(status, exitCode, error ? String(error).slice(0, 1000) : null,
    logTail ?? row.log_tail ?? '', finished, finished, row.id);
  if (row.api_key_id) {
    try { deleteKey(row.api_key_id); } catch { /* best effort */ }
    db.prepare('UPDATE workflow_runs SET api_key_id = NULL WHERE id = ?').run(row.id);
  }
  audit('workflow', 'workflow.finish', { id: row.id, workflowId: row.workflow_id, status, exitCode });
  log.info(`[workflow] ${row.id} ${status}${exitCode != null ? ` exit=${exitCode}` : ''}`);
  return getWorkflowRun(row.id);
}

function parseLog(output) {
  const marker = output.indexOf('---LOG---');
  if (marker < 0) return '';
  return output.slice(marker + 9).trim().slice(-12_000);
}

async function pollRun(row) {
  if (row.status === 'queued' && Date.now() - Date.parse(row.created_at) < 30_000) return;
  if (row.last_polled_at && Date.now() - Date.parse(row.last_polled_at) < 8_000) return;
  const account = getAccountRow(row.account_id);
  if (!account) {
    finishRun(row, 'failed', { error: '账号已删除' });
    return;
  }
  let result;
  try {
    result = await execOnService({
      account,
      service: runService(row),
      component: row.component,
      command: statusCommand(row.id),
      timeoutMs: 30_000,
    });
  } catch (error) {
    const errors = Number(row.poll_errors || 0) + 1;
    if (errors >= 12) {
      finishRun(row, row.status === 'cancelling' ? 'cancelled' : 'failed', {
        error: `状态轮询连续失败：${error.message}`,
      });
      return;
    }
    db.prepare(`
      UPDATE workflow_runs SET poll_errors = ?, error = ?, last_polled_at = ? WHERE id = ?
    `).run(errors, String(error.message || error).slice(0, 1000), nowIso(), row.id);
    return;
  }

  const output = String(result?.output || '');
  const logTail = parseLog(output);
  const exitMatch = /(?:^|\n)exit=(-?\d+)(?:\n|$)/.exec(output);
  const running = /(?:^|\n)running(?:\n|$)/.test(output);
  const lost = /(?:^|\n)lost(?:\n|$)/.test(output);
  const cancelling = /(?:^|\n)cancelling(?:\n|$)/.test(output);

  if (exitMatch) {
    const exitCode = Number(exitMatch[1]);
    const cancelled = row.cancel_requested || row.status === 'cancelling';
    finishRun(row, cancelled ? 'cancelled' : exitCode === 0 ? 'succeeded' : 'failed', {
      exitCode, logTail, error: cancelled ? null : exitCode === 0 ? null : `进程退出码 ${exitCode}`,
    });
    return;
  }
  if (lost) {
    finishRun(row, row.cancel_requested || row.status === 'cancelling' ? 'cancelled' : 'failed', {
      logTail,
      error: row.cancel_requested || row.status === 'cancelling' ? null : '进程已退出但未写入退出码',
    });
    return;
  }
  const nextStatus = cancelling ? 'cancelling' : row.status === 'queued' ? 'running' : row.status;
  db.prepare(`
    UPDATE workflow_runs SET status = ?, log_tail = ?, last_polled_at = ?, poll_errors = 0,
      started_at = COALESCE(started_at, ?), error = NULL
    WHERE id = ?
  `).run(nextStatus, logTail, nowIso(), nowIso(), row.id);
}

let timer = null;
let polling = false;
let initialized = false;

async function pollAll() {
  if (polling) return;
  polling = true;
  try {
    const rows = db.prepare(`
      SELECT * FROM workflow_runs WHERE status IN ('queued','running','cancelling')
      ORDER BY created_at LIMIT 100
    `).all();
    for (let i = 0; i < rows.length; i += 4) {
      await Promise.all(rows.slice(i, i + 4).map((row) => pollRun(row).catch((error) => {
        log.warn(`[workflow] poll ${row.id} failed`, error);
      })));
    }
  } finally {
    polling = false;
  }
}

export function initWorkflowRunner() {
  if (initialized) return;
  initialized = true;
  for (const row of db.prepare(`
    SELECT id, api_key_id FROM workflow_runs
    WHERE api_key_id IS NOT NULL AND status NOT IN ('queued','running','cancelling')
  `).all()) {
    try { deleteKey(row.api_key_id); } catch { /* best effort */ }
    db.prepare('UPDATE workflow_runs SET api_key_id = NULL WHERE id = ?').run(row.id);
  }
  if (timer) clearInterval(timer);
  timer = setInterval(() => {
    pollAll().catch((error) => log.error('[workflow] poll loop failed', error));
  }, 10_000);
  timer.unref?.();
  setTimeout(() => {
    pollAll().catch((error) => log.error('[workflow] initial poll failed', error));
  }, 5_000).unref?.();
  log.info(`[workflow] runner started · ${listWorkflows().filter((item) => item.bundleAvailable).length} bundle(s)`);
}

export function stopWorkflowRunner() {
  if (timer) clearInterval(timer);
  timer = null;
}
