/**
 * Workflow projects.
 *
 * Host workflows run as detached processes on the manager host (for example
 * cloady_auto_depoly, which deploys an app into a selected Cloady account).
 * Container workflows keep the original exec-based runner for app containers.
 * Both expose logs, status and cancellation through the same run table.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync, spawn } from 'node:child_process';
import { CONFIG, log } from './config.mjs';
import { db, json, audit, settings } from './db.mjs';
import { newId, sha256, encryptSecret, decryptSecret } from './lib/crypto.mjs';
import { getAccountRow, getAccountToken } from './accounts.mjs';
import { createKey, deleteKey } from './auth.mjs';
import { rawRequest } from './lib/cloady.mjs';
import { HttpError } from './lib/http.mjs';

const WORK_ROOT = '/tmp/cloady-fleet-workflows';
const HOST_ROOT = path.join(CONFIG.workflowsDir, 'runs');
const BUNDLE_TTL_MS = 60 * 60_000;

export const WORKFLOWS = [
  {
    id: 'cloady_auto_depoly',
    name: 'Cloady Auto Deploy',
    version: '8814e6f',
    repo: 'https://github.com/xbox-cn/cloady_auto_depoly',
    runner: 'host',
    description: '把 Twitch 注册机直接部署到所选账号的 Cloady workspace，并在容器内自动循环注册。',
    notes: '在管理器主机执行，源码包本地内置，不访问 GitHub。需要 Python 3 + requests；账号 token 需要 deploy/full 权限。上传接口固定为 http://<SERVER_IP>:5000/api/accounts/upload。WARP 出口被 Twitch Kasada 拒绝时，把 WARP 设为 0 并填写注册代理。',
    bundleFile: 'cloady_auto_depoly-8814e6f.tar.gz',
    entry: 'python3 deploy_twreg.py',
    fields: [
      { key: 'serverIp', label: '账号上传服务器 IP', type: 'text', default: '47.98.228.129', required: true, placeholder: '47.98.228.129' },
      { key: 'workers', label: '线程数', type: 'number', default: 3, min: 1, max: 20 },
      { key: 'accounts', label: '每轮账号数', type: 'number', default: 15, min: 1, max: 100 },
      { key: 'maxRounds', label: '最多轮数（0 不限）', type: 'number', default: 0, min: 0, max: 100 },
      { key: 'maxTotal', label: '最多注册数（0 不限）', type: 'number', default: 0, min: 0, max: 100000 },
      { key: 'useWarp', label: '每轮更换 WARP 出口（1=开启，0=关闭；用代理时选 0）', type: 'select', default: '1', options: ['1', '0'] },
      { key: 'enableUpload', label: '上传账号到服务器（1=开启，0=关闭）', type: 'select', default: '1', options: ['1', '0'] },
      { key: 'region', label: 'Region（留空自动）', type: 'text', default: '', placeholder: 'use1' },
      { key: 'workspace', label: 'Workspace（留空自动）', type: 'text', default: '' },
      { key: 'app', label: '应用名', type: 'text', default: 'twreg-ruyijs' },
      { key: 'mailApi', label: '临时邮箱 API', type: 'text', default: 'https://mail.minecraft.fashion' },
      { key: 'mailDomain', label: '邮箱域名', type: 'text', default: '*.jsip.us' },
      { key: 'proxy', label: '访问 Cloady 的代理', type: 'text', default: '', placeholder: 'http://127.0.0.1:7890' },
      { key: 'regProxy', label: '注册代理（WARP 关闭时使用）', type: 'text', default: '', placeholder: 'http://user:pass@host:port' },
      { key: 'dryRun', label: '只做源码自检', type: 'select', default: '0', options: ['0', '1'] },
    ],
  },
];

const WORKFLOW_MAP = new Map(WORKFLOWS.map((workflow) => [workflow.id, workflow]));
const ACTIVE = ['queued', 'running', 'cancelling'];

fs.mkdirSync(CONFIG.workflowsDir, { recursive: true, mode: 0o700 });

function httpError(status, code, message) {
  return new HttpError(status, code, message);
}

function nowIso() {
  return new Date().toISOString();
}

function bundlePath(workflow) {
  return path.join(CONFIG.workflowsDir, workflow.bundleFile);
}

function shellQuote(value) {
  return `'${String(value ?? '').replace(/'/g, "'\\''")}'`;
}

function clampNumber(value, field) {
  const n = Number(value);
  const base = Number.isFinite(n) ? n : Number(field.default || 0);
  return Math.max(field.min ?? 0, Math.min(field.max ?? Number.MAX_SAFE_INTEGER, Math.round(base)));
}

function normalizeParams(workflow, input = {}) {
  const out = {};
  for (const field of workflow.fields) {
    const raw = input[field.key] ?? field.default;
    if (field.required && String(raw ?? '').trim() === '') {
      throw httpError(400, 'missing_field', `缺少必填参数：${field.label}`);
    }
    if (field.type === 'number') out[field.key] = clampNumber(raw, field);
    else out[field.key] = String(raw ?? '').slice(0, field.type === 'password' ? 400 : 1000);
  }
  return out;
}

function redactParams(params = {}) {
  const out = { ...params };
  if (out.mailApiKey) out.mailApiKey = '••••';
  if (out.proxy) {
    out.proxy = String(out.proxy).replace(/:\/\/([^:@/]+):([^@/]+)@/, '://$1:***@');
  }
  if (out.regProxy) {
    out.regProxy = String(out.regProxy).replace(/:\/\/([^:@/]+):([^@/]+)@/, '://$1:***@');
  }
  return out;
}

function selectService(accountId, workspaceSlug, appSlug) {
  const rows = db.prepare(`
    SELECT * FROM services WHERE account_id = ?
    ORDER BY (status = 'running') DESC, id
  `).all(accountId);
  let matched = rows;
  if (workspaceSlug) matched = matched.filter((row) => row.workspace_slug === workspaceSlug);
  if (appSlug) matched = matched.filter((row) => row.slug === appSlug);
  return matched[0] || null;
}

function componentFor(service, requested) {
  if (requested) return String(requested).slice(0, 200);
  const sub = json(service.sub_services_json, []);
  return String(sub?.[0]?.name || service.slug || 'app').slice(0, 200);
}

function publicBaseFromRequest(req) {
  if (CONFIG.publicBaseUrl) return CONFIG.publicBaseUrl;
  const proto = String(req.headers['x-forwarded-proto'] || 'http').split(',')[0].trim() || 'http';
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
  return host ? `${proto}://${host}`.replace(/\/+$/, '') : '';
}

export { publicBaseFromRequest };

export function listWorkflows() {
  return WORKFLOWS.map((workflow) => {
    const file = bundlePath(workflow);
    let size = 0;
    try { size = fs.statSync(file).size; } catch { /* missing */ }
    return {
      id: workflow.id,
      name: workflow.name,
      version: workflow.version,
      repo: workflow.repo,
      runner: workflow.runner || 'container',
      description: workflow.description,
      notes: workflow.notes,
      entry: workflow.entry,
      fields: workflow.fields,
      bundleAvailable: size > 0,
      bundleBytes: size,
    };
  });
}

export function publicRun(row) {
  if (!row) return null;
  const started = row.started_at ? Date.parse(row.started_at) : 0;
  const finished = row.finished_at ? Date.parse(row.finished_at) : 0;
  return {
    id: row.id,
    workflowId: row.workflow_id,
    workflowName: row.workflow_name,
    workflowVersion: row.workflow_version,
    runner: row.runner || 'container',
    accountId: row.account_id,
    accountLabel: row.account_label,
    workspaceSlug: row.workspace_slug,
    appSlug: row.app_slug,
    appLabel: row.app_label,
    component: row.component,
    status: row.status,
    params: redactParams(json(row.params_json, {})),
    logTail: row.log_tail || '',
    exitCode: row.exit_code,
    error: row.error,
    createdAt: row.created_at,
    startedAt: row.started_at,
    finishedAt: row.finished_at,
    lastPolledAt: row.last_polled_at,
    durationMs: started ? (finished || Date.now()) - started : 0,
  };
}

export function listWorkflowRuns({ page = 1, pageSize = 20, workflow = '', status = '', query = '' } = {}) {
  const where = [];
  const params = [];
  if (workflow) { where.push('workflow_id = ?'); params.push(workflow); }
  if (status === 'active') {
    where.push("status IN ('queued','running','cancelling')");
  } else if (status) {
    where.push('status = ?');
    params.push(status);
  }
  const q = String(query || '').trim();
  if (q) {
    where.push('(account_label LIKE ? OR app_label LIKE ? OR app_slug LIKE ? OR id LIKE ?)');
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db.prepare(`SELECT COUNT(*) AS n FROM workflow_runs ${whereSql}`).get(...params).n;
  const size = Math.max(1, Math.min(100, Number(pageSize) || 20));
  const offset = (Math.max(1, Number(page) || 1) - 1) * size;
  const rows = db.prepare(`
    SELECT * FROM workflow_runs ${whereSql}
    ORDER BY created_at DESC LIMIT ? OFFSET ?
  `).all(...params, size, offset);
  const counts = db.prepare(`
    SELECT status, COUNT(*) AS n FROM workflow_runs
    ${workflow ? 'WHERE workflow_id = ?' : ''}
    GROUP BY status
  `).all(...(workflow ? [workflow] : []))
    .reduce((acc, row) => ({ ...acc, [row.status]: row.n }), {});
  return {
    items: rows.map(publicRun),
    total,
    page: Math.max(1, Number(page) || 1),
    pageSize: size,
    counts,
  };
}

export function getWorkflowRun(id) {
  return publicRun(db.prepare('SELECT * FROM workflow_runs WHERE id = ?').get(id));
}

function execPath(service) {
  return `/api/workspaces/${encodeURIComponent(service.workspace_slug)}`
    + `/apps/${encodeURIComponent(service.slug)}/exec`;
}

async function execOnService({ account, service, component, command, stdin, timeoutMs = 30_000 }) {
  const token = getAccountToken(account);
  const query = {};
  if (service.env) query.env = service.env;
  if (service.region) query.region = service.region;
  const res = await rawRequest({
    token,
    method: 'POST',
    path: execPath(service),
    query,
    body: {
      component,
      command,
      ...(stdin ? { stdin } : {}),
      timeoutMs,
    },
    timeoutMs: timeoutMs + 5_000,
  }).catch((error) => {
    throw httpError(502, 'exec_failed', `容器命令失败：${error.message}`);
  });
  if (!res.ok) {
    throw httpError(res.status === 401 || res.status === 403 ? res.status : 502,
      'exec_failed', `容器命令失败：HTTP ${res.status} ${JSON.stringify(res.data).slice(0, 300)}`);
  }
  if (res.data?.timedOut) {
    throw httpError(504, 'exec_timeout', '容器命令超时');
  }
  if (res.data?.exit != null && Number(res.data.exit) !== 0) {
    throw httpError(502, 'exec_exit',
      `容器命令退出码 ${res.data.exit}：${String(res.data.output || '').slice(-500)}`);
  }
  return res.data;
}

function runScript({ run, workflow, params, bundleUrl, managerKey, publicBase }) {
  const runDir = `${WORK_ROOT}/runs/${run.id}`;
  const projectDir = `${WORK_ROOT}/projects/${workflow.id}-${workflow.version}`;
  const env = {
    TARGET_URL: 'https://cloady.com',
    LOGIN_PATH: '/login',
    MAIL_API: params.mailApi,
    MAIL_DOMAIN: params.mailDomain,
    TOKEN_SCOPE: params.tokenScope,
    TOKEN_EXPIRES: params.tokenExpires,
    HEADED: 'false',
    FLEET_SYNC: 'true',
    FLEET_TAGS: 'autoreg,workflow',
    FLEET_IMPORT_CONCURRENCY: '3',
    OUT_DIR: 'accounts',
    LOG_DIR: 'logs',
  };
  if (params.mailApiKey) env.MAIL_API_KEY = params.mailApiKey;
  const envLines = Object.entries(env)
    .map(([key, value]) => `export ${key}=${shellQuote(value)}`)
    .join('\n');
  const args = [
    'node', 'src/run.mjs',
    '--count', String(params.count),
    '--workers', String(params.workers),
    '--threads', String(params.threads),
    '--rounds', String(params.rounds),
    '--token-scope', params.tokenScope,
    '--token-expires', params.tokenExpires,
    '--verbose',
    '--fleet-url', publicBase,
    '--fleet-key', managerKey,
    '--fleet-tags', 'autoreg,workflow',
    '--fleet-concurrency', '3',
  ];
  if (params.proxy) args.push('--proxy', params.proxy);

  return `#!/bin/sh
RUN_DIR=${shellQuote(runDir)}
PROJECT_DIR=${shellQuote(projectDir)}
BUNDLE_URL=${shellQuote(bundleUrl)}
finish() { code=$?; echo "$code" > "$RUN_DIR/exit_code"; }
trap finish EXIT
mkdir -p "$RUN_DIR" "$PROJECT_DIR"
exec >> "$RUN_DIR/run.log" 2>&1
echo $$ > "$RUN_DIR/self_pid"
echo "[fleet] $(date -u +%FT%TZ) workflow ${workflow.id} ${workflow.version}"
if [ -f "$RUN_DIR/cancel_requested" ]; then echo "[fleet] cancelled before start"; exit 130; fi
if ! command -v node >/dev/null 2>&1; then echo "[fleet] node not found (need >= 20.19)"; exit 20; fi
if ! command -v npm >/dev/null 2>&1; then echo "[fleet] npm not found"; exit 21; fi
node -e "const [a,b]=process.versions.node.split('.').map(Number); if(a<20||(a===20&&b<19)) process.exit(22)" || { echo "[fleet] node too old"; exit 22; }
node -v
npm -v
if [ ! -f "$PROJECT_DIR/package.json" ]; then
  echo "[fleet] downloading bundle"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$BUNDLE_URL" -o "$RUN_DIR/bundle.tar.gz" || exit 30
  elif command -v wget >/dev/null 2>&1; then
    wget -qO "$RUN_DIR/bundle.tar.gz" "$BUNDLE_URL" || exit 30
  else
    echo "[fleet] curl/wget not found"; exit 31
  fi
  rm -rf "$PROJECT_DIR"; mkdir -p "$PROJECT_DIR"
  tar -xzf "$RUN_DIR/bundle.tar.gz" -C "$PROJECT_DIR" || exit 32
fi
cd "$PROJECT_DIR" || exit 33
if [ ! -f "$PROJECT_DIR/.fleet-install-ok" ]; then
  echo "[fleet] installing dependencies"
  if [ -f package-lock.json ]; then
    npm ci --omit=dev --no-audit --no-fund || exit 34
  else
    npm install --omit=dev --no-audit --no-fund || exit 34
  fi
  touch "$PROJECT_DIR/.fleet-install-ok"
fi
${envLines}
echo "[fleet] starting ${workflow.entry}"
${args.map(shellQuote).join(' ')}
code=$?
echo "[fleet] workflow exited: $code"
exit $code
`;
}

function startCommand(runId) {
  const runDir = `${WORK_ROOT}/runs/${runId}`;
  return `set -e
RUN_DIR=${shellQuote(runDir)}
mkdir -p "$RUN_DIR"
cat > "$RUN_DIR/run.sh"
chmod +x "$RUN_DIR/run.sh"
cd "$RUN_DIR"
if command -v setsid >/dev/null 2>&1; then
  setsid sh "$RUN_DIR/run.sh" > "$RUN_DIR/boot.log" 2>&1 < /dev/null &
else
  nohup sh "$RUN_DIR/run.sh" > "$RUN_DIR/boot.log" 2>&1 < /dev/null &
fi
echo $! > "$RUN_DIR/pid"
cat "$RUN_DIR/pid"`;
}

function statusCommand(runId) {
  const runDir = `${WORK_ROOT}/runs/${runId}`;
  return `RUN_DIR=${shellQuote(runDir)}
PID_FILE="$RUN_DIR/self_pid"
[ -f "$PID_FILE" ] || PID_FILE="$RUN_DIR/pid"
if [ -f "$RUN_DIR/cancel_requested" ]; then echo cancelling; fi
if [ -f "$RUN_DIR/exit_code" ]; then
  echo "exit=$(cat "$RUN_DIR/exit_code")"
elif [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  echo running
else
  echo lost
fi
echo '---LOG---'
tail -n 80 "$RUN_DIR/run.log" 2>/dev/null || true`;
}

function cancelCommand(runId) {
  const runDir = `${WORK_ROOT}/runs/${runId}`;
  return `RUN_DIR=${shellQuote(runDir)}
PID_FILE="$RUN_DIR/self_pid"
[ -f "$PID_FILE" ] || PID_FILE="$RUN_DIR/pid"
mkdir -p "$RUN_DIR"
echo 1 > "$RUN_DIR/cancel_requested"
PID=$(cat "$PID_FILE" 2>/dev/null || true)
if [ -n "$PID" ]; then
  kill -TERM -"$PID" 2>/dev/null || kill -TERM "$PID" 2>/dev/null || true
  sleep 1
  kill -KILL -"$PID" 2>/dev/null || kill -KILL "$PID" 2>/dev/null || true
fi
echo cancelled`;
}

function runService(row) {
  return {
    workspace_slug: row.workspace_slug,
    slug: row.app_slug,
    env: row.env,
    region: row.region,
  };
}

function hostProjectDir(workflow) {
  return path.join(CONFIG.workflowsDir, 'projects', `${workflow.id}-${workflow.version}`);
}

function ensureHostProject(workflow) {
  const dir = hostProjectDir(workflow);
  const entry = path.join(dir, 'deploy_twreg.py');
  if (!fs.existsSync(entry)) {
    fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    try {
      execFileSync('tar', ['-xzf', bundlePath(workflow), '-C', dir], { stdio: 'ignore' });
    } catch (error) {
      throw httpError(500, 'bundle_extract_failed', `解压工作流源码失败：${error.message}`);
    }
  }
  if (!fs.existsSync(entry)) {
    throw httpError(500, 'bundle_invalid', '工作流源码包缺少 deploy_twreg.py');
  }
  return dir;
}

function hostRunDir(runId) {
  return path.join(HOST_ROOT, runId);
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function readPid(runDir) {
  for (const name of ['self_pid', 'pid']) {
    try {
      const pid = Number(fs.readFileSync(path.join(runDir, name), 'utf8').trim());
      if (Number.isFinite(pid) && pid > 0) return pid;
    } catch { /* try next */ }
  }
  return null;
}

function processAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function readLogTail(file, max = 12_000) {
  try {
    const stat = fs.statSync(file);
    if (!stat.size) return '';
    const length = Math.min(max, stat.size);
    const buffer = Buffer.alloc(length);
    const fd = fs.openSync(file, 'r');
    try {
      fs.readSync(fd, buffer, 0, length, stat.size - length);
    } finally {
      fs.closeSync(fd);
    }
    return buffer.toString('utf8');
  } catch {
    return '';
  }
}

function hostScript({ runId, workflow, params, projectDir }) {
  const runDir = hostRunDir(runId);
  const args = [
    'python3', 'deploy_twreg.py',
    '--source-dir', projectDir,
    '--server-ip', params.serverIp,
    '--workers', String(params.workers),
    '--accounts', String(params.accounts),
    '--max-rounds', String(params.maxRounds),
    '--max-total', String(params.maxTotal),
    '--use-warp', params.useWarp,
    '--enable-upload', params.enableUpload,
    '--mail-api', params.mailApi,
    '--mail-domain', params.mailDomain,
    '--app', params.app,
  ];
  if (params.region) args.push('--region', params.region);
  if (params.workspace) args.push('--workspace', params.workspace);
  if (params.proxy) args.push('--proxy', params.proxy);
  if (params.regProxy) args.push('--reg-proxy', params.regProxy);
  if (params.dryRun === '1') args.push('--dry-run');
  return `#!/bin/bash
RUN_DIR=${shellQuote(runDir)}
finish() { code=$?; echo "$code" > "$RUN_DIR/exit_code"; }
trap finish EXIT
mkdir -p "$RUN_DIR"
exec >> "$RUN_DIR/run.log" 2>&1
echo $$ > "$RUN_DIR/self_pid"
echo "[fleet] $(date -u +%FT%TZ) host workflow ${workflow.id} ${workflow.version}"
cd ${shellQuote(projectDir)} || exit 40
if ! command -v python3 >/dev/null 2>&1; then echo "[fleet] python3 not found"; exit 41; fi
if ! python3 -c 'import requests' >/dev/null 2>&1; then echo "[fleet] python requests not installed"; exit 42; fi
${args.map(shellQuote).join(' ')}
code=$?
echo "[fleet] workflow exited: $code"
exit $code
`;
}

function spawnHostRun(runId, script, token) {
  const runDir = hostRunDir(runId);
  fs.mkdirSync(runDir, { recursive: true, mode: 0o700 });
  const scriptPath = path.join(runDir, 'run.sh');
  fs.writeFileSync(scriptPath, script, { mode: 0o700 });
  const logFd = fs.openSync(path.join(runDir, 'spawn.log'), 'a');
  const useSetsid = fs.existsSync('/usr/bin/setsid') || fs.existsSync('/bin/setsid');
  const command = useSetsid ? 'setsid' : 'bash';
  const args = useSetsid ? ['bash', scriptPath] : [scriptPath];
  let child;
  try {
    child = spawn(command, args, {
      detached: true,
      stdio: ['ignore', logFd, logFd],
      env: { ...process.env, CLOADY_TOKEN: token, PYTHONUNBUFFERED: '1' },
    });
  } finally {
    fs.closeSync(logFd);
  }
  if (!child.pid) throw httpError(500, 'spawn_failed', '无法启动宿主机进程');
  child.unref();
  fs.writeFileSync(path.join(runDir, 'pid'), String(child.pid));
  return child.pid;
}

const HOST_CONCURRENCY_DEFAULT = 12;
const HOST_CONCURRENCY_MAX = 32;

export function getHostConcurrency() {
  const stored = Number(settings.get('workflow_host_concurrency'));
  const fallback = Number(process.env.WORKFLOW_HOST_CONCURRENCY || HOST_CONCURRENCY_DEFAULT);
  const value = Number.isFinite(stored) && stored > 0 ? stored : fallback;
  return Math.max(1, Math.min(HOST_CONCURRENCY_MAX, Math.round(value || HOST_CONCURRENCY_DEFAULT)));
}

export function setHostConcurrency(value) {
  const next = Math.max(1, Math.min(HOST_CONCURRENCY_MAX, Math.round(Number(value) || HOST_CONCURRENCY_DEFAULT)));
  settings.set('workflow_host_concurrency', String(next));
  pumpHostQueue();
  return next;
}

let pumpingHosts = false;

function createHostRun({ workflow, account, params, actor }) {
  const runId = newId('run');
  const createdAt = nowIso();
  const row = {
    id: runId,
    runner: 'host',
    workflow_id: workflow.id,
    workflow_name: workflow.name,
    workflow_version: workflow.version,
    account_id: account.id,
    account_label: account.label,
    workspace_slug: '',
    app_slug: String(params.app || ''),
    app_label: '管理器主机',
    component: 'host',
    env: null,
    region: params.region || null,
    status: 'queued',
    params_json: JSON.stringify(redactParams(params)),
    secret_json: encryptSecret(JSON.stringify(params)),
    log_tail: '',
    exit_code: null,
    error: null,
    bundle_token_hash: null,
    bundle_expires_at: null,
    api_key_id: null,
    cancel_requested: 0,
    poll_errors: 0,
    created_by: actor,
    created_at: createdAt,
    started_at: null,
    finished_at: null,
    last_polled_at: createdAt,
  };
  db.prepare(`
    INSERT INTO workflow_runs (
      id, runner, workflow_id, workflow_name, workflow_version, account_id, account_label,
      workspace_slug, app_slug, app_label, component, env, region, status, params_json, secret_json,
      log_tail, exit_code, error, bundle_token_hash, bundle_expires_at, api_key_id,
      cancel_requested, poll_errors, created_by, created_at, started_at, finished_at, last_polled_at
    ) VALUES (
      @id, @runner, @workflow_id, @workflow_name, @workflow_version, @account_id, @account_label,
      @workspace_slug, @app_slug, @app_label, @component, @env, @region, @status, @params_json, @secret_json,
      @log_tail, @exit_code, @error, @bundle_token_hash, @bundle_expires_at, @api_key_id,
      @cancel_requested, @poll_errors, @created_by, @created_at, @started_at, @finished_at, @last_polled_at
    )
  `).run(row);
  return row;
}

function launchHostRun(row) {
  const workflow = WORKFLOW_MAP.get(row.workflow_id);
  const account = getAccountRow(row.account_id);
  if (!workflow || !account || !row.secret_json) {
    db.prepare(`
      UPDATE workflow_runs SET status = 'failed', error = ?, finished_at = ?, last_polled_at = ?,
        secret_json = NULL WHERE id = ?
    `).run('账号或工作流已不存在', nowIso(), nowIso(), row.id);
    return false;
  }
  let params;
  try {
    params = JSON.parse(decryptSecret(row.secret_json));
  } catch {
    db.prepare(`
      UPDATE workflow_runs SET status = 'failed', error = ?, finished_at = ?, last_polled_at = ?,
        secret_json = NULL WHERE id = ?
    `).run('运行参数解密失败', nowIso(), nowIso(), row.id);
    return false;
  }
  const projectDir = ensureHostProject(workflow);
  const token = getAccountToken(account);
  try {
    spawnHostRun(row.id, hostScript({ runId: row.id, workflow, params, projectDir }), token);
  } catch (error) {
    db.prepare(`
      UPDATE workflow_runs SET status = 'failed', error = ?, finished_at = ?, last_polled_at = ?,
        secret_json = NULL WHERE id = ?
    `).run(String(error.message || error).slice(0, 1000), nowIso(), nowIso(), row.id);
    return false;
  }
  const startedAt = nowIso();
  db.prepare(`
    UPDATE workflow_runs SET status = 'running', started_at = ?, last_polled_at = ?,
      secret_json = NULL WHERE id = ?
  `).run(startedAt, startedAt, row.id);
  audit(row.created_by || 'workflow', 'workflow.start', {
    id: row.id, workflowId: workflow.id, accountId: account.id, runner: 'host', app: params.app,
  });
  return true;
}

function pumpHostQueue() {
  if (pumpingHosts) return;
  pumpingHosts = true;
  try {
    const running = db.prepare(`
      SELECT COUNT(*) AS n FROM workflow_runs WHERE runner = 'host' AND status = 'running'
    `).get().n;
    const slots = getHostConcurrency() - running;
    if (slots <= 0) return;
    const rows = db.prepare(`
      SELECT * FROM workflow_runs WHERE runner = 'host' AND status = 'queued'
      ORDER BY created_at LIMIT ?
    `).all(slots);
    let failed = 0;
    for (const row of rows) {
      try {
        if (!launchHostRun(row)) failed += 1;
      } catch (error) {
        failed += 1;
        db.prepare(`
          UPDATE workflow_runs SET status = 'failed', error = ?, finished_at = ?, last_polled_at = ?,
            secret_json = NULL WHERE id = ?
        `).run(String(error.message || error).slice(0, 1000), nowIso(), nowIso(), row.id);
      }
    }
    if (failed > 0) {
      setImmediate(() => {
        pumpingHosts = false;
        pumpHostQueue();
      });
      return;
    }
  } finally {
    pumpingHosts = false;
  }
}

function startHostWorkflow({ workflow, account, params, actor }) {
  const row = createHostRun({ workflow, account, params, actor });
  pumpHostQueue();
  return getWorkflowRun(row.id);
}

async function cancelHostRun(row) {
  const runDir = hostRunDir(row.id);
  fs.mkdirSync(runDir, { recursive: true, mode: 0o700 });
  fs.writeFileSync(path.join(runDir, 'cancel_requested'), '1');
  const pid = readPid(runDir);
  if (pid) {
    try { process.kill(-pid, 'SIGTERM'); } catch { try { process.kill(pid, 'SIGTERM'); } catch { /* gone */ } }
    await delay(1000);
    try { process.kill(-pid, 'SIGKILL'); } catch { try { process.kill(pid, 'SIGKILL'); } catch { /* gone */ } }
  }
}

async function pollHostRun(row) {
  if (row.status === 'queued') return;
  const runDir = hostRunDir(row.id);
  if (!fs.existsSync(runDir)) {
    finishRun(row, row.status === 'cancelling' ? 'cancelled' : 'failed', { error: '运行目录不存在' });
    return;
  }
  const logTail = readLogTail(path.join(runDir, 'run.log'))
    || readLogTail(path.join(runDir, 'spawn.log'));
  const exitFile = path.join(runDir, 'exit_code');
  if (fs.existsSync(exitFile)) {
    const exitCode = Number(fs.readFileSync(exitFile, 'utf8').trim());
    const cancelled = row.cancel_requested || row.status === 'cancelling';
    finishRun(row, cancelled ? 'cancelled' : exitCode === 0 ? 'succeeded' : 'failed', {
      exitCode: Number.isFinite(exitCode) ? exitCode : null,
      logTail,
      error: cancelled ? null : exitCode === 0 ? null : `进程退出码 ${exitCode}`,
    });
    return;
  }
  const pid = readPid(runDir);
  if (pid && processAlive(pid)) {
    const now = nowIso();
    db.prepare(`
      UPDATE workflow_runs SET status = ?, log_tail = ?, last_polled_at = ?,
        started_at = COALESCE(started_at, ?), error = NULL, poll_errors = 0
      WHERE id = ?
    `).run(row.status === 'cancelling' ? 'cancelling' : 'running', logTail, now, now, row.id);
    return;
  }
  if (row.status === 'queued' && Date.now() - Date.parse(row.created_at) < 30_000) return;
  finishRun(row, row.status === 'cancelling' || row.cancel_requested ? 'cancelled' : 'failed', {
    logTail,
    error: row.status === 'cancelling' || row.cancel_requested ? null : '进程已退出但未写入退出码',
  });
}

export async function startWorkflowRun({
  workflowId, accountId, workspaceSlug = '', appSlug = '', component = '', params = {}, actor = 'manager', publicBase,
}) {
  const workflow = WORKFLOW_MAP.get(workflowId);
  if (!workflow) throw httpError(404, 'workflow_not_found', '工作流不存在');
  if (!accountId) throw httpError(400, 'account_required', '请选择运行账号');
  if (!fs.existsSync(bundlePath(workflow))) {
    throw httpError(503, 'bundle_missing', '工作流源码包尚未安装到服务器');
  }
  const account = getAccountRow(accountId);
  if (!account) throw httpError(404, 'account_not_found', '账号不存在');
  if (account.status === 'banned') throw httpError(400, 'account_banned', '该账号已封号，无法运行工作流');
  if (account.scope === 'read') throw httpError(400, 'scope_required', '只读令牌无法执行部署，请使用 deploy/full 令牌');

  const active = db.prepare(`
    SELECT id FROM workflow_runs
    WHERE account_id = ? AND workflow_id = ? AND status IN ('queued','running','cancelling')
  `).get(accountId, workflowId);
  if (active) throw httpError(409, 'already_running', `该账号已有运行中的任务：${active.id}`);

  const runner = workflow.runner || 'container';
  const normalized = normalizeParams(workflow, params);
  if (runner === 'host') {
    return startHostWorkflow({ workflow, account, params: normalized, actor });
  }
  if (!publicBase) throw httpError(400, 'public_base_missing', '无法确定管理器的公网地址');

  const service = selectService(accountId, workspaceSlug, appSlug);
  if (!service) {
    throw httpError(400, 'no_container', '该账号还没有可执行容器；请先同步资产并在工作区创建应用');
  }
  const resolvedComponent = componentFor(service, component);
  const runId = newId('run');
  const bundleToken = crypto.randomBytes(24).toString('base64url');
  const bundleExpires = new Date(Date.now() + BUNDLE_TTL_MS).toISOString();
  const apiKey = createKey(`workflow:${workflowId}:${runId}`);
  const createdAt = nowIso();
  const row = {
    id: runId,
    workflow_id: workflow.id,
    workflow_name: workflow.name,
    workflow_version: workflow.version,
    account_id: account.id,
    account_label: account.label,
    workspace_slug: service.workspace_slug,
    app_slug: service.slug,
    app_label: service.name || service.slug,
    component: resolvedComponent,
    env: service.env || null,
    region: service.region || null,
    status: 'queued',
    params_json: JSON.stringify(redactParams(normalized)),
    log_tail: '',
    exit_code: null,
    error: null,
    bundle_token_hash: sha256(bundleToken),
    bundle_expires_at: bundleExpires,
    api_key_id: apiKey.id,
    cancel_requested: 0,
    poll_errors: 0,
    created_by: actor,
    created_at: createdAt,
    started_at: null,
    finished_at: null,
    last_polled_at: createdAt,
  };
  try {
    db.prepare(`
      INSERT INTO workflow_runs (
        id, workflow_id, workflow_name, workflow_version, account_id, account_label,
        workspace_slug, app_slug, app_label, component, env, region, status, params_json,
        log_tail, exit_code, error, bundle_token_hash, bundle_expires_at, api_key_id,
        cancel_requested, poll_errors, created_by, created_at, started_at, finished_at, last_polled_at
      ) VALUES (
        @id, @workflow_id, @workflow_name, @workflow_version, @account_id, @account_label,
        @workspace_slug, @app_slug, @app_label, @component, @env, @region, @status, @params_json,
        @log_tail, @exit_code, @error, @bundle_token_hash, @bundle_expires_at, @api_key_id,
        @cancel_requested, @poll_errors, @created_by, @created_at, @started_at, @finished_at, @last_polled_at
      )
    `).run(row);
  } catch (error) {
    try { deleteKey(apiKey.id); } catch { /* best effort */ }
    throw error;
  }

  const bundleUrl = `${publicBase}/api/workflows/${encodeURIComponent(workflow.id)}/bundle`
    + `?run=${encodeURIComponent(runId)}&token=${encodeURIComponent(bundleToken)}`;
  const script = runScript({
    run: row, workflow, params: normalized, bundleUrl, managerKey: apiKey.key, publicBase,
  });

  try {
    await execOnService({
      account,
      service,
      component: resolvedComponent,
      command: startCommand(runId),
      stdin: script,
      timeoutMs: 30_000,
    });
    const startedAt = nowIso();
    db.prepare(`
      UPDATE workflow_runs SET status = 'running', started_at = ?, last_polled_at = ? WHERE id = ?
    `).run(startedAt, startedAt, runId);
    audit(actor, 'workflow.start', {
      id: runId, workflowId, accountId, app: service.slug, component: resolvedComponent,
    });
    return getWorkflowRun(runId);
  } catch (error) {
    try {
      await execOnService({
        account,
        service,
        component: resolvedComponent,
        command: cancelCommand(runId),
        timeoutMs: 10_000,
      });
    } catch { /* best effort */ }
    try { deleteKey(apiKey.id); } catch { /* best effort */ }
    db.prepare(`
      UPDATE workflow_runs SET status = 'failed', error = ?, finished_at = ?, last_polled_at = ?,
        api_key_id = NULL, bundle_token_hash = NULL, bundle_expires_at = NULL WHERE id = ?
    `).run(String(error.message || error).slice(0, 1000), nowIso(), nowIso(), runId);
    throw error;
  }
}

export async function cancelWorkflowRun(id, actor) {
  const row = db.prepare('SELECT * FROM workflow_runs WHERE id = ?').get(id);
  if (!row) throw httpError(404, 'run_not_found', '任务不存在');
  if (!ACTIVE.includes(row.status)) return publicRun(row);
  if (row.status !== 'cancelling') {
    db.prepare("UPDATE workflow_runs SET status = 'cancelling', cancel_requested = 1 WHERE id = ?").run(id);
  }
  if (row.runner === 'host') {
    if (row.status === 'queued' && !row.started_at) {
      db.prepare(`
        UPDATE workflow_runs SET status = 'cancelled', finished_at = ?, last_polled_at = ?,
          secret_json = NULL WHERE id = ?
      `).run(nowIso(), nowIso(), id);
      audit(actor, 'workflow.cancel', { id, workflowId: row.workflow_id, accountId: row.account_id });
      return getWorkflowRun(id);
    }
    await cancelHostRun(row);
    audit(actor, 'workflow.cancel', { id, workflowId: row.workflow_id, accountId: row.account_id });
    return getWorkflowRun(id);
  }
  const account = getAccountRow(row.account_id);
  if (!account) throw httpError(404, 'account_not_found', '账号已删除');
  try {
    await execOnService({
      account,
      service: runService(row),
      component: row.component,
      command: cancelCommand(row.id),
      timeoutMs: 15_000,
    });
    audit(actor, 'workflow.cancel', { id, workflowId: row.workflow_id, accountId: row.account_id });
    return getWorkflowRun(id);
  } catch (error) {
    db.prepare(`
      UPDATE workflow_runs SET error = ?, status = CASE WHEN status = 'cancelling' THEN 'running' ELSE status END
      WHERE id = ?
    `).run(`取消失败：${String(error.message || error).slice(0, 900)}`, id);
    throw error;
  }
}

export async function startWorkflowBatch({
  workflowId, accountIds = [], params = {}, actor = 'manager', publicBase,
}) {
  const ids = [...new Set(accountIds.filter(Boolean))];
  if (!ids.length) throw httpError(400, 'account_required', '至少选择一个账号');
  if (ids.length > 200) throw httpError(400, 'too_many', '单次最多批量启动 200 个账号');
  const started = [];
  const failed = [];
  for (const accountId of ids) {
    try {
      const run = await startWorkflowRun({
        workflowId, accountId, params, actor, publicBase,
      });
      started.push({ id: run.id, accountId, status: run.status });
    } catch (error) {
      failed.push({
        accountId,
        code: error.code || 'error',
        error: String(error.message || error).slice(0, 300),
      });
    }
  }
  audit(actor, 'workflow.batch_start', {
    workflowId, requested: ids.length, started: started.length, failed: failed.length,
  });
  return { started, failed, total: ids.length };
}

export async function cancelWorkflowRunsForAccounts({
  workflowId, accountIds = [], actor = 'manager',
}) {
  const ids = [...new Set(accountIds.filter(Boolean))];
  if (!ids.length) throw httpError(400, 'account_required', '至少选择一个账号');
  if (ids.length > 200) throw httpError(400, 'too_many', '单次最多取消 200 个账号');
  const runIds = [];
  for (let i = 0; i < ids.length; i += 500) {
    const chunk = ids.slice(i, i + 500);
    const rows = db.prepare(`
      SELECT id FROM workflow_runs
      WHERE workflow_id = ? AND account_id IN (${chunk.map(() => '?').join(',')})
        AND status IN ('queued','running','cancelling')
    `).all(workflowId, ...chunk);
    for (const row of rows) runIds.push(row.id);
  }
  const cancelled = [];
  const failed = [];
  for (const runId of runIds) {
    try {
      const run = await cancelWorkflowRun(runId, actor);
      cancelled.push({ id: runId, status: run?.status || 'cancelling' });
    } catch (error) {
      failed.push({ id: runId, error: String(error.message || error).slice(0, 300) });
    }
  }
  audit(actor, 'workflow.batch_cancel', {
    workflowId, accounts: ids.length, found: runIds.length, cancelled: cancelled.length,
  });
  return { cancelled, failed, total: ids.length, found: runIds.length };
}

export function resolveWorkflowBundle(workflowId, runId, token) {
  const workflow = WORKFLOW_MAP.get(workflowId);
  if (!workflow || !token) return null;
  const file = bundlePath(workflow);
  if (!fs.existsSync(file)) return null;
  const row = db.prepare(`
    SELECT bundle_token_hash, bundle_expires_at FROM workflow_runs
    WHERE id = ? AND workflow_id = ?
  `).get(runId, workflowId);
  if (!row?.bundle_token_hash) return null;
  if (sha256(token) !== row.bundle_token_hash) return null;
  if (row.bundle_expires_at && Date.parse(row.bundle_expires_at) < Date.now()) return null;
  return { file, workflow };
}

function finishRun(row, status, { exitCode = null, error = null, logTail } = {}) {
  const finished = nowIso();
  db.prepare(`
    UPDATE workflow_runs SET status = ?, exit_code = ?, error = ?, log_tail = ?,
      finished_at = ?, last_polled_at = ?, poll_errors = 0,
      bundle_token_hash = NULL, bundle_expires_at = NULL, secret_json = NULL
    WHERE id = ?
  `).run(status, exitCode, error ? String(error).slice(0, 1000) : null,
    logTail ?? row.log_tail ?? '', finished, finished, row.id);
  if (row.api_key_id) {
    try { deleteKey(row.api_key_id); } catch { /* best effort */ }
    db.prepare('UPDATE workflow_runs SET api_key_id = NULL WHERE id = ?').run(row.id);
  }
  audit('workflow', 'workflow.finish', { id: row.id, workflowId: row.workflow_id, status, exitCode });
  log.info(`[workflow] ${row.id} ${status}${exitCode != null ? ` exit=${exitCode}` : ''}`);
  if (row.runner === 'host') pumpHostQueue();
  return getWorkflowRun(row.id);
}

function parseLog(output) {
  const marker = output.indexOf('---LOG---');
  if (marker < 0) return '';
  return output.slice(marker + 9).trim().slice(-12_000);
}

async function pollRun(row) {
  if (row.runner === 'host') {
    await pollHostRun(row);
    return;
  }
  if (row.status === 'queued' && Date.now() - Date.parse(row.created_at) < 30_000) return;
  if (row.last_polled_at && Date.now() - Date.parse(row.last_polled_at) < 8_000) return;
  const account = getAccountRow(row.account_id);
  if (!account) {
    finishRun(row, 'failed', { error: '账号已删除' });
    return;
  }
  let result;
  try {
    result = await execOnService({
      account,
      service: runService(row),
      component: row.component,
      command: statusCommand(row.id),
      timeoutMs: 30_000,
    });
  } catch (error) {
    const errors = Number(row.poll_errors || 0) + 1;
    if (errors >= 12) {
      finishRun(row, row.status === 'cancelling' ? 'cancelled' : 'failed', {
        error: `状态轮询连续失败：${error.message}`,
      });
      return;
    }
    db.prepare(`
      UPDATE workflow_runs SET poll_errors = ?, error = ?, last_polled_at = ? WHERE id = ?
    `).run(errors, String(error.message || error).slice(0, 1000), nowIso(), row.id);
    return;
  }

  const output = String(result?.output || '');
  const logTail = parseLog(output);
  const exitMatch = /(?:^|\n)exit=(-?\d+)(?:\n|$)/.exec(output);
  const running = /(?:^|\n)running(?:\n|$)/.test(output);
  const lost = /(?:^|\n)lost(?:\n|$)/.test(output);
  const cancelling = /(?:^|\n)cancelling(?:\n|$)/.test(output);

  if (exitMatch) {
    const exitCode = Number(exitMatch[1]);
    const cancelled = row.cancel_requested || row.status === 'cancelling';
    finishRun(row, cancelled ? 'cancelled' : exitCode === 0 ? 'succeeded' : 'failed', {
      exitCode, logTail, error: cancelled ? null : exitCode === 0 ? null : `进程退出码 ${exitCode}`,
    });
    return;
  }
  if (lost) {
    finishRun(row, row.cancel_requested || row.status === 'cancelling' ? 'cancelled' : 'failed', {
      logTail,
      error: row.cancel_requested || row.status === 'cancelling' ? null : '进程已退出但未写入退出码',
    });
    return;
  }
  const nextStatus = cancelling ? 'cancelling' : row.status === 'queued' ? 'running' : row.status;
  db.prepare(`
    UPDATE workflow_runs SET status = ?, log_tail = ?, last_polled_at = ?, poll_errors = 0,
      started_at = COALESCE(started_at, ?), error = NULL
    WHERE id = ?
  `).run(nextStatus, logTail, nowIso(), nowIso(), row.id);
}

let timer = null;
let polling = false;
let initialized = false;

async function pollAll() {
  if (polling) return;
  polling = true;
  try {
    pumpHostQueue();
    const rows = db.prepare(`
      SELECT * FROM workflow_runs
      WHERE status IN ('running','cancelling')
         OR (status = 'queued' AND COALESCE(runner, 'container') <> 'host')
      ORDER BY created_at LIMIT 100
    `).all();
    for (let i = 0; i < rows.length; i += 4) {
      await Promise.all(rows.slice(i, i + 4).map((row) => pollRun(row).catch((error) => {
        log.warn(`[workflow] poll ${row.id} failed`, error);
      })));
    }
  } finally {
    polling = false;
  }
}

export function initWorkflowRunner() {
  if (initialized) return;
  initialized = true;
  for (const row of db.prepare(`
    SELECT id, api_key_id FROM workflow_runs
    WHERE api_key_id IS NOT NULL AND status NOT IN ('queued','running','cancelling')
  `).all()) {
    try { deleteKey(row.api_key_id); } catch { /* best effort */ }
    db.prepare('UPDATE workflow_runs SET api_key_id = NULL WHERE id = ?').run(row.id);
  }
  if (timer) clearInterval(timer);
  timer = setInterval(() => {
    pollAll().catch((error) => log.error('[workflow] poll loop failed', error));
  }, 10_000);
  timer.unref?.();
  setTimeout(() => {
    pollAll().catch((error) => log.error('[workflow] initial poll failed', error));
  }, 5_000).unref?.();
  pumpHostQueue();
  log.info(`[workflow] runner started · ${listWorkflows().filter((item) => item.bundleAvailable).length} bundle(s)`);
}

export function stopWorkflowRunner() {
  if (timer) clearInterval(timer);
  timer = null;
}
